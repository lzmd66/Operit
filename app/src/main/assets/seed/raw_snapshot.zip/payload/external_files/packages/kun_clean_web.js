/*
METADATA
{
    "name": "kun_clean_web",
    "description": "Kun 净化搜索层：广告/内容农场黑名单 + 内容质量打分（时效/标题质量/摘要深度/同域多样性/多引擎共识）+ 推荐理由 + 用户拉黑。不负责搜索。推荐流程：先用 various_search/google_search/duckduckgo 取原始结果，再调用 pure_search(source_text=...) 或 filter_results 过滤。也可单独用 mark_junk 维护黑名单。",
    "tools": [
        {
            "name": "pure_search",
            "description": "净化外部搜索结果（与 filter_results 等价主路径）。必须传入 source_text 或 results；不做 HTTP 直连搜索。日常：various_search → pure_search(source_text=搜索原文)。",
            "parameters": [
                { "name": "query", "description": "搜索关键词（用于相关性打分）", "type": "string", "required": true },
                { "name": "source_text", "description": "外部搜索引擎返回的原文（如 various_search 的 content）。必填之一。", "type": "string", "required": false },
                { "name": "results", "description": "已结构化的结果 JSON 字符串或数组，元素含 title/url/snippet。与 source_text 二选一，优先 results。", "type": "string", "required": false },
                { "name": "max_results", "description": "返回条数，默认 5，最大 10", "type": "number", "required": false }
            ]
        },
        {
            "name": "filter_results",
            "description": "纯净化工具：把任意搜索原文/结果列表过黑名单、去广告、内容质量打分排序（时效性/标题质量/摘要深度/同域多样性/多引擎共识），输出带推荐理由。不负责搜索。适合 various_search 之后立刻调用。",
            "parameters": [
                { "name": "query", "description": "原始搜索词，用于相关性评分", "type": "string", "required": true },
                { "name": "source_text", "description": "搜索引擎返回的原文文本", "type": "string", "required": false },
                { "name": "results", "description": "结构化结果 JSON 字符串/数组", "type": "string", "required": false },
                { "name": "max_results", "description": "返回条数，默认 5，最大 10", "type": "number", "required": false }
            ]
        },
        {
            "name": "llm_rerank",
            "description": "LLM 语义精排：把候选结果的标题+摘要发给免费小模型（默认 glm-4.7-flash），按与查询的语义相关性保留/淘汰（同义表述算相关）。启发式分数区分不开时自动触发；也可手动调用。失败自动降级到启发式评分，不影响主流程，绝不换用收费模型。",
            "parameters": [
                { "name": "query", "description": "搜索关键词", "type": "string", "required": true },
                { "name": "results", "description": "结构化结果 JSON 数组/字符串，元素含 title/url/snippet", "type": "string", "required": false },
                { "name": "source_text", "description": "搜索原文（与 results 二选一）", "type": "string", "required": false },
                { "name": "max_results", "description": "返回条数，默认 5，最大 10", "type": "number", "required": false }
            ]
        },
        {
            "name": "mark_junk",
            "description": "把垃圾站/广告站加入用户黑名单，后续 pure_search/filter_results 自动拦截。",
            "parameters": [
                { "name": "url_or_domain", "description": "垃圾站 URL 或域名，例如 csdn.net 或 https://xxx.com/a", "type": "string", "required": true },
                { "name": "reason", "description": "原因备注，可选", "type": "string", "required": false }
            ]
        },
        {
            "name": "trust_domain",
            "description": "把域名加入用户豁免名单：即使被远程订阅源误杀（列入黑名单）也强制放行。用于修复上游源误伤正经站点的情况。",
            "parameters": [
                { "name": "url_or_domain", "description": "要豁免的 URL 或域名，例如 sysgeek.cn 或 https://xxx.com/a", "type": "string", "required": true },
                { "name": "reason", "description": "原因备注，可选", "type": "string", "required": false }
            ]
        },
        {
            "name": "refresh_filters",
            "description": "从远程订阅源更新广告/垃圾站过滤列表，并合并本地用户黑名单。手机端为轻量精选源。",
            "parameters": [
                { "name": "force", "description": "是否强制更新，默认 false（未过期则跳过）", "type": "boolean", "required": false }
            ]
        }
    ],
    "env": [
        { "name": "ZHIPU_SEARCH_API_KEY", "description": "智谱开放平台 Key（chat 精排免费；search 接口照常计费）", "required": false },
        { "name": "KUN_LLM_RERANK_MODEL", "description": "精排模型名，默认 glm-4.7-flash（免费档换代时改这里）", "required": false },
        { "name": "KUN_LLM_RERANK_ENABLED", "description": "设为 0 可整体关闭 LLM 精排", "required": false }
    ]
}
*/

// ===================== 配置 =====================
// 2026-08-27：/sdcard 根目录受 scoped storage 限制无法写入（EPERM），迁移到 Download（已实测可写）
const PKG = "kun_clean_web";
const DATA_DIR = "/sdcard/Download/kun_clean_web";
const USER_BL_PATH = DATA_DIR + "/user_blacklist.txt";
const REMOTE_BL_PATH = DATA_DIR + "/remote_blacklist.txt";
const WL_OVERRIDE_PATH = DATA_DIR + "/whitelist_overrides.txt";
const META_PATH = DATA_DIR + "/meta.json";
const BAD_LOG_PATH = DATA_DIR + "/bad_results.txt";
const AI_SLOP_PATH = DATA_DIR + "/ai_slop_domains.txt";
const BLACKLIST_TTL_MS = 7 * 24 * 3600 * 1000;

const SUBSCRIPTIONS = [
  "https://gh-proxy.com/raw.githubusercontent.com/eallion/uBlacklist-subscription-compilation/main/uBlacklist.txt",
  "https://raw.githubusercontent.com/eallion/uBlacklist-subscription-compilation/main/uBlacklist.txt",
  "https://raw.githubusercontent.com/laylavish/uBlockOrigin-HUGE-AI-Blocklist/main/list_uBlacklist.txt",
  "https://raw.githubusercontent.com/NotaInutilis/Super-SEO-Spam-Suppressor/main/ublacklist.txt",
  "https://raw.githubusercontent.com/wdmpa/content-farm-list/main/uBlacklist.txt",
  "https://raw.githubusercontent.com/jarelllama/Scam-Blocklist/main/lists/wildcard_domains/scams.txt",
  // ── 2026-08-05 新增：中文内容农场核心清单（调研 uBlacklist 官方规则集生态后补充）──
  "https://raw.githubusercontent.com/cobaltdisco/Google-Chinese-Results-Blocklist/master/uBlacklist_subscription.txt",
  "https://raw.githubusercontent.com/dallaslu/penzai-list/main/uBlacklist.txt",
  "https://raw.githubusercontent.com/MisakaMikoto-35c5/ublacklist-rules/master/content-farm.txt",
  "https://raw.githubusercontent.com/liubiantao/uBlacklist-Websites/master/uBlacklist.txt",
  // 机翻站（GitHub/SO 采集翻译，dev 搜索高发）
  "https://raw.githubusercontent.com/arosh/ublacklist-github-translation/master/uBlacklist.txt",
  "https://raw.githubusercontent.com/arosh/ublacklist-stackoverflow-translation/master/uBlacklist.txt",
  // ── 2026-08-26 新增：钓鱼/挂马域名防御源（这类直接拦截，不做降级）──
  "https://phishing.army/download/phishing_army_blocklist_extended.txt",
  "https://urlhaus.abuse.ch/downloads/hostfile/"
];

const STATIC_BLACKLIST = [
  "csdn.net", "blog.csdn.net",
  "baijiahao.baidu.com", "zhidao.baidu.com", "tieba.baidu.com",
  "jingyan.baidu.com", "wenku.baidu.com",
  "360doc.com", "sohu.com", "toutiao.com",
  "jianshu.com", "ithome.com",
  "51cto.com", "oschina.net", "cnblogs.com",
  "segmentfault.com", "tuicool.com", "aibase.com",
  "hao123.com", "zol.com.cn",
  "answers.microsoft.com", "quora.com", "medium.com", "dev.to",
  "geeksforgeeks.org", "tutorialspoint.com", "w3schools.com",
  "javatpoint.com", "programiz.com", "stackshare.io"
];

/*
 * 白名单按“注册域及其子域”匹配：openai.com 会覆盖 developers.openai.com、
 * help.openai.com 等。这里是安全放行名单，不应用来随意绕过用户主动拉黑。
 */
const WHITELIST = [
  "github.com", "gitlab.com", "bitbucket.org", "github.io",
  "google.com", "bing.com", "baidu.com", "duckduckgo.com",
  "microsoft.com", "stackoverflow.com", "stackexchange.com",
  "wikipedia.org", "cloudflare.com", "pypi.org", "python.org",
  "npmjs.com", "nodejs.org", "mozilla.org", "developer.mozilla.org",
  "arxiv.org", "reddit.com", "youtube.com", "operit.app",
  // 2026-08-05：评价/选购场景核心社区站（黑名单勿误伤；质量靠 TRUSTED 低分表达）
  "nga.cn", "v2ex.com", "zhihu.com", "douban.com", "smzdm.com",
  "bilibili.com", "sspai.com", "chiphell.com", "keylol.com",
  "steamcommunity.com", "store.steampowered.com",
  // OpenAI 官方主域；域匹配函数会同时放行其真实子域（developers/help 等）。
  "openai.com", "chatgpt.com"
];
const WHITELIST_SET = WHITELIST.reduce(function (set, domain) {
  set[domain] = 1;
  return set;
}, {});

const TRUSTED = {
  "github.com": 0.35,
  "gitlab.com": 0.28,
  "stackoverflow.com": 0.32,
  "serverfault.com": 0.28,
  "superuser.com": 0.26,
  "developer.mozilla.org": 0.38,
  "docs.python.org": 0.38,
  "docs.microsoft.com": 0.34,
  "learn.microsoft.com": 0.36,
  "nodejs.org": 0.34,
  "wikipedia.org": 0.22,
  "arxiv.org": 0.30,
  "operit.app": 0.40,
  "openai.com": 0.40,
  "anthropic.com": 0.40,
  "claude.ai": 0.40,
  "huggingface.co": 0.28,
  "kaggle.com": 0.26,
  "doi.org": 0.30,
  "nature.com": 0.32,
  "science.org": 0.32,
  "acm.org": 0.30,
  "ieee.org": 0.30,
  // ── 2026-08-05 新增：真实用户社区 + 独立创作站（Small Web 思路，评价/选购场景核心）──
  "sspai.com": 0.20,
  "chiphell.com": 0.18,
  "nga.cn": 0.16,
  "v2ex.com": 0.14,
  "keylol.com": 0.12,
  "steamcommunity.com": 0.16,
  "store.steampowered.com": 0.16,
  "reddit.com": 0.18,
  "douban.com": 0.10,
  "zhihu.com": 0.08,
  "smzdm.com": 0.05,
  "bilibili.com": 0.05
};

const LOW_QUALITY = {
  "csdn.net": -0.28,
  "blog.csdn.net": -0.30,
  "baijiahao.baidu.com": -0.35,
  "zhidao.baidu.com": -0.25,
  "jianshu.com": -0.18,
  "cnblogs.com": -0.12,
  "medium.com": -0.10,
  "quora.com": -0.15
};

const SPAM_KEYWORDS = [
  "点击", "广告", "推广", "加微信", "扫码加", "原标题",
  "转载请", "版权声明", "免责声明", "立即下载", "开通会员",
  "限时优惠", "联系客服", "带货", "为你推荐", "赞助商",
  "软文", "伪原创", "洗稿",
  "click here", "sponsored", "advertisement", "affiliate",
  "promo code", "buy now", "limited time", "sign up now",
  "as an amazon associate"
];

// ── 2026-08-05 新增：标题质量惩罚（借鉴 clean_search_mcp 评分 + Google E-E-A-T / Kagi SlopStop）──
// SEO 堆分隔符标题（"XXX | YYY | ZZZ | 2026 | 最新"这类农场/聚合站高频样式）
const SEO_SEP_RE = /[|_—»·\-]/g;
// AI 农场模板标题："Best X Tools 2026" / "Top 10 Apps" 等批量生成样式
const AI_FARM_TITLE_RE = /best\s+[\w\s]{0,20}?(tools|apps|software|services|platforms|sites|alternatives)\s*(in\s*)?(20\d\d)?/i;
// 中文营销号/空洞文标题模板（SlopStop 思路的轻量标题级检测；保守：多个命中才重罚）
const SLOP_TITLE_WORDS = ["是什么", "一文看懂", "看完你就懂", "全攻略", "最全", "终极指南", "保姆级", "避坑指南", "值得收藏", "建议收藏", "干货满满", "不看后悔", "震惊", "竟然", "居然", "太强了", "绝了"];

// ── 2026-08-25 新增：内容性优化（正向质量信号，借鉴 Kagi 排序哲学 / E-E-A-T / LobeChat 思路）──
// 标题意图词：出现说明内容有实质价值（评测/实测/教程/对比/文档…）
const QUALITY_TITLE_WORDS = ["实测", "评测", "测评", "体验", "教程", "指南", "对比", "分析", "深度", "避坑", "踩坑", "攻略", "文档", "官方", "复盘", "总结", "白皮书", "上手", "开箱", "使用感受", "长期使用", "review", "benchmark", "tutorial", "guide", "comparison", "test", "analysis", "deep dive", "how to", "hands-on", "impressions"];
// 标题低价值词：引流/资源类，通常无实质内容
const LOW_VALUE_TITLE_WORDS = ["下载", "破解", "免费版", "网盘", "迅雷", "福利", "资源站", "种子", "磁力", "注册送", "签到", "领红包", "会员免费", "破解版", "激活码", "注册码"];

function titlePenalty(title) {
  const t = String(title || "");
  if (AI_FARM_TITLE_RE.test(t)) return -0.20;
  const seps = (t.match(SEO_SEP_RE) || []).length;
  if (seps >= 5) return -0.08;
  if (seps >= 3) return -0.04;
  return 0;
}

function slopTitlePenalty(title) {
  const t = String(title || "");
  let hits = 0;
  for (let i = 0; i < SLOP_TITLE_WORDS.length; i++) {
    if (t.indexOf(SLOP_TITLE_WORDS[i]) >= 0) hits++;
  }
  if (hits >= 2) return -0.10;
  if (hits === 1) return -0.04;
  return 0;
}

// ── 2026-08-26 新增：AI 水文识别（Kagi SlopStop 思路：页面级信号 → 域名级累计 → downrank 不删除）──
// AI 典型摘要句式：空洞结构 / AI 自我声明 / 模板化过渡语（保守：多项命中才可疑）
const AI_SNIPPET_PATTERNS = [
  "希望对您有帮助", "希望这篇文章", "希望能帮到您", "希望对你有帮助",
  "综上所述", "总的来说，", "总而言之，",
  "接下来，我们将", "首先，我们需要了解", "本文将为您详细", "让我们一起来",
  "内容由ai生成", "本文由ai生成", "由人工智能生成", "ai辅助创作",
  "generated by ai", "ai-generated", "written by ai",
  "in conclusion,", "it is important to note", "delve into", "unlock the power"
];
// 批量生成标题模板："10个xxx盘点/排行/推荐/神器"
const AI_TITLE_NUMBER_RE = /\d+\s*(个|款|种|大|条)?\s*.{0,8}(盘点|排行榜|排行榜|推荐榜|神器|必备|合集排名)/;

// 页面级 AI 信号计数：≥2 视为可疑（注册进域名档案）
function aiSignalCount(item) {
  const title = String(item.title || "");
  const sn = String(item.snippet || "");
  let n = 0;
  if (AI_TITLE_NUMBER_RE.test(title)) n++;
  if (/ai\s*(生成|创作|写作)|由\s*ai|chatgpt|deepseek\s*写/i.test(title)) n++;
  const sl = sn.toLowerCase();
  for (let i = 0; i < AI_SNIPPET_PATTERNS.length; i++) {
    if (sl.indexOf(AI_SNIPPET_PATTERNS[i]) >= 0) {
      n++;
      if (n >= 4) break;
    }
  }
  return n;
}

// 域名档案：domain\tcount，一行一条；子域独立评估（对齐 Kagi）
async function loadSlopArchive() {
  const text = await readTextFile(AI_SLOP_PATH);
  const arc = {};
  if (!text) return arc;
  const lines = text.split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    const p = line.split("\t");
    if (p.length >= 2 && isDomainLike(p[0])) {
      const c = parseInt(p[1], 10);
      if (isFinite(c) && c > 0) arc[p[0]] = c;
    }
  }
  return arc;
}

async function saveSlopArchive(arc) {
  const keys = Object.keys(arc);
  if (!keys.length) return true;
  const out = keys.map(function (k) { return k + "\t" + arc[k]; }).join("\n");
  return await writeTextFile(AI_SLOP_PATH, out + "\n");
}

// 域名级降权：≥2 次 -0.15；≥5 次 -0.25。白名单豁免、不删除结果。
function slopDomainPenalty(host, archive) {
  if (!host || !archive) return 0;
  if (isWhitelistedDomain(host)) return 0;
  const c = archive[host] || 0;
  if (c >= 5) return -0.25;
  if (c >= 2) return -0.15;
  return 0;
}

// ── 2026-08-25 新增：内容质量评分（正向信号，与上方惩罚互补）──

// 时效性：标题/摘要/URL 中出现的最新年份越接近当前越加分；5 年以上缓慢降权。
// 无年份信号不惩罚（避免误伤历史/通用内容）；命中相对时间词小幅加分。
function freshnessScore(item) {
  const text = String(item.title || "") + " " + String(item.snippet || "") + " " + String(item.url || "");
  const now = new Date().getFullYear();
  const years = text.match(/20[0-2]\d/g);
  if (years && years.length) {
    let minAge = 99;
    for (let i = 0; i < years.length; i++) {
      const age = now - parseInt(years[i], 10);
      if (age >= 0 && age < minAge) minAge = age;
    }
    if (minAge <= 1) return 0.10;
    if (minAge <= 2) return 0.05;
    if (minAge <= 4) return 0;
    return Math.max(-0.18, -(minAge - 4) * 0.03);
  }
  if (/今日|今天|昨日|昨天|本周|刚刚|最新|首发/.test(text)) return 0.06;
  return 0;
}

// 标题正向质量：意图词加分（评测/实测/教程等）、引流词降权、含数字/疑问式加分
function titleQualityScore(title) {
  const t = String(title || "").trim();
  if (!t) return -0.10;
  let s = 0;
  if (t.length >= 4) s += 0.02;
  const lower = t.toLowerCase();
  let w = 0;
  for (let i = 0; i < QUALITY_TITLE_WORDS.length; i++) {
    if (lower.indexOf(QUALITY_TITLE_WORDS[i]) >= 0) w++;
  }
  if (w >= 2) s += 0.12;
  else if (w === 1) s += 0.06;
  let low = 0;
  for (let i = 0; i < LOW_VALUE_TITLE_WORDS.length; i++) {
    if (lower.indexOf(LOW_VALUE_TITLE_WORDS[i]) >= 0) low++;
  }
  if (low >= 2) s -= 0.18;
  else if (low === 1) s -= 0.08;
  if (/\d/.test(t)) s += 0.03;
  if (t.indexOf("?") >= 0 || t.indexOf("？") >= 0) s += 0.02;
  return clamp(s, -0.25, 0.20);
}

// 摘要深度：具体数字/时间/价格是信息密度信号；空摘要/营销词降权
function snippetDepthScore(item) {
  const sn = String(item.snippet || "").trim();
  if (!sn) return -0.12;
  if (sn.length < 24) return -0.08;
  let s = 0;
  if (sn.length >= 80) s += 0.05;
  if (/\d/.test(sn)) s += 0.04;
  if (/20[0-2]\d/.test(sn)) s += 0.03;
  if (/[%￥$]|元|块|美元/.test(sn)) s += 0.02;
  const sp = spamHits(sn);
  if (sp >= 1) s -= Math.min(0.15, sp * 0.05);
  return clamp(s, -0.2, 0.12);
}

// 推荐理由标签：告诉调用方“为什么把这条排前面”
const COMMUNITY_SITES = {
  "nga.cn": 1, "v2ex.com": 1, "chiphell.com": 1, "keylol.com": 1,
  "reddit.com": 1, "douban.com": 1, "smzdm.com": 1, "bilibili.com": 1,
  "sspai.com": 1, "zhihu.com": 1, "steamcommunity.com": 1, "store.steampowered.com": 1
};
function computeReasons(item) {
  const reasons = [];
  const host = domainOf(item.url);
  const parts = host.split(".");
  let trustedScore = 0;
  let isCommunity = false;
  for (let i = 0; i < parts.length - 1; i++) {
    const cand = parts.slice(i).join(".");
    if (TRUSTED[cand] != null) trustedScore = Math.max(trustedScore, TRUSTED[cand]);
    if (COMMUNITY_SITES[cand]) isCommunity = true;
  }
  if (trustedScore >= 0.30) reasons.push("权威/官方");
  if (isCommunity) reasons.push("社区/真实用户");
  if (freshnessScore(item) >= 0.05) reasons.push("时效新");
  if (titleQualityScore(item.title) >= 0.08) reasons.push("内容扎实");
  if ((item.engines || []).length >= 2) reasons.push("多引擎共识");
  if (/教程|指南|攻略|how to|tutorial|guide/i.test(item.title || "")) reasons.push("教程/说明");
  if (String(item.snippet || "").length >= 80) reasons.push("信息详实");
  // 2026-08-26：AI 水文信号透明化——正向最多留 3 条，负面标签必保留
  const flags = [];
  if ((item._aiSignals || 0) >= 2) flags.push("疑似AI水文");
  if (typeof item._slopPenalty === "number" && item._slopPenalty < 0) flags.push("域名档案降权");
  return flags.concat(reasons.slice(0, 4 - flags.length));
}

// ── 2026-09-07 LLM 语义精排：免费小模型（默认 glm-4.7-flash）只在启发式分数区分不开时触发 ──
// 模型名可配：环境变量 KUN_LLM_RERANK_MODEL；KUN_LLM_RERANK_ENABLED=0 整体关闭。
// 任何失败（无key/网络/解析/免费政策变化）都静默降级回启发式评分，绝不阻塞、绝不换用收费模型。
const LLM_RERANK_URL = "https://open.bigmodel.cn/api/paas/v4/chat/completions";
const LLM_RERANK_TIMEOUT = 45000;

function llmRerankConfig() {
  let model = "";
  let enabled = true;
  try { model = getEnv("KUN_LLM_RERANK_MODEL") || ""; } catch (e) {}
  try { if (getEnv("KUN_LLM_RERANK_ENABLED") === "0") enabled = false; } catch (e) {}
  let key = "";
  try { key = getEnv("ZHIPU_SEARCH_API_KEY") || getEnv("DEFAULT_API_KEY") || ""; } catch (e) {}
  return { model: model || "glm-4.7-flash", enabled: enabled, key: key };
}

function buildRerankPrompt(query, items) {
  const lines = [];
  for (let i = 0; i < items.length; i++) {
    const it = items[i];
    const sn = String(it.snippet || "").replace(/\s+/g, " ").slice(0, 150);
    lines.push((i + 1) + ". 标题: " + String(it.title || "").slice(0, 60) + (sn ? "\n   摘要: " + sn : ""));
  }
  return "用户搜索: " + query + "\n\n候选结果:\n" + lines.join("\n") +
    "\n\n任务: 判断每条结果是否与用户搜索实质相关（同义表述算相关，仅堆砌关键词但答非所问算不相关）。" +
    "\n只输出严格 JSON，禁止输出任何其他文字或代码块标记。格式: {\"keep\":[{\"i\":编号,\"rel\":0到1的小数,\"why\":\"不超过12字理由\"}]}，keep 里只放相关的条目。";
}

function busyWait(ms) {
  const end = Date.now() + ms;
  while (Date.now() < end) {}
}

async function llmRerankCall(query, items) {
  const cfg = llmRerankConfig();
  if (!cfg.enabled) throw new Error("llm_rerank disabled by env");
  if (!cfg.key) throw new Error("no API key (ZHIPU_SEARCH_API_KEY)");
  const client = OkHttp.newBuilder()
    .connectTimeout(LLM_RERANK_TIMEOUT)
    .readTimeout(LLM_RERANK_TIMEOUT)
    .writeTimeout(LLM_RERANK_TIMEOUT)
    .build();
  const mkBody = function (useNoThink, maxTokens) {
    const b = {
      model: cfg.model,
      messages: [
        { role: "system", content: "你是搜索结果相关性判定器。直接输出严格 JSON，不要输出思考过程或任何其他文字。" },
        { role: "user", content: buildRerankPrompt(query, items) }
      ],
      temperature: 0.1,
      max_tokens: maxTokens
    };
    if (useNoThink) b.thinking = { type: "disabled" };
    return b;
  };
  // 2026-09-07 实测修正：免费档高峰会 429（code 1305，访问量过大）→ 退避重试；
  // 思考模式会把 max_tokens 花在思考上导致正文空 → 默认模式加大 token 上限
  const plan = [
    { useNoThink: true, waitBefore: 0, maxTokens: 900, tag: "noThink" },
    { useNoThink: true, waitBefore: 4000, maxTokens: 900, tag: "noThink-retry" },
    { useNoThink: false, waitBefore: 0, maxTokens: 2000, tag: "think-fallback" }
  ];
  const attemptErrors = [];
  for (let a = 0; a < plan.length; a++) {
    const p = plan[a];
    try {
      if (p.waitBefore > 0) busyWait(p.waitBefore);
      const resp = await client.newRequest()
        .url(LLM_RERANK_URL)
        .method("POST")
        .header("Authorization", "Bearer " + cfg.key)
        .header("Content-Type", "application/json")
        .body(JSON.stringify(mkBody(p.useNoThink, p.maxTokens)), "json")
        .build().execute();
      const content = resp.content;
      if (!resp.isSuccessful()) {
        throw new Error("HTTP " + resp.statusCode + ": " + String(content).slice(0, 160));
      }
      const parsed = JSON.parse(content);
      const msg = parsed.choices && parsed.choices[0] && parsed.choices[0].message ? parsed.choices[0].message : null;
      const text = msg ? (msg.content || "") : "";
      const m = String(text).match(/\{[\s\S]*\}/);
      if (!m) throw new Error("no json in reply (head: " + String(text).slice(0, 120) + ")");
      const verdict = JSON.parse(m[0]);
      if (!verdict || !Array.isArray(verdict.keep)) throw new Error("bad verdict shape");
      return { model: cfg.model, keep: verdict.keep, mode: p.tag };
    } catch (e) {
      attemptErrors.push(p.tag + ": " + String(e && e.message ? e.message : e).slice(0, 150));
    }
  }
  throw new Error(attemptErrors.join(" | ") || "llm_rerank failed");
}

// 触发判断：top 分数太低（没找到好结果）或前两名咬得太紧（排序不确定）才算歧义
function isAmbiguous(scored) {
  if (!scored || scored.length < 3) return false;
  const top = scored[0].score;
  const second = scored[1] ? scored[1].score : 0;
  return top < 0.55 || (top - second) <= 0.06;
}

function applyLlmVerdict(scored, keep) {
  const byIndex = {};
  for (let k = 0; k < keep.length; k++) {
    const e = keep[k];
    const idx = parseInt(e.i, 10);
    if (isFinite(idx) && idx >= 1 && idx <= scored.length) byIndex[idx] = e;
  }
  return scored.map(function (s, n) {
    const v = byIndex[n + 1];
    const out = {};
    for (const key in s) out[key] = s[key];
    out.reasons = (s.reasons || []).slice();
    if (v && Number(v.rel) >= 0.6) {
      out.score = Math.max(s.score, 0.78 + Math.min(0.12, (Number(v.rel) - 0.6)) * 2);
      out.reasons.unshift("LLM确认相关" + (v.why ? "(" + String(v.why).slice(0, 12) + ")" : ""));
    } else if (v) {
      out.score = Math.min(s.score, 0.45);
      out.reasons.unshift("LLM判定弱相关");
    } else {
      out.score = Math.min(s.score, 0.35);
      out.reasons.unshift("LLM判定不相关");
    }
    out.score = clamp(out.score, 0, 1);
    return out;
  });
}

const HTTP_HEADERS = {
  "User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
  "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
  "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8"
};

// ===================== 基础工具 =====================
function ok(data, message) {
  const payload = { success: true, message: message || "ok", data: data };
  if (typeof complete === "function") complete(payload);
  return payload;
}

function fail(message, extra) {
  const payload = Object.assign({ success: false, message: String(message || "error") }, extra || {});
  if (typeof complete === "function") complete(payload);
  return payload;
}

function clamp(n, a, b) {
  n = Number(n);
  if (!isFinite(n)) return a;
  return Math.max(a, Math.min(b, n));
}

function cleanDomain(input) {
  let d = String(input || "").trim().toLowerCase();
  d = d.replace(/^https?:\/\//, "").replace(/^www\./, "");
  d = d.split("/")[0].split("?")[0].split("#")[0].split(":")[0];
  return d.replace(/^\.+|\.+$/g, "");
}

function domainOf(url) {
  try {
    const m = String(url || "").match(/^https?:\/\/([^\/\?#]+)/i);
    if (!m) return "";
    return cleanDomain(m[1]);
  } catch (e) {
    return "";
  }
}

function isDomainLike(d) {
  return /^(?:[a-z0-9-]+\.)+[a-z]{2,}$/i.test(d || "");
}

/* Whitelist matching walks DNS labels only, so evilopenai.com cannot inherit
 * openai.com privileges. */
function isWhitelistedDomain(host) {
  host = cleanDomain(host);
  if (!host) return false;
  if (WHITELIST_SET[host]) return true;
  const parts = host.split(".");
  for (let i = 1; i < parts.length - 1; i++) {
    if (WHITELIST_SET[parts.slice(i).join(".")]) return true;
  }
  return false;
}

function detectLang(query) {
  return /[\u4e00-\u9fff]/.test(String(query || "")) ? "zh" : "en";
}

function stripHtml(s) {
  return String(s || "")
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/"/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

function decodeUrl(u) {
  let url = String(u || "").trim();
  const m = url.match(/[?&]u=a1([^&]+)/i);
  if (m) {
    try { url = decodeURIComponent(m[1]); } catch (e) {}
  }
  if (url.indexOf("http") !== 0 && url.indexOf("https%3A") === 0) {
    try { url = decodeURIComponent(url); } catch (e) {}
  }
  return url;
}

function isNoiseUrl(url) {
  const u = String(url || "").toLowerCase();
  if (!/^https?:\/\//.test(u)) return true;
  const host = domainOf(u);
  if (!host) return true;
  const noise = [
    "bing.com", "cn.bing.com", "microsoft.com", "msn.com",
    "live.com", "office.com", "azure.com",
    "duckduckgo.com", "google.com", "gstatic.com",
    "baidu.com", "sogou.com"
  ];
  for (let i = 0; i < noise.length; i++) {
    if (host === noise[i] || host.endsWith("." + noise[i])) return true;
  }
  if (/\/(fd|sa|rp|rs|rb)\//.test(u)) return true;
  return false;
}

function tokenize(query) {
  const q = String(query || "").toLowerCase();
  const zh = q.match(/[\u4e00-\u9fff]{1,}/g) || [];
  const en = q.match(/[a-z0-9_]{2,}/g) || [];
  const toks = [];
  zh.forEach(function (z) {
    if (z.length <= 2) toks.push(z);
    else {
      for (let i = 0; i < z.length - 1; i++) toks.push(z.slice(i, i + 2));
    }
  });
  en.forEach(function (e) { toks.push(e); });
  return Array.from(new Set(toks)).slice(0, 24);
}

function relevanceHits(query, text) {
  const toks = tokenize(query);
  if (!toks.length) return 1;
  const hay = String(text || "").toLowerCase();
  let hits = 0;
  for (let i = 0; i < toks.length; i++) {
    if (hay.indexOf(toks[i]) >= 0) hits++;
  }
  return hits;
}

// ── 2026-09-07 覆盖率模型：衡量查询 token 在标题/摘要中的命中比例，供评分扣分与沉底 ──
function relevanceDetail(query, item) {
  const toks = tokenize(query);
  const total = toks.length;
  if (!total) return { total: 0, hits: 0, titleHits: 0, ratio: 1 };
  const title = String(item.title || "").toLowerCase();
  const body = (String(item.snippet || "") + " " + String(item.content || "")).toLowerCase();
  let hits = 0;
  let titleHits = 0;
  for (let i = 0; i < toks.length; i++) {
    const inTitle = title.indexOf(toks[i]) >= 0;
    if (inTitle || body.indexOf(toks[i]) >= 0) hits++;
    if (inTitle) titleHits++;
  }
  return { total: total, hits: hits, titleHits: titleHits, ratio: hits / total };
}

function spamHits(text) {
  const t = String(text || "").toLowerCase();
  let n = 0;
  for (let i = 0; i < SPAM_KEYWORDS.length; i++) {
    if (t.indexOf(String(SPAM_KEYWORDS[i]).toLowerCase()) >= 0) n++;
  }
  return n;
}

function parseListText(text) {
  const domains = {};
  const lines = String(text || "").split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    let line = lines[i].trim();
    if (!line || line[0] === "#" || line[0] === "!" || line[0] === "@") continue;
    let domain = "";
    let m = line.match(/^\*:\/\/(?:\*\.)?([a-z0-9.-]+)\//i);
    if (m) domain = cleanDomain(m[1]);
    if (!domain) {
      m = line.match(/^\|\|([a-z0-9.-]+)\^/i);
      if (m) domain = cleanDomain(m[1]);
    }
    if (!domain) {
      m = line.match(/^(?:0\.0\.0\.0|127\.0\.0\.1)\s+([a-z0-9.-]+)/i);
      if (m) domain = cleanDomain(m[1]);
    }
    if (!domain) domain = cleanDomain(line);
    if (isDomainLike(domain) && !isWhitelistedDomain(domain)) domains[domain] = 1;
  }
  return Object.keys(domains);
}

// ===================== 文件 IO（原生 Tools.Files） =====================
function extractTextPayload(r) {
  if (r == null) return "";
  if (typeof r === "string") return r;
  if (typeof r.content === "string") return r.content;
  if (typeof r.text === "string") return r.text;
  if (typeof r.body === "string") return r.body;
  if (r.output != null && typeof r.output === "string") return r.output;
  if (r.data != null) {
    if (typeof r.data === "string") return r.data;
    if (typeof r.data.content === "string") return r.data.content;
    if (typeof r.data.body === "string") return r.data.body;
    if (r.data.result && typeof r.data.result.content === "string") return r.data.result.content;
    if (r.data.result && typeof r.data.result === "string") return r.data.result;
  }
  if (r.result && typeof r.result.content === "string") return r.result.content;
  return "";
}

async function ensureDir() {
  try {
    if (Tools && Tools.Files && typeof Tools.Files.mkdir === "function") {
      await Tools.Files.mkdir(DATA_DIR, true, "android");
      return;
    }
  } catch (e) {}
}

async function readTextFile(path) {
  try {
    if (Tools && Tools.Files && typeof Tools.Files.exists === "function") {
      const exists = await Tools.Files.exists(path, "android");
      if (exists && exists.exists === false) return "";
    }
  } catch (e) {}

  try {
    if (Tools && Tools.Files && typeof Tools.Files.read === "function") {
      let r = null;
      try {
        r = await Tools.Files.read({ path: path, environment: "android" });
      } catch (e1) {
        r = await Tools.Files.read(path);
      }
      const t = extractTextPayload(r);
      if (t) return t;
      if (r && typeof r === "string") return r;
    }
  } catch (e) {}
  return "";
}

async function writeTextFile(path, content) {
  const text = String(content || "");
  try {
    await ensureDir();
    if (Tools && Tools.Files && typeof Tools.Files.write === "function") {
      try {
        await Tools.Files.write(path, text, false, "android");
      } catch (e1) {
        await Tools.Files.write(path, text, false);
      }
      return true;
    }
  } catch (e) {}
  return false;
}

async function loadLines(path) {
  const text = await readTextFile(path);
  if (!text) return [];
  return text.split(/\r?\n/).map(function (x) { return cleanDomain(x); }).filter(function (x) { return isDomainLike(x); });
}

async function loadMeta() {
  const text = await readTextFile(META_PATH);
  if (!text) return {};
  try { return JSON.parse(text); } catch (e) { return {}; }
}

async function saveMeta(meta) {
  await writeTextFile(META_PATH, JSON.stringify(meta || {}, null, 2));
}

async function loadBlacklistSet(userOverrides) {
  const set = {};
  const overrideSet = {};
  (userOverrides || []).forEach(function (d) { if (d) overrideSet[d] = 1; });
  function isExempt(d) {
    return !!overrideSet[d];
  }
  STATIC_BLACKLIST.forEach(function (d) {
    if (!isWhitelistedDomain(d) && !isExempt(d)) set[d] = 1;
  });
  const user = await loadLines(USER_BL_PATH);
  user.forEach(function (d) {
    if (!isWhitelistedDomain(d) && !isExempt(d)) set[d] = 1;
  });
  const remote = await loadLines(REMOTE_BL_PATH);
  remote.forEach(function (d) {
    if (!isWhitelistedDomain(d) && !isExempt(d)) set[d] = 1;
  });
  return set;
}

function isBlocked(url, blSet) {
  const host = domainOf(url);
  if (!host) return true;
  // White-list is deliberately checked before parent-domain black-list matching.
  if (isWhitelistedDomain(host)) return false;
  const parts = host.split(".");
  for (let i = 0; i < parts.length - 1; i++) {
    const cand = parts.slice(i).join(".");
    if (blSet[cand]) return true;
  }
  return false;
}

function scoreItem(item, query) {
  let s = 0.4;
  const host = domainOf(item.url);
  const text = (item.title || "") + " " + (item.snippet || "") + " " + (item.content || "");
  // 2026-09-07 覆盖率模型：旧版相关性只加分不扣分，不相干页面也能拿 0.5+；现在低覆盖直接沉底
  const rel = relevanceDetail(query, item);
  s += Math.min(0.35, rel.hits * 0.05);
  s += Math.min(0.08, rel.titleHits * 0.04);
  if (rel.total >= 3 && rel.ratio < 0.34) {
    s -= Math.min(0.45, (0.34 - rel.ratio) * 1.2);
  }
  if (item._zeroRel) s -= 0.25;
  s -= Math.min(0.3, spamHits(text) * 0.08);
  if ((item.snippet || "").length < 20) s -= 0.08;
  if ((item.title || "").length < 4) s -= 0.08;
  // 2026-08-05：标题质量惩罚（AI农场模板 / SEO堆分隔符 / 营销空洞标题）
  s += titlePenalty(item.title);
  s += slopTitlePenalty(item.title);
  // 2026-08-25：内容性优化正向信号（时效性 / 标题质量 / 摘要深度 / 多引擎共识）
  s += freshnessScore(item);
  s += titleQualityScore(item.title);
  s += snippetDepthScore(item);
  if ((item.engines || []).length >= 2) s += 0.10;
  if ((item.engines || []).length >= 3) s += 0.04;
  // 2026-08-26：AI 水文页面级惩罚 + 域名档案降权（slopArchive 通过 item._slopPenalty 传入）
  if (item._aiSignals >= 2) s -= 0.12;
  if (typeof item._slopPenalty === "number") s += item._slopPenalty;

  const parts = host.split(".");
  for (let i = 0; i < parts.length - 1; i++) {
    const cand = parts.slice(i).join(".");
    if (TRUSTED[cand]) s += TRUSTED[cand];
    if (LOW_QUALITY[cand]) s += LOW_QUALITY[cand];
  }

  if (/baike\.baidu\.com\/item\//.test(item.url || "")) {
    const t = String(item.title || "").split("（")[0].trim();
    if (t.length === 1) s -= 0.5;
  }

  if (s < 0) s = 0;
  if (s > 1) s = 1;
  return Math.round(s * 1000) / 1000;
}

// ===================== HTTP（原生 Tools.Net.http） =====================
async function httpRequest(url, method) {
  method = method || "GET";
  if (!Tools || !Tools.Net || typeof Tools.Net.http !== "function") {
    throw new Error("Tools.Net.http unavailable in sandbox");
  }

  const resp = await Tools.Net.http({
    url: url,
    method: method,
    headers: HTTP_HEADERS,
    follow_redirects: true,
    connect_timeout: 20000,
    read_timeout: 45000,
    validateStatus: false
  });

  if (resp == null) return "";

  const saved =
    resp.content_saved_to ||
    (resp.data && resp.data.content_saved_to) ||
    resp.output_saved_to ||
    "";
  if (saved) {
    const fileText = await readTextFile(saved);
    if (fileText) return fileText;
  }

  let content = "";
  if (typeof resp.content === "string") content = resp.content;
  else if (typeof resp.body === "string") content = resp.body;
  else if (typeof resp.text === "string") content = resp.text;
  else if (typeof resp === "string") content = resp;
  else content = extractTextPayload(resp);

  if (content === "(saved_to_file)") {
    const msg = String(resp.message || resp.hint || "");
    const m = msg.match(/(\/sdcard\/[^\s。]+\.(?:html|txt|json|log))/);
    if (m) {
      const fileText = await readTextFile(m[1]);
      if (fileText) return fileText;
    }
  }

  const code = Number(resp.statusCode || resp.status || 0);
  if (code && (code < 200 || code >= 400) && (!content || content.length < 40)) {
    throw new Error("HTTP " + code + " for " + url);
  }
  return content || "";
}

async function httpGetText(url) {
  try {
    return await httpRequest(url, "GET");
  } catch (e) {
    return "";
  }
}

// ===================== 搜索解析 =====================
function normalizeSearchPayload(raw) {
  const arr = [];
  if (raw == null) return arr;

  if (typeof raw === "string") {
    const lines = raw.split(/\r?\n/);
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;

      let m = line.match(/^\[(\d+)\]\s+(.+)$/);
      if (m) {
        const rest = m[2];
        const urls = rest.match(/https?:\/\/[^\s]+/g) || [];
        let url = "";
        if (urls.length) {
          url = urls[urls.length - 1].replace(/[),.]+$/, "");
        } else {
          // search_reviews 输出格式：标题行后跟 "URL: xxx"（2026-08-05 兼容）
          const nextLine = lines[i + 1] || "";
          const um = nextLine.match(/^(?:URL|url|链接|Link)\s*[:：]\s*(https?:\/\/\S+)/i);
          if (um) url = um[1].replace(/[),.]+$/, "");
        }
        if (!url) continue;
        let title = rest;
        title = title.replace(/【[^】]*】/g, "").trim();
        title = title.replace(/\s+-\s+https?:\/\/\S+$/, "");
        title = title.replace(/https?:\/\/\S+/g, " ").replace(/\s+/g, " ").trim();
        title = title.replace(/翻译此结果/g, "").trim();
        if (!title) title = domainOf(url) || url;
        // 2026-08-25：解析 search_clean 格式的 "摘要:" 行（标题行 → URL: 行 → 摘要: 行）
        let snippet = "";
        for (let k = i + 1; k < Math.min(i + 5, lines.length); k++) {
          const sm = lines[k].match(/^(?:摘要|snippet|description|desc|简介)\s*[:：]\s*(.+)$/i);
          if (sm) { snippet = stripHtml(sm[1]).trim(); break; }
        }
        if (!isNoiseUrl(url)) arr.push({ title: title, url: url, snippet: snippet });
        continue;
      }

      m = line.match(/^\d+\.\s+(.+?)\s+-\s+(https?:\/\/\S+)$/);
      if (m) {
        const url = m[2].replace(/[),.]+$/, "");
        if (!isNoiseUrl(url)) arr.push({ title: m[1].trim(), url: url, snippet: "" });
        continue;
      }

      m = line.match(/^(?:title|标题)\s*[:：]\s*(.+)$/i);
      if (m && i + 1 < lines.length) {
        const n2 = lines[i + 1].match(/^(?:url|链接)\s*[:：]\s*(https?:\/\/\S+)/i);
        if (n2) {
          const url = n2[1].replace(/[),.]+$/, "");
          // 2026-08-25：兼容 title/URL/摘要 三行格式（search_clean 变体）
          let snippet = "";
          for (let k = i + 1; k < Math.min(i + 5, lines.length); k++) {
            const sm = lines[k].match(/^(?:摘要|snippet|description|desc|简介)\s*[:：]\s*(.+)$/i);
            if (sm) { snippet = stripHtml(sm[1]).trim(); break; }
          }
          if (!isNoiseUrl(url)) arr.push({ title: m[1].trim(), url: url, snippet: snippet });
        }
      }
    }
    return arr;
  }

  let list = [];
  if (Array.isArray(raw)) list = raw;
  else if (Array.isArray(raw.results)) list = raw.results;
  else if (Array.isArray(raw.data)) list = raw.data;
  else if (raw.data && Array.isArray(raw.data.results)) list = raw.data.results;
  else if (raw.data && Array.isArray(raw.data.items)) list = raw.data.items;
  else if (Array.isArray(raw.items)) list = raw.items;
  else if (typeof raw === "object") {
    if (typeof raw.content === "string") return normalizeSearchPayload(raw.content);
    if (raw.data && typeof raw.data.content === "string") return normalizeSearchPayload(raw.data.content);
    if (raw.platform && typeof raw.content === "string") return normalizeSearchPayload(raw.content);
    if (raw.url || raw.link) list = [raw];
  }

  return list.map(function (x) {
    if (!x || typeof x !== "object") return null;
    const url = decodeUrl(x.url || x.link || x.href || "");
    const title = stripHtml(x.title || x.name || "");
    const snippet = stripHtml(x.snippet || x.description || x.desc || x.summary || "");
    if (!url || isNoiseUrl(url)) return null;
    return { title: title || domainOf(url), url: url, snippet: snippet };
  }).filter(Boolean);
}

// 直连 Bing/DuckDuckGo 搜索已移除：日常搜索源请用 various_search 等外部包。

// ===================== 净化核心 =====================
function parseExternalResults(params) {
  const out = [];
  const seen = {};

  function pushItem(it, engineHint) {
    if (!it || typeof it !== "object") return;
    const url = decodeUrl(it.url || it.link || it.href || "");
    if (!url || isNoiseUrl(url)) return;
    const key = url.replace(/#.*$/, "").replace(/\/$/, "");
    if (!key) return;
    const eng = String(it.engine || engineHint || "external");
    // 2026-08-25：同 URL 多引擎命中 → 合并共识（评分的多引擎共识信号）
    if (seen[key]) {
      const ex = seen[key];
      if (ex.engines.indexOf(eng) < 0) ex.engines.push(eng);
      return;
    }
    seen[key] = {
      title: stripHtml(it.title || it.name || "") || domainOf(url),
      url: url,
      snippet: stripHtml(it.snippet || it.description || it.desc || it.summary || ""),
      engine: eng,
      source: it.source || "external",
      engines: [eng]
    };
    out.push(seen[key]);
  }

  let rawResults = params && params.results;
  if (rawResults != null) {
    if (typeof rawResults === "string") {
      const t = rawResults.trim();
      if (t) {
        try {
          rawResults = JSON.parse(t);
        } catch (e) {
          const parsed = normalizeSearchPayload(t);
          for (let i = 0; i < parsed.length; i++) pushItem(parsed[i], "parsed");
          rawResults = null;
        }
      } else {
        rawResults = null;
      }
    }
    if (Array.isArray(rawResults)) {
      for (let i = 0; i < rawResults.length; i++) pushItem(rawResults[i], "structured");
    } else if (rawResults && typeof rawResults === "object") {
      const list =
        (Array.isArray(rawResults.results) && rawResults.results) ||
        (Array.isArray(rawResults.items) && rawResults.items) ||
        (rawResults.data && Array.isArray(rawResults.data.results) && rawResults.data.results) ||
        (rawResults.data && Array.isArray(rawResults.data) && rawResults.data) ||
        null;
      if (list) {
        for (let i = 0; i < list.length; i++) pushItem(list[i], "structured");
      } else {
        const parsed = normalizeSearchPayload(rawResults);
        for (let i = 0; i < parsed.length; i++) pushItem(parsed[i], "structured");
      }
    }
  }

  if (!out.length && params && params.source_text) {
    const parsed = normalizeSearchPayload(params.source_text);
    for (let i = 0; i < parsed.length; i++) pushItem(parsed[i], "source_text");
  }

  return out;
}

async function purifyAndRank(query, raws, options) {
  options = options || {};
  const max_results = clamp(options.max_results || 5, 1, 10);
  const diagnostics = options.diagnostics || {};
  const mode = options.mode || "filter";

  await ensureDir();
  // 2026-08-27：用户豁免名单（上游订阅源误杀正经站时强制放行）
  const wlOverrides = await loadLines(WL_OVERRIDE_PATH);
  const blSet = await loadBlacklistSet(wlOverrides);
  // 2026-08-26：AI 水文域名档案（随结果累计，越用越准）
  const slopArchive = await loadSlopArchive();

  const blocked = [];
  const survivors = [];
  for (let i = 0; i < raws.length; i++) {
    const r = raws[i];
    if (!r || !r.url) continue;
    if (isBlocked(r.url, blSet)) {
      blocked.push({ url: r.url, title: r.title || "", reason: "blacklist" });
      continue;
    }
    const relText = (r.title || "") + " " + (r.snippet || "");
    if (relText.trim()) {
      if (relevanceHits(query, relText) < 1 && relevanceHits(query, r.url || "") < 1) {
        // 2026-09-07 收紧：零相关保底 3 条 → 2 条；保留的零相关项评分时额外压分沉底
        if (survivors.length >= 2) continue;
        r._zeroRel = true;
      }
    }
    if (spamHits(relText) >= 3) {
      blocked.push({ url: r.url, title: r.title || "", reason: "spam_keywords" });
      continue;
    }
    // 2026-08-26：页面级 AI 信号 → 记域名档案（累计）；降级而非删除（SlopStop 原则）
    const aiN = aiSignalCount(r);
    r._aiSignals = aiN;
    if (aiN >= 2) {
      const h = domainOf(r.url);
      if (h && !isWhitelistedDomain(h)) {
        slopArchive[h] = (slopArchive[h] || 0) + 1;
        await saveSlopArchive(slopArchive);
      }
    }
    r._slopPenalty = slopDomainPenalty(domainOf(r.url), slopArchive);
    survivors.push(r);
    if (survivors.length >= Math.max(12, max_results * 3)) break;
  }

  let pool = survivors.length ? survivors : raws.slice(0, Math.max(12, max_results * 3));

  // 2026-08-25：同域聚合——同一域名最多 2 条；池子不足时从溢出项按原顺序补足（保多样性）
  const domainCount = {};
  const deduped = [];
  const overflow = [];
  for (let i = 0; i < pool.length; i++) {
    const host = domainOf(pool[i].url) || "";
    const c = domainCount[host] || 0;
    if (c >= 2) { overflow.push(pool[i]); continue; }
    domainCount[host] = c + 1;
    deduped.push(pool[i]);
  }
  if (deduped.length < Math.min(8, max_results * 2)) {
    for (let i = 0; i < overflow.length && deduped.length < Math.min(8, max_results * 2); i++) {
      deduped.push(overflow[i]);
    }
  }
  pool = deduped;

  const scoredAll = pool.map(function (r) {
    return {
      title: r.title,
      url: r.url,
      snippet: r.snippet,
      engine: r.engine || (r.engines && r.engines[0]) || "",
      engines: r.engines || [],
      source: r.source || "",
      score: scoreItem(r, query),
      reasons: computeReasons(r)
    };
  }).sort(function (a, b) {
    return b.score - a.score;
  });

  // 2026-09-07 LLM 语义精排：仅歧义时触发（免费模型），任何失败静默降级回启发式排序
  const llmInfo = { triggered: false, used: false };
  if (isAmbiguous(scoredAll)) {
    llmInfo.triggered = true;
    const candidates = scoredAll.slice(0, Math.min(8, scoredAll.length));
    const t0 = Date.now();
    try {
      const verdict = await llmRerankCall(query, candidates);
      llmInfo.used = true;
      llmInfo.model = verdict.model;
      llmInfo.kept = verdict.keep.length;
      const reranked = applyLlmVerdict(candidates, verdict.keep);
      for (let i = 0; i < reranked.length; i++) scoredAll[i] = reranked[i];
      scoredAll.sort(function (a, b) { return b.score - a.score; });
    } catch (e) {
      llmInfo.error = String(e && e.message ? e.message : e).slice(0, 200);
    }
    llmInfo.latency_ms = Date.now() - t0;
  }

  const scored = scoredAll.slice(0, max_results);

  return {
    query: query,
    lang: detectLang(query),
    mode: mode,
    blocked_policy: "static + user + remote(lightweight); whitelist covers subdomains",
    blacklist_size_estimate: Object.keys(blSet).length,
    input_count: raws.length,
    blocked_count: blocked.length,
    blocked_sample: blocked.slice(0, 8),
    result_count: scored.length,
    llm_rerank: llmInfo,
    diagnostics: diagnostics,
    results: scored
  };
}

// ===================== 工具实现 =====================
async function pure_search(params) {
  return filter_results(params);
}

async function filter_results(params) {
  try {
    const query = String((params && params.query) || "").trim();
    if (!query) return fail("query 不能为空");

    const hasExternal =
      (params && params.source_text && String(params.source_text).trim()) ||
      (params && params.results != null && String(params.results).trim() !== "");
    if (!hasExternal) {
      return fail("需要 source_text 或 results。本包不负责搜索，请先用 various_search 取源再净化。", {
        data: {
          tip: "推荐流程：various_search:search_bing/combined_search → kun_clean_web:filter_results(source_text=...)"
        }
      });
    }

    const max_results = clamp((params && params.max_results) || 5, 1, 10);
    const raws = parseExternalResults(params);
    if (!raws.length) {
      return fail("未能从 source_text/results 解析出有效链接", {
        data: { query: query, results: [], tip: "检查是否传入 various_search 返回的 content 文本" }
      });
    }

    const data = await purifyAndRank(query, raws, {
      max_results: max_results,
      diagnostics: { external: { count: raws.length } },
      mode: "filter_only"
    });
    return ok(data, "过滤完成");
  } catch (e) {
    return fail(e && e.message ? e.message : e);
  }
}

async function mark_junk(params) {
  try {
    const input = String((params && params.url_or_domain) || "").trim();
    const reason = String((params && params.reason) || "").trim();
    if (!input) return fail("url_or_domain 不能为空");

    let domain = input;
    if (/^https?:\/\//i.test(input) || input.indexOf("/") >= 0) domain = domainOf(input);
    domain = cleanDomain(domain);
    if (!isDomainLike(domain)) return fail("无法解析有效域名: " + input);
    if (isWhitelistedDomain(domain)) return fail("该域名或其父域在白名单中，拒绝拉黑: " + domain);

    await ensureDir();
    const current = await loadLines(USER_BL_PATH);
    const set = {};
    current.forEach(function (d) { set[d] = 1; });
    const existed = !!set[domain];
    set[domain] = 1;
    const next = Object.keys(set).sort();
    const saved = await writeTextFile(USER_BL_PATH, next.join("\n") + "\n");
    if (!saved) return fail("写入用户黑名单失败（检查文件权限）");

    try {
      const oldLog = await readTextFile(BAD_LOG_PATH);
      const line = new Date().toISOString() + "\t" + domain + "\t" + input + "\t" + reason + "\n";
      await writeTextFile(BAD_LOG_PATH, (oldLog || "") + line);
    } catch (e) {}

    return ok({
      domain: domain,
      already_existed: existed,
      user_blacklist_count: next.length,
      path: USER_BL_PATH
    }, existed ? "域名已在黑名单中" : "已加入用户黑名单");
  } catch (e) {
    return fail(e && e.message ? e.message : e);
  }
}

// 2026-08-27：用户豁免名单——上游订阅源误杀正经站时，一键强制放行
async function trust_domain(params) {
  try {
    const input = String((params && params.url_or_domain) || "").trim();
    const reason = String((params && params.reason) || "").trim();
    if (!input) return fail("url_or_domain 不能为空");

    let domain = input;
    if (/^https?:\/\//i.test(input) || input.indexOf("/") >= 0) domain = domainOf(input);
    domain = cleanDomain(domain);
    if (!isDomainLike(domain)) return fail("无法解析有效域名: " + input);

    await ensureDir();
    const current = await loadLines(WL_OVERRIDE_PATH);
    const set = {};
    current.forEach(function (d) { set[d] = 1; });
    const existed = !!set[domain];
    set[domain] = 1;
    const next = Object.keys(set).sort();
    const saved = await writeTextFile(WL_OVERRIDE_PATH, next.join("\n") + "\n");
    if (!saved) return fail("写入豁免名单失败（检查文件权限）");
    if (reason) {
      const log = "[" + new Date().toISOString() + "] " + domain + " - " + reason + "\n";
      const old = await readTextFile(DATA_DIR + "/trust_log.txt");
      await writeTextFile(DATA_DIR + "/trust_log.txt", String(old || "") + log);
    }
    return ok({
      domain: domain,
      already_existed: existed,
      whitelist_override_count: next.length,
      path: WL_OVERRIDE_PATH
    }, existed ? "域名已在豁免名单中" : "已加入豁免名单，立即生效");
  } catch (e) {
    return fail(e && e.message ? e.message : e);
  }
}

async function refresh_filters(params) {
  try {
    const force = !!(params && params.force);
    const silent = !!(params && params._silent);
    await ensureDir();

    const meta = await loadMeta();
    const now = Date.now();
    if (!force && meta.updated_at && (now - Number(meta.updated_at) < BLACKLIST_TTL_MS)) {
      const msg = "过滤列表仍在有效期内，跳过更新";
      if (silent) return { success: true, message: msg, data: meta };
      return ok(meta, msg);
    }

    const all = {};
    const source_stats = [];
    for (let i = 0; i < SUBSCRIPTIONS.length; i++) {
      const url = SUBSCRIPTIONS[i];
      try {
        const text = await httpGetText(url);
        if (!text || text.length < 20) {
          source_stats.push({ url: url, ok: false, count: 0 });
          continue;
        }
        const domains = parseListText(text);
        domains.forEach(function (d) { all[d] = 1; });
        source_stats.push({ url: url, ok: true, count: domains.length });
      } catch (e) {
        source_stats.push({ url: url, ok: false, count: 0, error: String(e && e.message ? e.message : e) });
      }
    }

    STATIC_BLACKLIST.forEach(function (d) {
      if (!isWhitelistedDomain(d)) all[d] = 1;
    });

    const list = Object.keys(all).filter(function (d) {
      return !isWhitelistedDomain(d);
    }).sort();
    if (!list.length) {
      return fail("远程订阅全部失败，保留旧列表", { data: { source_stats: source_stats } });
    }

    const saved = await writeTextFile(REMOTE_BL_PATH, list.join("\n") + "\n");
    if (!saved) return fail("写入远程黑名单失败（检查 /sdcard 写权限）");

    const nextMeta = {
      updated_at: now,
      updated_at_iso: new Date(now).toISOString(),
      remote_count: list.length,
      source_stats: source_stats,
      ttl_days: 7,
      note: "lightweight mobile list, not full 3M desktop list; whitelist excludes subdomains"
    };
    await saveMeta(nextMeta);

    if (silent) return { success: true, message: "updated", data: nextMeta };
    return ok(nextMeta, "过滤列表已更新");
  } catch (e) {
    return fail(e && e.message ? e.message : e);
  }
}

async function llm_rerank(params) {
  try {
    const query = String((params && params.query) || "").trim();
    if (!query) return fail("query 不能为空");
    const raws = parseExternalResults(params);
    if (!raws.length) {
      return fail("需要 results 或 source_text");
    }
    const max_results = clamp((params && params.max_results) || 5, 1, 10);
    const cfg = llmRerankConfig();
    const pool = raws.slice(0, 8);
    const pre = pool.map(function (r) {
      return {
        title: r.title, url: r.url, snippet: r.snippet,
        engine: r.engine || (r.engines && r.engines[0]) || "",
        engines: r.engines || [],
        score: scoreItem(r, query),
        reasons: computeReasons(r)
      };
    }).sort(function (a, b) { return b.score - a.score; });
    const t0 = Date.now();
    try {
      const verdict = await llmRerankCall(query, pre);
      const reranked = applyLlmVerdict(pre, verdict.keep).sort(function (a, b) { return b.score - a.score; });
      return ok({
        query: query,
        model: verdict.model,
        latency_ms: Date.now() - t0,
        results: reranked.slice(0, max_results)
      }, "LLM 精排完成");
    } catch (e) {
      return fail("LLM 精排失败（主流程可降级回启发式评分，不受影响）: " + (e && e.message ? e.message : e), {
        data: { enabled: cfg.enabled, has_key: !!cfg.key, model: cfg.model }
      });
    }
  } catch (e) {
    return fail(e && e.message ? e.message : e);
  }
}

// ===================== 导出 =====================
exports.pure_search = pure_search;
exports.filter_results = filter_results;
exports.mark_junk = mark_junk;
exports.trust_domain = trust_domain;
exports.refresh_filters = refresh_filters;
exports.llm_rerank = llm_rerank;
