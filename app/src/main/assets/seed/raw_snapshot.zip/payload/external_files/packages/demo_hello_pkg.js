/*
METADATA
{
    "name": "demo_hello_pkg",
    "description": "operit_dev 脚手架冒烟示例包",
    "tools": [
        {
            "name": "hello",
            "description": "示例工具：回显输入并返回时间戳。",
            "parameters": [
                { "name": "text", "description": "可选文本", "type": "string", "required": false }
            ]
        }
    ]
}
*/

const demo_hello_pkgPackage = (function () {
    async function hello(params) {
        params = params || {};
        const text = params.text == null ? "hello from demo_hello_pkg" : String(params.text);
        return {
            success: true,
            package: "demo_hello_pkg",
            text: text,
            ts: Date.now()
        };
    }

    return {
        hello: hello
    };
})();

exports.hello = demo_hello_pkgPackage.hello;
