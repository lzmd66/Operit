/* METADATA
{
    "name": "net_probe",
    "description": "临时网络实验包（调试用，可删）：探测沙盒工具执行时长上限、单源/并行/串行 DoH 行为对比。",
    "tools": [
        {
            "name": "sleep_ms",
            "description": "睡眠指定毫秒后返回，用于探测沙盒工具执行时长上限。",
            "parameters": [
                { "name": "ms", "description": "毫秒数 0-120000，默认 3000", "type": "number", "required": false }
            ]
        },
        {
            "name": "doh_one",
            "description": "单源 DoH 查询（带自守卫超时）。name: alidns / tencent / google。返回耗时与解析结果。",
            "parameters": [
                { "name": "name", "description": "源名：alidns / tencent / google", "type": "string", "required": true },
                { "name": "host", "description": "域名", "type": "string", "required": true },
                { "name": "timeout_ms", "description": "自守卫超时毫秒，默认 8000", "type": "number", "required": false }
            ]
        },
        {
            "name": "doh_par",
            "description": "并行查询三个 DoH 源（各自独立自守卫超时），返回每源耗时与合并去重 IP。",
            "parameters": [
                { "name": "host", "description": "域名", "type": "string", "required": true },
                { "name": "timeout_ms", "description": "单源自守卫超时毫秒，默认 4000", "type": "number", "required": false }
            ]
        },
        {
            "name": "doh_serial",
            "description": "串行查询三个 DoH 源（复现 web_grab_kit 原版模式）。guard=true 时每源加自守卫超时；guard=false 则完全依赖 Tools.Net.http 自身的 timeout 参数（用于检测该参数是否被宿主执行）。",
            "parameters": [
                { "name": "host", "description": "域名", "type": "string", "required": true },
                { "name": "timeout_ms", "description": "单源超时毫秒，默认 8000", "type": "number", "required": false },
                { "name": "guard", "description": "是否加自守卫超时，默认 true", "type": "boolean", "required": false }
            ]
        }
    ]
}
*/

// ===================== 常量 =====================
const PKG = "net_probe";
const UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36";

const SOURCES = [
  { name: "alidns", url: "https://dns.alidns.com/resolve?name={host}&type=A" },
  { name: "tencent", url: "https://doh.pub/dns-query?name={host}&type=A" },
  { name: "google", url: "https://dns.google/resolve?name={host}&type=A" }
];

// ===================== 基础 =====================
function ok(data, message) {
  const payload = { success: true, message: message || "ok", data: data };
  if (typeof complete === "function") complete(payload);
  return payload;
}

function fail(message, extra) {
  const payload = Object.assign({ success: false, message: String(message || "error") }, extra || {});
  if (typeof complete === "function") complete(payload);
  return payload;
}

function str(v) { return v == null ? "" : String(v); }
function msgOf(e) { return e && e.message ? e.message : String(e); }
function clamp(n, a, b) {
  n = Number(n);
  if (!isFinite(n)) return a;
  return Math.max(a, Math.min(b, n));
}

// ===================== DoH 单源查询 =====================
/**
 * 查询单个 DoH 源。useGuard 时用 Promise.race 加自守卫超时，
 * 即使宿主不执行 timeout 参数也不会永久挂起。
 */
async function queryOne(source, host, timeoutMs, useGuard) {
  const started = Date.now();
  const url = source.url.replace("{host}", encodeURIComponent(host));
  const httpP = Tools.Net.http({
    url: url,
    method: "GET",
    headers: { "User-Agent": UA, "Accept": "application/dns-json, application/json, */*" },
    connect_timeout: timeoutMs,
    read_timeout: timeoutMs,
    responseType: "text",
    validateStatus: false
  });
  let raced = httpP;
  if (useGuard) {
    const guard = new Promise(function (_, reject) {
      setTimeout(function () { reject(new Error("guard-timeout " + timeoutMs + "ms")); }, timeoutMs + 300);
    });
    raced = Promise.race([httpP, guard]);
  }
  let resp;
  try {
    resp = await raced;
  } catch (e) {
    return { name: source.name, ok: false, ms: Date.now() - started, err: msgOf(e) };
  }
  const ms = Date.now() - started;
  const text = resp && resp.content !== undefined ? resp.content : (resp ? resp.body : null);
  if (!text) return { name: source.name, ok: false, ms: ms, err: "empty body" };
  let data;
  try { data = JSON.parse(String(text)); } catch (e2) {
    return { name: source.name, ok: false, ms: ms, err: "bad json: " + msgOf(e2) };
  }
  const answers = (data && data.Answer) || [];
  const ips = [];
  for (let i = 0; i < answers.length; i++) {
    const a = answers[i];
    if (a && a.type === 1 && a.data) ips.push(String(a.data));
  }
  const status = resp && (resp.statusCode !== undefined ? resp.statusCode : resp.status);
  return { name: source.name, ok: true, ms: ms, status: status == null ? null : status, ips: ips };
}

// ===================== 工具 =====================
async function sleep_ms(params) {
  try {
    const ms = clamp((params && params.ms) || 3000, 0, 120000);
    const t0 = Date.now();
    await new Promise(function (r) { setTimeout(r, ms); });
    return ok({ asked_ms: ms, wall_ms: Date.now() - t0 }, "slept " + ms + "ms");
  } catch (e) { return fail(msgOf(e)); }
}

async function doh_one(params) {
  try {
    const name = str(params && params.name).trim().toLowerCase();
    const host = str(params && params.host).trim();
    if (!host) return fail("host 不能为空");
    const src = SOURCES.filter(function (s) { return s.name === name; })[0];
    if (!src) return fail("name 必须是 alidns / tencent / google 之一");
    const timeoutMs = clamp((params && params.timeout_ms) || 8000, 500, 20000);
    const r = await queryOne(src, host, timeoutMs, true);
    return ok(r, r.ok ? "查询完成" : "查询失败");
  } catch (e) { return fail(msgOf(e)); }
}

async function doh_par(params) {
  try {
    const host = str(params && params.host).trim();
    if (!host) return fail("host 不能为空");
    const timeoutMs = clamp((params && params.timeout_ms) || 4000, 500, 20000);
    const t0 = Date.now();
    const rs = await Promise.all(SOURCES.map(function (s) { return queryOne(s, host, timeoutMs, true); }));
    const totalMs = Date.now() - t0;
    const seen = {};
    const merged = [];
    for (let i = 0; i < rs.length; i++) {
      const ips = (rs[i] && rs[i].ips) || [];
      for (let j = 0; j < ips.length; j++) {
        if (!seen[ips[j]]) { seen[ips[j]] = 1; merged.push(ips[j]); }
      }
    }
    return ok({ host: host, timeout_ms: timeoutMs, total_ms: totalMs, sources: rs, merged_ips: merged }, "并行查询完成");
  } catch (e) { return fail(msgOf(e)); }
}

async function doh_serial(params) {
  try {
    const host = str(params && params.host).trim();
    if (!host) return fail("host 不能为空");
    const timeoutMs = clamp((params && params.timeout_ms) || 8000, 500, 20000);
    const useGuard = !(params && params.guard === false);
    const t0 = Date.now();
    const rs = [];
    for (let i = 0; i < SOURCES.length; i++) {
      rs.push(await queryOne(SOURCES[i], host, timeoutMs, useGuard));
    }
    const totalMs = Date.now() - t0;
    return ok({ host: host, timeout_ms: timeoutMs, guard: useGuard, total_ms: totalMs, sources: rs }, "串行查询完成");
  } catch (e) { return fail(msgOf(e)); }
}

// ===================== 导出 =====================
exports.sleep_ms = sleep_ms;
exports.doh_one = doh_one;
exports.doh_par = doh_par;
exports.doh_serial = doh_serial;
