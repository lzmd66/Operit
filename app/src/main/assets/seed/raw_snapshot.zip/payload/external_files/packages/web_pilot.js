/*
METADATA
{
    "name": "web_pilot",
    "display_name": {
        "zh": "网页浏览助手（自研）",
        "en": "Web Pilot"
    },
    "description": {
        "zh": "自研浏览器工具集：打开 / 查看 / 点击 / 输入 / 读取普通网站。规避官方 browser 包的已知缺陷：点击走页面内 JS 路径（不触发 ref 原生点击的线程崩溃）、后退用自维护历史栈（不依赖 WebView 历史，不跳格）、快照为自研轻量格式（无样式噪声）。限制：严格 CSP 站点上注入类操作不可用（与官方包同引擎限制，等上游修复后解除）。动作延迟约 1-3 秒/步。",
        "en": "Self-made browser tools for normal sites: open/snapshot/click/type/read/back/shot. Avoids known bugs of the built-in browser package (click thread-crash, back history skip)."
    },
    "category": "Automatic",
    "tools": [
        {
            "name": "open",
            "description": {
                "zh": "打开一个网址：导航、等待渲染稳定，返回页面信息与可交互元素列表（含 wp_N 编号，用于后续 click/type_text）。",
                "en": "Open a URL and return page info plus interactive elements."
            },
            "parameters": [
                { "name": "url", "description": { "zh": "目标网址（可省略 https://）。", "en": "Target URL." }, "type": "string", "required": true },
                { "name": "wait", "description": { "zh": "可选，额外等待秒数，默认 2。", "en": "Optional extra wait seconds, default 2." }, "type": "number", "required": false }
            ]
        },
        {
            "name": "snapshot",
            "description": {
                "zh": "对当前页面生成轻量快照：可交互元素列表（wp_N 编号）+ 文本预览。点击/输入前先看这个。",
                "en": "Lightweight snapshot of the current page."
            },
            "parameters": []
        },
        {
            "name": "click",
            "description": {
                "zh": "点击元素。ref 支持三种写法：wp_N（snapshot 编号）、css=选择器、text=文本。点击后自动等待并返回新页面快照。",
                "en": "Click an element by wp_N id, css selector or text. Returns a fresh snapshot."
            },
            "parameters": [
                { "name": "ref", "description": { "zh": "目标：wp_N / css=… / text=…", "en": "Target: wp_N / css=… / text=…" }, "type": "string", "required": true },
                { "name": "wait", "description": { "zh": "可选，点击后等待秒数，默认 1.5。", "en": "Optional wait after click, default 1.5." }, "type": "number", "required": false }
            ]
        },
        {
            "name": "type_text",
            "description": {
                "zh": "向输入框/文本域输入文本（兼容常见前端框架）。submit=true 时尝试提交表单。",
                "en": "Type text into an input/textarea; optional submit."
            },
            "parameters": [
                { "name": "ref", "description": { "zh": "目标：wp_N / css=… / text=…", "en": "Target." }, "type": "string", "required": true },
                { "name": "text", "description": { "zh": "要输入的文本。", "en": "Text to type." }, "type": "string", "required": true },
                { "name": "submit", "description": { "zh": "可选，输入后是否提交（默认 false）。", "en": "Optional submit after typing." }, "type": "boolean", "required": false },
                { "name": "wait", "description": { "zh": "可选，之后等待秒数，默认 1。", "en": "Optional wait seconds." }, "type": "number", "required": false }
            ]
        },
        {
            "name": "read",
            "description": {
                "zh": "读取当前页面文本（可指定选择器与最大字数）。",
                "en": "Read page text, optional selector and max chars."
            },
            "parameters": [
                { "name": "selector", "description": { "zh": "可选，CSS 选择器限定区域。", "en": "Optional CSS selector." }, "type": "string", "required": false },
                { "name": "max_chars", "description": { "zh": "可选，最大返回字数，默认 6000。", "en": "Optional max chars, default 6000." }, "type": "number", "required": false }
            ]
        },
        {
            "name": "back",
            "description": {
                "zh": "后退到本工具记录的上一个页面（自维护历史，不依赖浏览器后退，不会跳格）。",
                "en": "Go back to the previous page (self-maintained history)."
            },
            "parameters": [
                { "name": "wait", "description": { "zh": "可选，等待秒数，默认 2。", "en": "Optional wait seconds." }, "type": "number", "required": false }
            ]
        },
        {
            "name": "shot",
            "description": {
                "zh": "对当前页面截图（视口），返回图片文件路径。",
                "en": "Take a viewport screenshot, returns the file path."
            },
            "parameters": [
                { "name": "filename", "description": { "zh": "可选，文件名。", "en": "Optional file name." }, "type": "string", "required": false }
            ]
        }
    ]
}
*/

// ===== 基础 =====
const WP_DIR = "/sdcard/Download/Operit/web_pilot";
const HISTORY_FILE = WP_DIR + "/nav_history.json";
const NAV_TIMEOUT_MS = 20000;
const WAIT_GRACE_MS = 5000;
const EVAL_TIMEOUT_MS = 15000;
const MAX_HISTORY = 60;

let memHistory = null;

function msgOf(e) { return e && e.message ? e.message : String(e); }

function raceGuard(promise, ms, label) {
    return new Promise(function (resolve, reject) {
        let done = false;
        const timer = setTimeout(function () {
            if (!done) { done = true; reject(new Error("guard-timeout " + ms + "ms" + (label ? "（" + label + "）" : ""))); }
        }, ms);
        promise.then(function (v) {
            if (!done) { done = true; clearTimeout(timer); resolve(v); }
        }, function (e) {
            if (!done) { done = true; clearTimeout(timer); reject(e); }
        });
    });
}

function extractResult(raw) {
    const text = String(raw);
    const marker = "### Result";
    const idx = text.lastIndexOf(marker);
    if (idx < 0) {
        throw new Error("浏览器返回中未找到 ### Result 段（页面可能被 CSP 拦截或未渲染完成）。返回前 300 字符: " + text.slice(0, 300));
    }
    let body = text.slice(idx + marker.length).trim();
    const nl = body.indexOf("\n### ");
    if (nl >= 0) { body = body.slice(0, nl).trim(); }
    try {
        return JSON.parse(body);
    } catch (e) {
        throw new Error("浏览器返回的结果不是合法 JSON。片段: " + body.slice(0, 300));
    }
}

async function evalInPage(code) {
    return extractResult(await raceGuard(Tools.Net.browserEvaluate({ function: code }), EVAL_TIMEOUT_MS, "browserEvaluate"));
}

async function waitSeconds(s) {
    const t = Math.max(0, Number(s) || 0);
    if (t > 0) { await raceGuard(Tools.Net.browserWaitFor({ time: t }), t * 1000 + WAIT_GRACE_MS, "wait"); }
}

// ===== 历史栈（自维护，不依赖浏览器后退） =====
async function loadHistory() {
    if (memHistory) { return memHistory; }
    try {
        const raw = await Tools.Files.read(HISTORY_FILE);
        const text = raw && raw.content !== undefined ? String(raw.content) : String(raw);
        const arr = JSON.parse(text);
        memHistory = Array.isArray(arr) ? arr : [];
    } catch (e) {
        memHistory = [];
    }
    return memHistory;
}

async function saveHistory() {
    try {
        await Tools.Files.mkdir(WP_DIR, true);
        await Tools.Files.write(HISTORY_FILE, JSON.stringify(memHistory || []), false);
    } catch (e) { }
}

async function recordVisit(url) {
    if (!url) { return; }
    const arr = await loadHistory();
    const last = arr.length ? arr[arr.length - 1] : null;
    if (last && last.url === url) {
        last.t = Date.now();
    } else {
        arr.push({ t: Date.now(), url: url });
        if (arr.length > MAX_HISTORY) { arr.splice(0, arr.length - MAX_HISTORY); }
    }
    await saveHistory();
}

async function prevUrl(current) {
    const arr = await loadHistory();
    for (let i = arr.length - 1; i >= 0; i--) {
        const u = arr[i] && arr[i].url;
        if (u && u !== current) { return u; }
    }
    return null;
}

// ===== 页面脚本 =====
const SNAP_SCRIPT = "() => { try { var out = []; var idx = 0; var all = document.querySelectorAll('a,button,input,textarea,select,[role=button],[role=link],[contenteditable=true]'); for (var i = 0; i < all.length && out.length < 120; i++) { var el = all[i]; var tag = el.tagName.toLowerCase(); var st = null; try { st = window.getComputedStyle(el); } catch (e) { st = null; } if (st && (st.display === 'none' || st.visibility === 'hidden')) { continue; } var r = el.getBoundingClientRect(); if (r.width < 2 && r.height < 2) { continue; } var type = String(el.getAttribute('type') || ''); var txt = String(el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('placeholder') || el.getAttribute('title') || (el.value !== undefined ? el.value : '') || '').replace(/\\s+/g, ' ').trim(); if (!txt && tag === 'a') { var im = el.querySelector('img'); txt = im ? String(im.getAttribute('alt') || '[img]') : ''; } if (!txt && tag !== 'input' && tag !== 'textarea' && tag !== 'select') { continue; } idx++; var wid = 'wp_' + idx; try { el.setAttribute('data-operit-wp', wid); } catch (e2) { } var href = ''; if (tag === 'a') { try { href = String(el.href || '').slice(0, 120); } catch (e3) { } } var ph = String(el.getAttribute('placeholder') || ''); out.push({ id: wid, tag: tag, type: type, text: txt.slice(0, 70), href: href, ph: ph }); } var preview = String((document.body && document.body.innerText) || '').replace(/\\s+/g, ' ').slice(0, 600); return JSON.stringify({ title: document.title, url: location.href, count: out.length, items: out, preview: preview }); } catch (e) { return JSON.stringify({ error: String(e && e.message || e) }); } }";

const SUMMARY_SCRIPT = "() => JSON.stringify({ title: document.title, url: location.href, ready: document.readyState })";

const FINDER = "if (REF.indexOf('css=') === 0) { try { el = document.querySelector(REF.slice(4)); } catch (eA) { el = null; } } else if (REF.indexOf('text=') === 0) { var want = REF.slice(5); var cands = document.querySelectorAll('a,button,[role=button],input[type=submit],input[type=button]'); for (var ci = 0; ci < cands.length; ci++) { var ct = String((cands[ci].innerText || cands[ci].value) || '').replace(/\\s+/g, ' ').trim(); if (ct === want || ct.indexOf(want) >= 0) { el = cands[ci]; break; } } } else { try { el = document.querySelector('[data-operit-wp=' + JSON.stringify(REF) + ']'); } catch (eB) { el = null; } }";

function buildClickScript(refJson) {
    return "() => { var REF = " + refJson + "; var el = null; " + FINDER + " if (!el) { return JSON.stringify({ ok: false, error: 'element_not_found' }); } try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch (e) { } try { el.focus({ preventScroll: true }); } catch (e) { } try { el.click(); } catch (e2) { return JSON.stringify({ ok: false, error: String(e2 && e2.message || e2) }); } return JSON.stringify({ ok: true, tag: el.tagName.toLowerCase(), text: String((el.innerText || el.value) || '').replace(/\\s+/g, ' ').slice(0, 60) }); }";
}

function buildTypeScript(refJson, textJson) {
    return "() => { var REF = " + refJson + "; var el = null; " + FINDER + " if (!el) { return JSON.stringify({ ok: false, error: 'element_not_found' }); } var TEXT = " + textJson + "; var tag = el.tagName.toLowerCase(); try { if (tag === 'textarea') { var ts = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value'); if (ts && ts.set) { ts.set.call(el, TEXT); } else { el.value = TEXT; } } else if (tag === 'input' || tag === 'select') { var is = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value'); if (is && is.set) { is.set.call(el, TEXT); } else { el.value = TEXT; } } else { el.textContent = TEXT; } el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); return JSON.stringify({ ok: true, value: String(el.value !== undefined ? el.value : el.textContent).slice(0, 80) }); } catch (e3) { return JSON.stringify({ ok: false, error: String(e3 && e3.message || e3) }); } }";
}

function buildSubmitScript(refJson) {
    return "() => { var REF = " + refJson + "; var el = null; " + FINDER + " if (!el) { return JSON.stringify({ ok: false, error: 'element_not_found' }); } try { el.focus({ preventScroll: true }); } catch (e) { } try { if (el.form && el.form.requestSubmit) { el.form.requestSubmit(); return JSON.stringify({ ok: true, via: 'requestSubmit' }); } } catch (e2) { } try { var ev = new KeyboardEvent('keydown', { key: 'Enter', bubbles: true, cancelable: true }); el.dispatchEvent(ev); return JSON.stringify({ ok: true, via: 'enter' }); } catch (e3) { return JSON.stringify({ ok: false, error: String(e3 && e3.message || e3) }); } }";
}

function buildReadScript(selectorJson, maxChars) {
    return "() => { var SEL = " + selectorJson + "; var MAX = " + maxChars + "; var root = null; if (SEL) { try { root = document.querySelector(SEL); } catch (e) { root = null; } if (!root) { return JSON.stringify({ error: 'selector_not_found' }); } } var node = root || document.body; var t = String((node && (node.innerText || node.textContent)) || ''); return JSON.stringify({ title: document.title, url: location.href, len: t.length, text: t.slice(0, MAX) }); }";
}

// ===== 输出格式化 =====
function formatSnapshot(snap) {
    if (!snap) { return "(未获取到页面信息)"; }
    if (snap.error) { return "快照失败: " + snap.error; }
    const lines = [];
    lines.push("页面: " + String(snap.title || ""));
    lines.push("URL: " + String(snap.url || ""));
    const items = snap.items || [];
    lines.push("可交互元素 " + items.length + " 个（id 可用于 click / type_text）:");
    for (let i = 0; i < items.length; i++) {
        const it = items[i];
        let seg = "[" + it.id + "] " + it.tag;
        if (it.type) { seg += "(" + it.type + ")"; }
        if (it.text) { seg += " \"" + it.text + "\""; }
        if (it.ph) { seg += " [placeholder=" + it.ph + "]"; }
        if (it.href) { seg += " -> " + it.href; }
        lines.push(seg);
    }
    if (snap.preview) { lines.push(""); lines.push("文本预览: " + snap.preview); }
    return lines.join("\n");
}

async function waitReady(maxSec) {
    const deadline = Date.now() + Math.max(0, maxSec || 0) * 1000;
    let last = null;
    while (Date.now() <= deadline) {
        last = await evalInPage(SUMMARY_SCRIPT);
        if (last && last.ready === 'complete') { return last; }
        await waitSeconds(1);
    }
    return last;
}

// ===== 工具实现 =====
async function open(params) {
    const rawUrl = params && params.url ? String(params.url).trim() : "";
    if (!rawUrl) { throw new Error("url 不能为空"); }
    const url = /^https?:/i.test(rawUrl) ? rawUrl : ("https://" + rawUrl);
    const wait = params && params.wait !== undefined ? Number(params.wait) : 2;
    await raceGuard(Tools.Net.browserNavigate(url), NAV_TIMEOUT_MS, "browserNavigate");
    await waitSeconds(wait);
    let sum = null;
    try { sum = await waitReady(3); } catch (e) { sum = null; }
    let snap = null;
    try { snap = await evalInPage(SNAP_SCRIPT); } catch (e2) { snap = { error: msgOf(e2) }; }
    await recordVisit((sum && sum.url) || url);
    return "已打开: " + ((sum && sum.url) || url) + "\n\n" + formatSnapshot(snap);
}

async function snapshot() {
    const snap = await evalInPage(SNAP_SCRIPT);
    return formatSnapshot(snap);
}

async function click(params) {
    const ref = params && params.ref ? String(params.ref).trim() : "";
    if (!ref) { throw new Error("ref 不能为空（支持 wp_N / css=… / text=…）"); }
    const wait = params && params.wait !== undefined ? Number(params.wait) : 1.5;
    const res = await evalInPage(buildClickScript(JSON.stringify(ref)));
    if (!res || res.ok !== true) {
        throw new Error("点击失败: " + ((res && res.error) || "unknown"));
    }
    await waitSeconds(wait);
    let sum = null;
    try { sum = await waitReady(2); } catch (e) { sum = null; }
    const lines = [];
    lines.push("已点击 [" + ref + "] " + String(res.tag || "") + (res.text ? (" \"" + res.text + "\"") : ""));
    if (sum && sum.url) {
        lines.push("当前: " + String(sum.title || "") + " — " + sum.url);
        await recordVisit(sum.url);
    }
    let snap = null;
    try { snap = await evalInPage(SNAP_SCRIPT); } catch (e2) { snap = { error: msgOf(e2) }; }
    lines.push("");
    lines.push(formatSnapshot(snap));
    return lines.join("\n");
}

async function type_text(params) {
    const ref = params && params.ref ? String(params.ref).trim() : "";
    const text = params && params.text !== undefined ? String(params.text) : "";
    if (!ref) { throw new Error("ref 不能为空"); }
    if (!text) { throw new Error("text 不能为空"); }
    const submit = !!(params && params.submit);
    const wait = params && params.wait !== undefined ? Number(params.wait) : 1;
    let beforeUrl = "";
    try { const b = await evalInPage(SUMMARY_SCRIPT); beforeUrl = (b && b.url) || ""; } catch (e0) { beforeUrl = ""; }
    const res = await evalInPage(buildTypeScript(JSON.stringify(ref), JSON.stringify(text)));
    if (!res || res.ok !== true) {
        throw new Error("输入失败: " + ((res && res.error) || "unknown"));
    }
    let submitInfo = "";
    if (submit) {
        try {
            const s = await evalInPage(buildSubmitScript(JSON.stringify(ref)));
            submitInfo = "；提交: " + ((s && s.ok) ? (s.via || "ok") : "未确认");
        } catch (e) {
            submitInfo = "；提交: 已触发（等待页面响应）";
        }
    }
    await waitSeconds(wait);
    let sum = null;
    try { sum = await waitReady(2); } catch (e2) { sum = null; }
    const afterUrl = (sum && sum.url) || "";
    if (afterUrl) { await recordVisit(afterUrl); }
    const jumped = (beforeUrl && afterUrl && beforeUrl !== afterUrl) ? "；页面已跳转" : "";
    return "已输入到 [" + ref + "]：" + res.value + submitInfo + jumped + "\n当前: " + ((sum && sum.title) || "") + " — " + afterUrl;
}

async function read(params) {
    const selector = params && params.selector ? String(params.selector) : "";
    const maxChars = params && params.max_chars !== undefined
        ? Math.max(500, Math.min(20000, Number(params.max_chars) || 6000))
        : 6000;
    const res = await evalInPage(buildReadScript(JSON.stringify(selector), maxChars));
    if (res && res.error === 'selector_not_found') {
        throw new Error("选择器未匹配到元素: " + selector);
    }
    const lines = [];
    lines.push("页面: " + String((res && res.title) || ""));
    lines.push("URL: " + String((res && res.url) || ""));
    lines.push("文本长度: " + String((res && res.len) || 0) + ((res && res.len > maxChars) ? ("（截断至 " + maxChars + "）") : ""));
    lines.push("");
    lines.push(String((res && res.text) || ""));
    return lines.join("\n");
}

async function back(params) {
    const wait = params && params.wait !== undefined ? Number(params.wait) : 2;
    let sum = null;
    try { sum = await evalInPage(SUMMARY_SCRIPT); } catch (e) { sum = null; }
    const cur = (sum && sum.url) || "";
    const prev = await prevUrl(cur);
    if (!prev) {
        throw new Error("没有可后退的历史（本工具仅记录 web_pilot 打开/点击过的页面）。可用 open 直接打开目标地址。");
    }
    await raceGuard(Tools.Net.browserNavigate(prev), NAV_TIMEOUT_MS, "browserNavigate");
    await waitSeconds(wait);
    try { await waitReady(3); } catch (e2) { }
    await recordVisit(prev);
    let snap = null;
    try { snap = await evalInPage(SNAP_SCRIPT); } catch (e3) { snap = { error: msgOf(e3) }; }
    return "已后退到: " + prev + "\n\n" + formatSnapshot(snap);
}

async function shot(params) {
    const fn = params && params.filename ? String(params.filename) : "";
    const args = { type: "jpg" };
    if (fn) { args.filename = fn; }
    const r = await raceGuard(Tools.Net.browserTakeScreenshot(args), EVAL_TIMEOUT_MS, "browserTakeScreenshot");
    const text = String(r);
    const m = text.match(/Saved screenshot to [^\s]+/);
    if (m) { return "截图完成: " + m[0].replace("Saved screenshot to ", ""); }
    return "截图完成（原始返回）: " + text.slice(0, 400);
}

exports.open = open;
exports.snapshot = snapshot;
exports.click = click;
exports.type_text = type_text;
exports.read = read;
exports.back = back;
exports.shot = shot;

exports.main = function () {
    return "web_pilot ready: open / snapshot / click / type_text / read / back / shot";
};
