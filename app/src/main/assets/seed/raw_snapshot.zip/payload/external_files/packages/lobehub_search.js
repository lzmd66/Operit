/*
METADATA
{
    "name": "lobehub_search",
    "display_name": { "zh": "LobeHub 云端搜索", "en": "LobeHub Cloud Search" },
    "category": "Search",
    "description": {
        "zh": "LobeHub 云端搜索（10 工具）：web_search 中文主力（免费，不占 metaso/tavily 额度，支持 engines/categories/time_range）；open_url 直抓目标站正文，不吃 lobehub 域阻断、实测能读 metaso 读不了的 Cloudflare 站，是读网页首选。内置熔断器：连续 2 次网络失败才武装、短路 20s（报「已熔断」= 网络阻断不是凭据问题，禁止重验凭据）；401 与业务错永不计入。网络抖动期整调用自动补跑一遍（单次预算 ≤ ~41s）。凭据 config.json + market.json 自动续期，只有 401 才需 PC 上 lh login 重迁。可选中继通道（relay.json，域被掐时自动改道）；排障先跑 status。",
        "en": "Chinese web search backed by LobeHub cloud (same engine as LobeHub built-in search). Best for Chinese queries; for English use tavily_search instead. Auto token refresh. Optional relay fallback (relay.json); run the status tool for triage.",
    },
    "enabledByDefault": true,
    "tools": [
        {
            "name": "web_search",
            "description": "LobeHub 云端搜索【快路】。query 必填；可选 engines(逗号分隔,如 brave,bing)、categories(general,news,science 等)、time_range(day/week/month/year)、limit(1-20)。返回 title/url/score/content 摘要。注意：本包依赖境外域 app.lobehub.com，网络阻断日会失败并报「已熔断」——那是网络问题不是凭据问题，转 metaso/zhipu/tavily，不要重试、不要重验凭据。",
            "parameters": [
                { "name": "query", "description": "搜索词", "type": "string", "required": true },
                { "name": "engines", "description": "搜索引擎，逗号分隔，留空用默认", "type": "string", "required": false },
                { "name": "categories", "description": "分类，逗号分隔，如 general,news", "type": "string", "required": false },
                { "name": "time_range", "description": "时间过滤: day/week/month/year", "type": "string", "required": false },
                { "name": "limit", "description": "返回条数 1-20，默认 10", "type": "number", "required": false }
            ]
        },
        {
            "name": "status",
            "description": "通道体检：一键判链路是否正常（OK / 被夹断 / 令牌坏 / 中继不通 / 上游毛病），附熔断状态、令牌到期、中继配置与一次真实探测。搜索失败或疑似阻断时先跑它，再决定转梯队还是动配置。",
            "parameters": []
        },
        {
            "name": "open_url",
            "description": "读取网页正文（OkHttp 直抓 + HTML 转文本），用于打开 web_search 返回的链接。",
            "parameters": [
                { "name": "url", "description": "绝对 http(s) 链接", "type": "string", "required": true }
            ]
        },
        {
            "name": "skill_list",
            "description": "列 LobeHub 社区 skills。source 可选 installed/market/user。",
            "parameters": [
                { "name": "source", "description": "过滤: installed/market/user，留空全部", "type": "string", "required": false }
            ]
        },
        {
            "name": "skill_search",
            "description": "按关键词搜 LobeHub 社区 skills 市场。",
            "parameters": [
                { "name": "query", "description": "搜索词", "type": "string", "required": true }
            ]
        },
        {
            "name": "skill_read",
            "description": "读 skill 全文（SKILL.md 内容），AI 可照其执行。",
            "parameters": [
                { "name": "id", "description": "skill ID，如 skl_xxx", "type": "string", "required": true }
            ]
        },
        {
            "name": "skill_resource",
            "description": "读 skill 内资源文件（README/脚本等）源码，可本地执行。",
            "parameters": [
                { "name": "id", "description": "skill ID", "type": "string", "required": true },
                { "name": "path", "description": "资源路径，如 README.md 或 scripts/xxx.py", "type": "string", "required": true }
            ]
        },
        {
            "name": "market_search",
            "description": "【找社区 skill 用这个】LobeHub 全市场搜索（33万+ skills，M2M 直连）。返回 identifier/安装量/评分/star，比 skill_search（弱召回、仅账号域）强得多。搜到后用 market_view 或 skill_read 读详情。",
            "parameters": [
                { "name": "q", "description": "搜索关键词", "type": "string", "required": true },
                { "name": "sort", "description": "排序: stars/installCount/ratingAverage/commentCount/createdAt/updatedAt/relevance，默认 installCount", "type": "string", "required": false },
                { "name": "order", "description": "asc/desc，默认 desc", "type": "string", "required": false },
                { "name": "page", "description": "页码，默认 1", "type": "number", "required": false },
                { "name": "page_size", "description": "每页条数 1-50，默认 10", "type": "number", "required": false },
                { "name": "locale", "description": "内容语言，如 zh-CN / en-US，默认 zh-CN", "type": "string", "required": false }
            ]
        },
        {
            "name": "market_view",
            "description": "读全市场任意 skill 的详情（SKILL.md 全文 + 资源清单），identifier 来自 market_search。需要用户级凭据（market.json 里配置 userRefreshToken），未迁移时明确报错。",
            "parameters": [
                { "name": "identifier", "description": "market identifier，如 anthropics-skills-pdf", "type": "string", "required": true },
                { "name": "locale", "description": "内容语言，默认 zh-CN", "type": "string", "required": false }
            ]
        },
        {
            "name": "agent_list",
            "description": "列账号下 LobeHub agents（拿 agent id/title/description/model）。",
            "parameters": [
                { "name": "limit", "description": "返回条数，默认 10", "type": "number", "required": false },
                { "name": "keyword", "description": "关键词过滤", "type": "string", "required": false }
            ]
        }
    ]
}
*/

const lobehub_searchPackage = (function () {
    const SERVER = "https://app.lobehub.com";
    const CONFIG_PATH = "/sdcard/Download/Operit/lobehub/config.json";

    // ---- 中继通道（v5, 2026-10-03 上线）：可选的反向代理出口 ----
    // 配置 /sdcard/Download/Operit/lobehub/relay.json（文件缺失/未启用 = 完全旧行为）：
    //   { "enabled": true, "mode": "fallback" | "only",
    //     "appBase": "https://relay.你的域名/app" 或 "http://192.168.x.x:8787",
    //     "marketBase": "https://relay.你的域名/market"（可省，省则 market 走直连）,
    //     "headerName": "x-relay-key"（可省）, "headerValue": "***"（可省） }
    // fallback = 第一腿直连抢开窗，网络类失败后的补跑腿改走中继；only = 全程走中继、绝不直连。
    const RELAY_CONFIG_PATH = "/sdcard/Download/Operit/lobehub/relay.json";
    let relayCfg = null;
    let relayActive = false;
    async function loadRelay() {
        // 每次都重读：Operit 可能复用包模块实例，模块级缓存会读到旧配置（2026-10-03 实测踩坑）
        relayCfg = null;
        try {
            const raw = await readText(RELAY_CONFIG_PATH);
            if (raw) {
                const o = JSON.parse(raw);
                if (o && o.enabled && o.appBase) {
                    relayCfg = {
                        mode: o.mode === "only" ? "only" : "fallback",
                        appBase: String(o.appBase).replace(/\/+$/, ""),
                        marketBase: o.marketBase ? String(o.marketBase).replace(/\/+$/, "") : null,
                        headerName: o.headerName ? String(o.headerName) : null,
                        headerValue: (o.headerValue !== undefined && o.headerValue !== null) ? String(o.headerValue) : null
                    };
                }
            }
        } catch (_) { relayCfg = null; }
        return relayCfg;
    }
    function appBaseUrl() { return (relayActive && relayCfg && relayCfg.appBase) ? relayCfg.appBase : SERVER; }
    function marketBaseUrl() { return (relayActive && relayCfg && relayCfg.marketBase) ? relayCfg.marketBase : MARKET_BASE; }
    function relayTag(msg) { return (relayActive ? "[relay] " : "") + msg; }
    function hostOf(u) {
        try { return String(u).replace(/^https?:\/\//, "").split("/")[0]; } catch (_) { return String(u); }
    }
    /** 统一请求执行器：中继启用时自动带鉴权头；失败时打 [relay] 标记（便于 status 判案）。 */
    async function execGuard(builder, label) {
        if (relayActive && relayCfg && relayCfg.headerName && relayCfg.headerValue) {
            try { builder = builder.header(relayCfg.headerName, relayCfg.headerValue); } catch (_) { }
        }
        try {
            return await raceGuard(builder.build().execute(), LOBE_HTTP_GUARD_MS, label);
        } catch (e) {
            throw new Error(relayTag((e && e.message) || String(e)));
        }
    }
    const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

    function createClient() {
        try {
            return OkHttp.newBuilder()
                .connectTimeout(9000)   // 2026-10-03: 4s→9s。实测劣化网络下 TLS 握手能把"成功请求"拖到 10.6s，4s 会误杀
                .readTimeout(20000)
                .writeTimeout(10000)
                .followRedirects(true)
                .retryOnConnectionFailure(false)
                .build();
        } catch (_) {
            return OkHttp.newClient();
        }
    }
    const client = createClient();
    const LOBE_HTTP_GUARD_MS = 20000;  // 2026-10-03: 12s→20s。实测成功样本端到端 10.6s（云端仅 4.7s，余量被劣化 TLS 握手吃掉），12s 会误杀

    // ---- 网络抖动补跳（2026-10-03 v4：开窗期调用级自动补跑）----
    // 背景：域阻断呈分钟级"开窗/关窗"，窗口内成功样本 1.9~10.6s，窗口外必挂。
    // 抖动期单遍命中率约 30~50%；整调用自动补跑一遍，把命中率抬到 ~50~75%（单次预算 ≤ ~41s）。
    const LOBE_RETRY_MAX = 2;            // 同一操作最多自动跑 2 遍（1 主力 + 1 补跑）
    const LOBE_RETRY_DELAY_MS = 1000;    // 两遍之间停 1s，避免毫秒级连撞同一堵墙

    // ---- 熔断器（2026-10-03 v3：连续失败才熔断 + 状态落文件）----
    // 为什么不是"一次失败就熔"：抖动窗口是秒级，实测成功率 1/6；一次误杀就把本来 10 秒能成的查询封成 45 秒不可用，是净亏。
    // 为什么状态必须落文件：实测 Operit 沙盒每次工具调用都是全新模块上下文（内存版熔断第 2 次调用仍等满 12s）。
    const BREAKER_COOLDOWN_MS = 20000;      // 熔断后冷却 20s（抖动是秒级，45s 过长）
    const BREAKER_FAIL_THRESHOLD = 2;       // 连续失败 2 次才熔断
    const BREAKER_FAIL_WINDOW_MS = 60000;   // 失败计数有效期：超过 60s 的旧失败不算"连续"
    const BREAKER_STATE_PATH = "/sdcard/Download/Operit/lobehub/breaker.json";
    const BREAKER_KEYS = ["guard-timeout", "connect timed out", "failed to connect", "und_err_connect_timeout",
        "handshake", "sslv3_alert", "network is unreachable", "unable to resolve host", "enotfound",
        "etimedout", "connection reset", "stream reset", "epipe", "ehostunreach", "enetunreach", "timeout"];
    async function readBreaker() {
        try {
            const raw = await readText(BREAKER_STATE_PATH);
            if (!raw) return { until: 0, reason: "", fails: 0, failAt: 0 };
            const o = JSON.parse(raw);
            return {
                until: Number(o.until) || 0, reason: String(o.reason || ""),
                fails: Number(o.fails) || 0, failAt: Number(o.failAt) || 0
            };
        } catch (_) { return { until: 0, reason: "", fails: 0, failAt: 0 }; }
    }
    async function writeBreaker(st) {
        try { await writeText(BREAKER_STATE_PATH, JSON.stringify(st)); } catch (_) { }
    }
    function isAuthError(msg) {
        return msg.indexOf("401") >= 0 || msg.indexOf("认证失效") >= 0;
    }
    function isNetError(msg) {
        const low = msg.toLowerCase();
        for (let i = 0; i < BREAKER_KEYS.length; i++) { if (low.indexOf(BREAKER_KEYS[i]) >= 0) return true; }
        return false;
    }
    async function breakerCheck() {
        const st = await readBreaker();
        const left = st.until - Date.now();
        if (left > 0) {
            throw new Error("已熔断（" + Math.ceil(left / 1000) + "s 后放行）：" + st.reason +
                " —— 网络层阻断，非凭据问题，勿重验凭据；按 search-routing 转 metaso/zhipu/tavily");
        }
    }
    async function breakerTrip(err) {
        const msg = String((err && err.message) || err || "");
        if (isAuthError(msg) || !isNetError(msg)) return;  // 鉴权/业务错误不计入熔断
        const now = Date.now();
        const st = await readBreaker();
        const fails = (st.fails && (now - st.failAt) <= BREAKER_FAIL_WINDOW_MS) ? st.fails + 1 : 1;
        const next = { until: st.until, reason: st.reason, fails: fails, failAt: now };
        if (fails >= BREAKER_FAIL_THRESHOLD) {
            next.until = now + BREAKER_COOLDOWN_MS;
            next.reason = msg.slice(0, 120);
            next.fails = 0;
        }
        await writeBreaker(next);
    }
    function withBreaker(name, fn) {
        return async function (params) {
            await breakerCheck();
            try {
                const r = await fn(params);
                const st = await readBreaker();
                // 成功即清零：连续计数与残余冷却都不留
                if (st.until || st.fails) await writeBreaker({ until: 0, reason: "", fails: 0, failAt: 0 });
                return r;
            } catch (e) {
                await breakerTrip(e);
                throw e;
            }
        };
    }

    /** 给任意 Promise 加自守卫超时：到点即以 Error 拒绝，防止宿主层 timeout 参数不生效导致无限挂起。 */
    function raceGuard(promise, ms, label) {
        return new Promise(function (resolve, reject) {
            let done = false;
            const timer = setTimeout(function () {
                if (!done) { done = true; reject(new Error("guard-timeout " + ms + "ms" + (label ? "（" + label + "）" : ""))); }
            }, ms);
            promise.then(function (v) {
                if (!done) { done = true; clearTimeout(timer); resolve(v); }
            }, function (e) {
                if (!done) { done = true; clearTimeout(timer); reject(e); }
            });
        });
    }

        /** 网络抖动补跳（工具级）：整个调用失败且属网络类错误时，自动补跑一遍（共最多 LOBE_RETRY_MAX 遍）。
     *  鉴权/业务错误不补跳；熔断器在更外层 withBreaker，天然按"调用"计一次，不受补跳影响。 */
    function withNetRetry(name, fn) {
        return async function (params) {
            await loadRelay();
            relayActive = !!(relayCfg && relayCfg.mode === "only"); // only 模式全程走中继
            let lastErr = null;
            for (let attempt = 0; attempt < LOBE_RETRY_MAX; attempt++) {
                try {
                    return await fn(params);
                } catch (e) {
                    lastErr = e;
                    const msg = String((e && e.message) || e || "");
                    if (!isNetError(msg)) throw e;   // 401/业务错不补跳
                    if (attempt < LOBE_RETRY_MAX - 1) {
                        if (relayCfg && !relayActive) relayActive = true; // 补跑腿改走中继（若已配置）
                        await new Promise(function (res) { setTimeout(res, LOBE_RETRY_DELAY_MS); });
                    }
                }
            }
            throw lastErr;
        };
    }

    // ---- 文件读写（多签名兼容） ----
    async function readText(path) {
        try {
            let r = await Tools.Files.read({ path: path, environment: "android" });
            if (typeof r === "string") return r;
            if (r && typeof r.content === "string") return r.content;
            if (r && typeof r.data === "string") return r.data;
        } catch (e1) {
            const r2 = await Tools.Files.read(path);
            if (typeof r2 === "string") return r2;
            if (r2 && typeof r2.content === "string") return r2.content;
        }
        return "";
    }
    async function writeText(path, text) {
        try {
            await Tools.Files.write(path, String(text), false, "android");
            return true;
        } catch (e1) {
            try { await Tools.Files.write(path, String(text), false); return true; }
            catch (e2) { return false; }
        }
    }

    // ---- 认证：读配置 + 过期自动续期 ----
    let cachedToken = null;
    let cachedExpiry = 0;

    async function loadConfig() {
        const raw = await readText(CONFIG_PATH);
        if (!raw) throw new Error("缺少凭据文件 " + CONFIG_PATH + "，请先从电脑端迁移 credentials");
        return JSON.parse(raw);
    }
    async function saveConfig(cfg) {
        await writeText(CONFIG_PATH, JSON.stringify(cfg, null, 2));
    }

    async function refreshToken(refreshToken) {
        const req = client.newRequest()
            .url(appBaseUrl() + "/oidc/token")
            .method("POST")
            .body({ client_id: "lobehub-cli", grant_type: "refresh_token", refresh_token: refreshToken }, "form");
        const response = await execGuard(req, "OkHttp");
        const content = String(response && response.content || "");
        if (!response.isSuccessful()) throw new Error(relayTag("token 刷新失败 HTTP " + response.statusCode + ": " + content.slice(0, 200)));
        const j = JSON.parse(content);
        return { accessToken: j.access_token, refreshToken: j.refresh_token || refreshToken, expiresAt: j.expires_in ? Math.floor(Date.now() / 1000) + j.expires_in : 0 };
    }

    async function getToken() {
        const now = Math.floor(Date.now() / 1000);
        if (cachedToken && cachedExpiry - 120 > now) return cachedToken;
        const cfg = await loadConfig();
        if (cfg.accessToken && cfg.expiresAt - 120 > now) {
            cachedToken = cfg.accessToken; cachedExpiry = cfg.expiresAt;
            return cachedToken;
        }
        if (!cfg.refreshToken) throw new Error("凭据无 refresh_token，需重新从电脑端迁移或 lh login");
        const fresh = await refreshToken(cfg.refreshToken);
        cfg.accessToken = fresh.accessToken;
        cfg.refreshToken = fresh.refreshToken;
        cfg.expiresAt = fresh.expiresAt;
        await saveConfig(cfg);
        cachedToken = fresh.accessToken; cachedExpiry = fresh.expiresAt;
        return cachedToken;
    }

    // ---- SuperJSON 响应解包 ----
    function unwrap(j) {
        if (j && j.result && j.result.data) {
            const d = j.result.data;
            return (d.json !== undefined) ? d.json : d;
        }
        if (j && j.error) {
            const e = j.error.json || j.error;
            throw new Error("LobeHub API 错误: " + (e.message || JSON.stringify(e).slice(0, 200)));
        }
        return j;
    }

    // ---- web_search ----
    async function web_search(params) {
        params = params || {};
        const query = String(params.query || "").trim();
        if (!query) throw new Error("缺少 query 参数");

        const inner = { query: query };
        // 2026-10-02 修复：云端 zod 要求 array，旧代码传 join(",") 的字符串 → 一传就 400。
        // engines / categories 此前从未真正生效过。现统一转成字符串数组。
        const toArr = function (v) {
            if (Array.isArray(v)) return v.map(function (x) { return String(x).trim(); }).filter(Boolean);
            return String(v || '').split(",").map(function (x) { return x.trim(); }).filter(Boolean);
        };
        if (params.engines) {
            var engArr = toArr(params.engines);
            if (engArr.length) inner.searchEngines = engArr;
        }
        if (params.categories) {
            var catArr = toArr(params.categories);
            if (catArr.length) inner.searchCategories = catArr;
        }
        const tr = ["day", "week", "month", "year"];
        if (params.time_range && tr.indexOf(params.time_range) >= 0) inner.searchTimeRange = params.time_range;

        const input = encodeURIComponent(JSON.stringify({ json: inner }));
        const token = await getToken();
        const response = await execGuard(client.newRequest()
            .url(appBaseUrl() + "/trpc/tools/search.webSearch?input=" + input)
            .method("GET")
            .header("Oidc-Auth", token)
            .header("User-Agent", UA), "OkHttp");
        const content = String(response && response.content || "");
        if (response.statusCode === 401) throw new Error("认证失效(401)，refresh_token 可能已过期，需重新迁移凭据");
        if (!response.isSuccessful()) throw new Error(relayTag("HTTP " + response.statusCode + ": " + content.slice(0, 200)));

        const data = unwrap(JSON.parse(content));
        const results = (data && data.results) || [];
        const limit = Math.max(1, Math.min(20, Number(params.limit) || 10));
        const items = results.slice(0, limit).map(function (r) {
            return {
                title: String(r.title || "").slice(0, 200),
                url: String(r.url || ""),
                score: (r.score === null || r.score === undefined) ? null : Number(r.score),
                snippet: String(r.content || "").slice(0, 300)
            };
        });
        return {
            success: true,
            query: query,
            total: (data && data.resultNumbers) || results.length,
            costTime: (data && data.costTime) || null,
            results: items
        };
    }

    // ---- open_url：直抓 + HTML 转文本 ----
    // SSRF 防护：拒绝环回/内网/链路本地/单标签内网主机
    function isPrivateTarget(url) {
        let host = "";
        try {
            const rest = url.split("://")[1] || "";
            host = (rest.split("/")[0].split("?")[0].split("@").pop() || "").toLowerCase();
        } catch (e) { return true; }
        if (host.indexOf("[") === 0) return true; // IPv6 字面量一律拒绝（含 ::1/fe80/fd00 等内网形态）
        host = host.split(":")[0];
        if (!host) return true;
        if (host === "localhost" || host.indexOf(".localhost") >= 0 || host.indexOf(".local") >= 0 || host.endsWith(".internal")) return true;
        if (host.indexOf(".") < 0) return true; // 单标签主机名，无法公网解析
        const m = host.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
        if (m) {
            const a = +m[1], b = +m[2];
            if (a === 0 || a === 10 || a === 127 || a >= 224) return true;
            if (a === 172 && b >= 16 && b <= 31) return true;
            if (a === 192 && b === 168) return true;
            if (a === 169 && b === 254) return true;
            if (a === 100 && b >= 64 && b <= 127) return true; // CGNAT
        }
        return false;
    }

    function htmlToText(html) {
        return String(html)
            .replace(/<!--[\s\S]*?-->/g, " ")
            .replace(/<(script|style|noscript|svg|iframe)[\s\S]*?<\/\1>/gi, " ")
            .replace(/<\/(p|div|li|tr|h[1-6]|section|article|blockquote)>/gi, "\n")
            .replace(/<br\s*\/?>/gi, "\n")
            .replace(/<[^>]+>/g, " ")
            .replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&").replace(/&lt;/gi, "<")
            .replace(/&gt;/gi, ">").replace(/"/gi, '"').replace(/&#0?39;/g, "'")
            .replace(/[ \t]+/g, " ")
            .replace(/\n\s*\n\s*\n+/g, "\n\n")
            .trim();
    }

    async function open_url(params) {
        params = params || {};
        const url = String(params.url || "").trim();
        if (!/^https?:\/\//i.test(url)) throw new Error("需要绝对 http(s) URL");
        if (isPrivateTarget(url)) throw new Error("已拒绝：禁止访问环回/内网/链路本地地址（SSRF 防护）");

        const response = await raceGuard((client.newRequest()
            .url(url)
            .method("GET")
            .header("User-Agent", UA)
            .header("Accept", "text/html,application/xhtml+xml,*/*;q=0.8")
            .header("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8")
            .build()
            .execute()), LOBE_HTTP_GUARD_MS, "OkHttp");
        const content = String(response && response.content || "");
        if (!response.isSuccessful()) throw new Error("HTTP " + response.statusCode + " from " + url);
        const ct = (response.header && response.header("Content-Type")) || "";
        if (ct.indexOf("json") >= 0) return { success: true, url: url, content: content.slice(0, 100000) };
        const text = htmlToText(content);
        if (text.length < 80) throw new Error("正文提取过短(" + text.length + " 字符)，页面可能是 JS 渲染，无法读取");
        const titleMatch = content.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
        const title = titleMatch ? titleMatch[1].trim() : "";
        return { success: true, url: url, title: title, content: (title ? title + "\n\n" : "") + text.slice(0, 100000) };
    }

    // ---- LobeHub 社区：tRPC lambda GET 通用调用 ----
    async function trpcGet(proc, input) {
        const token2 = await getToken();
        const url2 = appBaseUrl() + "/trpc/lambda/" + proc + "?input=" + encodeURIComponent(JSON.stringify({ json: input }));
        const resp = await execGuard(client.newRequest()
            .url(url2)
            .method("GET")
            .header("Oidc-Auth", token2)
            .header("User-Agent", UA), "OkHttp");
        const content2 = String(resp && resp.content || "");
        if (resp.statusCode === 401) throw new Error("认证失效(401)，refresh_token 可能已过期，需重新迁移凭据");
        if (!resp.isSuccessful()) throw new Error(relayTag("HTTP " + resp.statusCode + " on " + proc + ": " + content2.slice(0, 200)));
        const j = JSON.parse(content2);
        if (j && j.error) {
            const e = j.error.json || j.error;
            throw new Error(proc + " 错误: " + (e.message || JSON.stringify(e).slice(0, 200)));
        }
        const data = j && j.result && j.result.data ? j.result.data : j;
        return (data && data.json !== undefined) ? data.json : data;
    }
    function arrOf(x, key) {
        if (Array.isArray(x)) return x;
        if (x && Array.isArray(x.data)) return x.data;
        if (x && key && Array.isArray(x[key])) return x[key];
        return [];
    }

    async function skill_list(params) {
        params = params || {};
        const src = ["installed", "market", "user"].indexOf(params.source) >= 0 ? params.source : null;
        const input = src ? { source: src } : {};
        const items = arrOf(await trpcGet("agentSkills.list", input));
        return {
            success: true,
            count: items.length,
            skills: items.slice(0, 60).map(function (s) {
                return { id: s.id, name: s.name, identifier: s.identifier, source: s.source, description: String(s.description || "").slice(0, 150) };
            })
        };
    }

    async function skill_search(params) {
        params = params || {};
        const q = String(params.query || "").trim();
        if (!q) throw new Error("缺少 query 参数");
        const items = arrOf(await trpcGet("agentSkills.search", { query: q }));
        return {
            success: true,
            count: items.length,
            skills: items.slice(0, 15).map(function (s) {
                return { id: s.id, name: s.name, identifier: s.identifier, source: s.source, description: String(s.description || "").slice(0, 150) };
            })
        };
    }

    async function skill_read(params) {
        params = params || {};
        const id = String(params.id || "").trim();
        if (!id) throw new Error("缺少 id 参数");
        const s = await trpcGet("agentSkills.getById", { id: id });
        if (!s) throw new Error("Skill 不存在: " + id);
        return {
            success: true,
            id: s.id,
            name: s.name,
            identifier: s.identifier,
            source: s.source,
            description: s.description,
            content: String(s.content || "").slice(0, 60000)
        };
    }

    async function skill_resource(params) {
        params = params || {};
        const id = String(params.id || "").trim();
        const p = String(params.path || "").trim();
        if (!id || !p) throw new Error("需要 id 和 path 参数");
        const r = await trpcGet("agentSkills.readResource", { id: id, path: p });
        const txt = typeof r === "string" ? r : (r && (r.content || r.text)) || JSON.stringify(r);
        return { success: true, id: id, path: p, content: String(txt).slice(0, 60000) };
    }

    async function agent_list(params) {
        params = params || {};
        const input = { limit: Math.max(1, Math.min(50, Number(params.limit) || 10)) };
        if (params.keyword) input.keyword = String(params.keyword);
        const r = await trpcGet("agent.queryAgents", input);
        const items = Array.isArray(r) ? r : ((r && r.items) || []);
        return {
            success: true,
            count: items.length,
            agents: items.slice(0, input.limit).map(function (a) {
                const meta = a.meta || {};
                return {
                    id: a.id || a.agentId,
                    title: a.title || a.name || meta.title,
                    description: String(a.description || meta.description || "").slice(0, 150),
                    model: a.model
                };
            })
        };
    }

    // ==================== LobeHub Market（全市场 33万+ skills）====================
    // M2M 直连：HS256 签 JWT（clientSecret 密钥）→ POST /oidc/token (client_credentials)
    // → Bearer 调 /api/v1/skills*。凭据在 /sdcard/Download/Operit/lobehub/market.json
    // （PC lhm register 迁移而来，红线文件，不外发不进聊天）。
    const MARKET_BASE = "https://market.lobehub.com";
    const MARKET_CONFIG_PATH = "/sdcard/Download/Operit/lobehub/market.json";
    let m2mToken = null, m2mExpiry = 0;      // ms 时间戳
    let marketUserToken = null, marketUserExpiry = 0;

    // ---- 纯 JS SHA-256（沙盒无 crypto 依赖）----
    var SHA_K = [
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
    ];
    function rotr(x, n) { return (x >>> n) | (x << (32 - n)); }
    function sha256(bytes) {
        var H = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];
        var len = bytes.length;
        var bitLenHi = Math.floor(len / 0x20000000);
        var bitLenLo = (len << 3) >>> 0;
        var padded = bytes.slice();
        padded.push(0x80);
        while (padded.length % 64 !== 56) padded.push(0);
        for (var i = 0; i < 4; i++) padded.push((bitLenHi >>> (24 - i * 8)) & 0xff);
        for (i = 0; i < 4; i++) padded.push((bitLenLo >>> (24 - i * 8)) & 0xff);
        var w = new Array(64);
        for (var off = 0; off < padded.length; off += 64) {
            for (i = 0; i < 16; i++) {
                w[i] = ((padded[off + i * 4] << 24) | (padded[off + i * 4 + 1] << 16) | (padded[off + i * 4 + 2] << 8) | padded[off + i * 4 + 3]) >>> 0;
            }
            for (i = 16; i < 64; i++) {
                var s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >>> 3);
                var s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >>> 10);
                w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0;
            }
            var a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
            for (i = 0; i < 64; i++) {
                var S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
                var ch = (e & f) ^ (~e & g);
                var t1 = (h + S1 + ch + SHA_K[i] + w[i]) >>> 0;
                var S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
                var mj = (a & b) ^ (a & c) ^ (b & c);
                var t2 = (S0 + mj) >>> 0;
                h = g; g = f; f = e; e = (d + t1) >>> 0;
                d = c; c = b; b = a; a = (t1 + t2) >>> 0;
            }
            H[0] = (H[0] + a) >>> 0; H[1] = (H[1] + b) >>> 0; H[2] = (H[2] + c) >>> 0; H[3] = (H[3] + d) >>> 0;
            H[4] = (H[4] + e) >>> 0; H[5] = (H[5] + f) >>> 0; H[6] = (H[6] + g) >>> 0; H[7] = (H[7] + h) >>> 0;
        }
        var out = [];
        for (i = 0; i < 8; i++) {
            out.push((H[i] >>> 24) & 0xff, (H[i] >>> 16) & 0xff, (H[i] >>> 8) & 0xff, H[i] & 0xff);
        }
        return out;
    }
    function utf8Bytes(s) {
        var u = unescape(encodeURIComponent(s));
        var out = [];
        for (var i = 0; i < u.length; i++) out.push(u.charCodeAt(i) & 0xff);
        return out;
    }
    function hmacSha256(keyBytes, msgBytes) {
        var k = keyBytes.slice();
        if (k.length > 64) k = sha256(k);
        while (k.length < 64) k.push(0);
        var ipad = [], opad = [];
        for (var i = 0; i < 64; i++) {
            ipad.push(k[i] ^ 0x36);
            opad.push(k[i] ^ 0x5c);
        }
        var inner = sha256(ipad.concat(msgBytes));
        return sha256(opad.concat(inner));
    }
    function b64urlFromBytes(bytes) {
        var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
        var out = "";
        var len = bytes.length;
        for (var i = 0; i < len; i += 3) {
            var b0 = bytes[i];
            var b1 = i + 1 < len ? bytes[i + 1] : 0;
            var b2 = i + 2 < len ? bytes[i + 2] : 0;
            out += chars[b0 >> 2];
            out += chars[((b0 & 3) << 4) | (b1 >> 4)];
            if (i + 1 < len) out += chars[((b1 & 15) << 2) | (b2 >> 6)];
            if (i + 2 < len) out += chars[b2 & 63];
        }
        return out; // JWT base64url 不带 padding
    }
    function uuidV4() {
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
            var r = Math.floor(Math.random() * 16);
            return (c === "x" ? r : (r & 3) | 8).toString(16);
        });
    }

    async function loadMarketConfig() {
        const raw = await readText(MARKET_CONFIG_PATH);
        if (!raw) throw new Error("缺少市场凭据 " + MARKET_CONFIG_PATH + "（含 clientId/clientSecret），需从 PC 的 ~/.lobehub-market/credentials.json 迁移");
        const cfg = JSON.parse(raw);
        if (!cfg.clientId || !cfg.clientSecret) throw new Error("market.json 缺少 clientId/clientSecret，请重新迁移 M2M 凭据");
        return cfg;
    }

    async function getM2MToken() {
        const now = Date.now();
        if (m2mToken && m2mExpiry - 60000 > now) return m2mToken;
        const cfg = await loadMarketConfig();
        // aud 固定用规范域名（服务端按 canonical 校验）；POST 目标可能经中继。
        const canonTokenEndpoint = MARKET_BASE + "/oauth/token";
        const tokenEndpoint = marketBaseUrl() + "/oauth/token";
        var header = b64urlFromBytes(utf8Bytes(JSON.stringify({ alg: "HS256", typ: "JWT" })));
        var nowSec = Math.floor(now / 1000);
        var payload = b64urlFromBytes(utf8Bytes(JSON.stringify({
            iss: cfg.clientId, sub: cfg.clientId, aud: canonTokenEndpoint,
            jti: uuidV4(), iat: nowSec, exp: nowSec + 300
        })));
        var sig = b64urlFromBytes(hmacSha256(utf8Bytes(cfg.clientSecret), utf8Bytes(header + "." + payload)));
        var assertion = header + "." + payload + "." + sig;

        const response = await execGuard(client.newRequest()
            .url(tokenEndpoint)
            .method("POST")
            .body({ grant_type: "client_credentials", client_assertion_type: "urn:ietf:params:oauth:client-assertion-type:jwt-bearer", client_assertion: assertion }, "form"), "OkHttp");
        const content = String(response && response.content || "");
        if (!response.isSuccessful()) throw new Error(relayTag("M2M token 获取失败 HTTP " + response.statusCode + ": " + content.slice(0, 200)));
        const j = JSON.parse(content);
        if (!j.access_token) throw new Error("M2M token 响应缺少 access_token: " + content.slice(0, 200));
        m2mToken = j.access_token;
        m2mExpiry = now + ((j.expires_in || 3600) - 120) * 1000;
        return m2mToken;
    }

    async function getMarketUserToken() {
        const now = Date.now();
        if (marketUserToken && marketUserExpiry - 60000 > now) return marketUserToken;
        const cfg = await loadMarketConfig();
        if (!cfg.userRefreshToken) throw new Error("market_view 需要用户级凭据：market.json 缺 userRefreshToken。请在 PC 完成 lhm login 后迁移（AI 走局域网传 market.json，不进聊天）");
        const response = await execGuard(client.newRequest()
            .url(marketBaseUrl() + "/lobehub-oidc/token")
            .method("POST")
            .header("Content-Type", "application/x-www-form-urlencoded")
            .body({ grant_type: "refresh_token", client_id: "lobehub-cli", refresh_token: cfg.userRefreshToken }, "form"), "OkHttp");
        const content = String(response && response.content || "");
        if (!response.isSuccessful()) throw new Error(relayTag("market 用户 token 刷新失败 HTTP " + response.statusCode + "（refresh_token 可能失效，需 PC 重新 lhm login）: " + content.slice(0, 200)));
        const j = JSON.parse(content);
        if (!j.access_token) throw new Error("market 用户 token 响应异常: " + content.slice(0, 200));
        marketUserToken = j.access_token;
        marketUserExpiry = now + ((j.expires_in || 3600) - 120) * 1000;
        if (j.refresh_token && j.refresh_token !== cfg.userRefreshToken) {
            cfg.userRefreshToken = j.refresh_token;
            await writeText(MARKET_CONFIG_PATH, JSON.stringify(cfg, null, 2));
        }
        return marketUserToken;
    }

    async function marketRequest(pathAndQuery, bearerToken) {
        const response = await execGuard(client.newRequest()
            .url(marketBaseUrl() + pathAndQuery)
            .method("GET")
            .header("Authorization", "Bearer " + bearerToken)
            .header("User-Agent", UA), "OkHttp");
        const content = String(response && response.content || "");
        if (!response.isSuccessful()) {
            var err = null;
            try { err = JSON.parse(content); } catch (_) { }
            throw new Error(relayTag("market API HTTP " + response.statusCode + ": " + (err && err.error ? err.error + " - " + (err.error_description || "") : content.slice(0, 200))));
        }
        return JSON.parse(content);
    }

    async function market_search(params) {
        params = params || {};
        const q = String(params.q || "").trim();
        if (!q) throw new Error("缺少 q 参数");
        var sortOk = ["createdAt", "stars", "installCount", "name", "relevance", "ratingAverage", "commentCount", "updatedAt"];
        var sort = sortOk.indexOf(params.sort) >= 0 ? params.sort : "installCount";
        var order = params.order === "asc" ? "asc" : "desc";
        var page = Math.max(1, Number(params.page) || 1);
        var pageSize = Math.max(1, Math.min(50, Number(params.page_size) || 10));
        var locale = params.locale ? encodeURIComponent(String(params.locale)) : "zh-CN";
        var qs = "q=" + encodeURIComponent(q) + "&sort=" + sort + "&order=" + order + "&page=" + page + "&pageSize=" + pageSize + "&locale=" + locale;
        const token = await getM2MToken();
        const data = await marketRequest("/api/v1/skills?" + qs, token);
        var items = (data.items || []).map(function (s) {
            return {
                identifier: s.identifier,
                name: s.name,
                author: s.author,
                description: String(s.description || "").slice(0, 300),
                category: s.category,
                stars: s.github && s.github.stars,
                installs: s.installCount,
                rating: s.ratingAvg,
                ratingCount: s.ratingCount,
                featured: !!s.isFeatured,
                updatedAt: s.updatedAt
            };
        });
        return { total: data.totalCount, page: data.currentPage, totalPages: data.totalPages, items: items };
    }

    async function market_view(params) {
        params = params || {};
        const id = String(params.identifier || "").trim();
        if (!id) throw new Error("缺少 identifier 参数（从 market_search 结果里拿）");
        var locale = params.locale ? encodeURIComponent(String(params.locale)) : "zh-CN";
        const token = await getMarketUserToken();
        const d = await marketRequest("/api/v1/skills/" + encodeURIComponent(id) + "?locale=" + locale, token);
        var resources = d.resources && typeof d.resources === "object" ? Object.keys(d.resources) : (Array.isArray(d.resources) ? d.resources : undefined);
        return {
            identifier: d.identifier,
            name: d.name,
            author: d.author,
            version: d.version,
            description: String(d.description || "").slice(0, 1000),
            homepage: d.homepage,
            license: d.license,
            content: d.content ? String(d.content).slice(0, 100000) : undefined,
            resources: resources,
            installs: d.installCount,
            rating: d.ratingAvg
        };
    }

    // ---- status：通道体检（只读诊断 + 一次真实探测；不占熔断计数） ----
    async function status() {
        const out = {
            verdict: null,
            time: new Date().toISOString(),
            tokenExpiresAt: null, tokenExpiresInHours: null,
            breaker: null, relay: null, probe: null, hint: null
        };
        try {
            const cfg = await loadConfig();
            out.tokenExpiresAt = cfg.expiresAt ? new Date(cfg.expiresAt * 1000).toISOString() : null;
            out.tokenExpiresInHours = cfg.expiresAt ? Math.round((cfg.expiresAt * 1000 - Date.now()) / 36e5) : null;
        } catch (e) {
            out.verdict = "TOKEN_MISSING";
            out.hint = "缺少凭据文件 " + CONFIG_PATH + "：" + e.message;
            return out;
        }
        const st = await readBreaker();
        out.breaker = { until: st.until || 0, remainingSeconds: Math.max(0, Math.ceil(((st.until || 0) - Date.now()) / 1000)), reason: st.reason || "" };
        await loadRelay();
        out.relay = relayCfg
            ? { configured: true, mode: relayCfg.mode, appBase: hostOf(relayCfg.appBase), marketBase: relayCfg.marketBase ? hostOf(relayCfg.marketBase) : null }
            : { configured: false };

        // 探测：模仿真实调用——直连优先，网络类失败且配了中继则改道重试一次
        relayActive = !!(relayCfg && relayCfg.mode === "only");
        const t0 = Date.now();
        let firstErr = null;
        for (let attempt = 0; attempt < 2; attempt++) {
            try {
                const r = await web_search({ query: "connectivity probe", limit: 1 });
                out.probe = { ok: true, ms: Date.now() - t0, results: (r.results || []).length, via: relayActive ? "relay" : "direct" };
                if (firstErr) out.probe.firstError = firstErr;
                break;
            } catch (e) {
                const msg = String((e && e.message) || e);
                if (attempt === 0 && isNetError(msg) && relayCfg && !relayActive) {
                    firstErr = msg.slice(0, 140);
                    relayActive = true;
                    continue;
                }
                out.probe = { ok: false, ms: Date.now() - t0, error: msg.slice(0, 300), via: relayActive ? "relay" : "direct" };
                if (firstErr) out.probe.firstError = firstErr;
                break;
            }
        }

        const p = out.probe || {};
        const emsg = String(p.error || "");
        if (p.ok && p.results > 0) {
            out.verdict = "OK";
            out.hint = "链路正常（" + (p.via === "relay" ? "经中继" : "直连") + "）。";
        } else if (p.ok) {
            out.verdict = "OK_BUT_EMPTY";
            out.hint = "链路与令牌都正常，本次探测没返回结果（服务端波动），可直接重试。";
        } else if (isAuthError(emsg)) {
            out.verdict = "TOKEN_INVALID";
            out.hint = "令牌被拒且刷新未救回：多为 refresh_token 在别处被轮换或授权被撤。需从 PC 重新迁移凭据。";
        } else if (emsg.indexOf("[relay]") >= 0) {
            out.verdict = "RELAY_BROKEN";
            out.hint = "经中继失败：" + emsg + " —— 检查中继端（PC 是否开机/脚本是否在跑/域名与 key 是否正确），别动凭据。";
        } else if (isNetError(emsg)) {
            out.verdict = "NETWORK_BLOCKED";
            out.hint = "长时间无响应/握手失败 = 域被掐。转 metaso/zhipu/tavily；或启用中继（relay.json）/开 VPN（覆盖卓易通）。别重验凭据。";
        } else if (/HTTP \d/.test(emsg)) {
            out.verdict = "UPSTREAM_ERROR";
            out.hint = "上游返回错误：" + emsg.slice(0, 160) + "，稍后重试。";
        } else {
            out.verdict = "UNKNOWN";
            out.hint = emsg.slice(0, 200) || "未知失败；先确认手机有网。";
        }
        return out;
    }

    // ---- 冒烟测试 ----
    async function test() {
        // 走 api（已包熔断器），保证测试调用也参与熔断统计
        const r = await api.web_search({ query: "LobeHub", limit: 3 });
        var marketNote = "skipped";
        try {
            const m = await api.market_search({ q: "pdf", page_size: 1 });
            marketNote = "ok, total=" + m.total;
        } catch (e) { marketNote = "fail: " + e.message; }
        var relayNote = "off";
        try { await loadRelay(); if (relayCfg) relayNote = relayCfg.mode + " @ " + hostOf(relayCfg.appBase); } catch (_) { }
        return { success: true, total: r.total, costTime: r.costTime, first: r.results.length ? r.results[0].title : null, market: marketNote, relay: relayNote };
    }

    // ---- 对外接口：统一挂上熔断器 ----
    const api = {
        web_search: withBreaker("web_search", withNetRetry("web_search", web_search)),
        open_url: withBreaker("open_url", withNetRetry("open_url", open_url)),
        skill_list: withBreaker("skill_list", withNetRetry("skill_list", skill_list)),
        skill_search: withBreaker("skill_search", withNetRetry("skill_search", skill_search)),
        skill_read: withBreaker("skill_read", withNetRetry("skill_read", skill_read)),
        skill_resource: withBreaker("skill_resource", withNetRetry("skill_resource", skill_resource)),
        agent_list: withBreaker("agent_list", withNetRetry("agent_list", agent_list)),
        market_search: withBreaker("market_search", withNetRetry("market_search", market_search)),
        market_view: withBreaker("market_view", withNetRetry("market_view", market_view)),
        status: status,
        test: test
    };
    return api;
})();

exports.web_search = lobehub_searchPackage.web_search;
exports.open_url = lobehub_searchPackage.open_url;
exports.skill_list = lobehub_searchPackage.skill_list;
exports.skill_search = lobehub_searchPackage.skill_search;
exports.skill_read = lobehub_searchPackage.skill_read;
exports.skill_resource = lobehub_searchPackage.skill_resource;
exports.agent_list = lobehub_searchPackage.agent_list;
exports.market_search = lobehub_searchPackage.market_search;
exports.market_view = lobehub_searchPackage.market_view;
exports.status = lobehub_searchPackage.status;
exports.test = lobehub_searchPackage.test;