/* METADATA
{
  "name": "kimi_search",
  "display_name": { "zh": "Kimi搜索", "en": "Kimi Web Search" },
  "description": {
    "zh": "Kimi开放平台联网搜索（新版 REST三接口）：search基础搜索 ¥0.01/次（可选带网页正文）；search_pro增强搜索 ¥0.015/次（站点限定≤5、时间窗、正文片段chunks）；fetch网页抓取 ¥0.01/次（URL转markdown）；test零成本自检（查余额）。仅成功且非空计费，失败不计费。境内直连 api.moonshot.cn，不挑网络。Key读 /sdcard/Download/Operit/kimi/config.json（或设 MOONSHOT_API_KEY环境变量）。",
    "en": "Kimi (Moonshot) web search REST APIs: search 0.01 CNY/call; search_pro 0.015 CNY/call (sites/time window/chunks); fetch URL to markdown 0.01 CNY/call; free balance self-test. Charged only on success with non-empty results."
  },
  "author": "浮生一梦",
  "env": [
    {
      "name": "MOONSHOT_API_KEY",
      "description": {
        "zh": "Kimi开放平台 API Key（sk-开头，platform.kimi.com创建）。可选：不设置则读 config.json",
        "en": "Kimi Open Platform API key (sk-...). Optional; falls back to config.json"
      },
      "required": false
    }
  ],
  "category": "Search",
  "tools": [
    {
      "name": "search",
      "description": {
        "zh": "Kimi联网搜索 Basic：返回标题/摘要/链接/日期/权威等级；include_content=true时每个结果的 text附带网页正文（同价）。¥0.01/次，失败或空结果不计费。",
        "en": "Basic web search: title/snippet/url/date/authority; optional page content. CNY0.01 per successful non-empty call."
      },
      "parameters": [
        { "name": "query", "description": { "zh": "搜索词（写具体：实体+时间+限定词）", "en": "Search query" }, "type": "string", "required": true },
        { "name": "limit", "description": { "zh": "结果数1-20，默认5", "en": "Result count 1-20, default 5" }, "type": "number", "required": false },
        { "name": "include_content", "description": { "zh": "true时每个结果附带网页正文，适合需要细读正文时一趟拿全", "en": "Include page content in text field" }, "type": "boolean", "required": false },
        { "name": "timeout_seconds", "description": { "zh": "超时秒数1-60，可选；带正文或复杂查询建议30", "en": "Timeout seconds 1-60" }, "type": "number", "required": false },
        { "name": "api_key", "description": { "zh": "API Key（可选覆盖）", "en": "API key override" }, "type": "string", "required": false }
      ]
    },
    {
      "name": "search_pro",
      "description": {
        "zh": "Kimi联网搜索 Pro：站点限定（最多5个，OR）、时间窗限定、每结果附按相关性排序的正文片段（chunks）。¥0.015/次。适合时效/指定来源检索。",
        "en": "Pro search: sites filter (max 5), time window, ranked content chunks. CNY0.015 per successful call."
      },
      "parameters": [
        { "name": "query", "description": { "zh": "搜索词", "en": "Search query" }, "type": "string", "required": true },
        { "name": "limit", "description": { "zh": "结果数1-20，默认5", "en": "Result count 1-20, default 5" }, "type": "number", "required": false },
        { "name": "sites", "description": { "zh": "站点限定，逗号分隔，最多5个，如 zhihu.com,bilibili.com", "en": "Sites filter, comma separated, max 5" }, "type": "string", "required": false },
        { "name": "time_start", "description": { "zh": "时间窗起，格式 YYYY / YYYY-MM / YYYY-MM-DD", "en": "Time window start" }, "type": "string", "required": false },
        { "name": "time_end", "description": { "zh": "时间窗止，格式同上", "en": "Time window end" }, "type": "string", "required": false },
        { "name": "timeout_seconds", "description": { "zh": "超时秒数1-60，可选", "en": "Timeout seconds 1-60" }, "type": "number", "required": false },
        { "name": "api_key", "description": { "zh": "API Key（可选覆盖）", "en": "API key override" }, "type": "string", "required": false }
      ]
    },
    {
      "name": "fetch",
      "description": {
        "zh": "网页抓取：给 URL返回 markdown正文（无图片/视频文件）。¥0.01/次，失败或空内容不计费。",
        "en": "Fetch a URL to markdown. CNY0.01 per successful call."
      },
      "parameters": [
        { "name": "url", "description": { "zh": "要抓取的网页 URL", "en": "URL to fetch" }, "type": "string", "required": true },
        { "name": "max_chars", "description": { "zh": "正文截断长度，默认30000，范围1000-200000", "en": "Max chars, default 30000" }, "type": "number", "required": false },
        { "name": "api_key", "description": { "zh": "API Key（可选覆盖）", "en": "API key override" }, "type": "string", "required": false }
      ]
    },
    {
      "name": "test",
      "description": {
        "zh": "零成本自检：验证 Key有效性并查询账户余额（不计费）",
        "en": "Free self-test: validate key and show balance"
      },
      "parameters": []
    }
  ]
}*/
/// <reference path="./types/index.d.ts" />
const kimiSearch = (function () {
    const SEARCH_URL = "https://api.moonshot.cn/v1/tools/search";
    const SEARCH_PRO_URL = "https://api.moonshot.cn/v1/tools/search_pro";
    const FETCH_URL = "https://api.moonshot.cn/v1/tools/fetch";
    const BALANCE_URL = "https://api.moonshot.cn/v1/users/me/balance";
    const CONFIG_PATH = "/sdcard/Download/Operit/kimi/config.json";
    const NET_GUARD_MS = 95000;
    const BALANCE_GUARD_MS = 35000;
    const client = OkHttp.newBuilder()
        .connectTimeout(20000)
        .readTimeout(90000)
        .writeTimeout(20000)
        .build();
    function msgOf(e) {
        return e && e.message ? e.message : String(e);
    }
    function raceGuard(promise, ms, label) {
        return new Promise(function (resolve, reject) {
            let done = false;
            const timer = setTimeout(function () {
                if (!done) {
                    done = true;
                    reject(new Error("guard-timeout " + ms + "ms" + (label ? "（" + label + "）" : "")));
                }
            }, ms);
            promise.then(function (v) {
                if (!done) { done = true; clearTimeout(timer); resolve(v); }
            }, function (e) {
                if (!done) { done = true; clearTimeout(timer); reject(e); }
            });
        });
    }
    async function readText(path) {
        try {
            let r = await Tools.Files.read({ path: path, environment: "android" });
            if (typeof r === "string") return r;
            if (r && typeof r.content === "string") return r.content;
            if (r && r.data && typeof r.data.content === "string") return r.data.content;
        } catch (e1) {
            try {
                let r2 = await Tools.Files.read(path);
                if (typeof r2 === "string") return r2;
                if (r2 && typeof r2.content === "string") return r2.content;
                if (r2 && r2.data && typeof r2.data.content === "string") return r2.data.content;
            } catch (e2) { }
        }
        return "";
    }
    async function getApiKey(providedKey) {
        if (providedKey) return providedKey;
        try {
            const envKey = getEnv("MOONSHOT_API_KEY");
            if (envKey) return envKey;
        } catch (e) { }
        try {
            const text = await readText(CONFIG_PATH);
            if (text) {
                const cfg = JSON.parse(text);
                if (cfg && typeof cfg.api_key === "string" && cfg.api_key) return cfg.api_key;
            }
        } catch (e2) { }
        return "";
    }
    function keyMissingError() {
        return new Error("未配置 Kimi API Key：请检查 " + CONFIG_PATH + "的 api_key字段，或设置 MOONSHOT_API_KEY环境变量，或在调用时传 api_key参数");
    }
    function buildHttpError(status, content) {
        let detail = "";
        try {
            const j = JSON.parse(content);
            if (j && j.error && j.error.message) detail = j.error.message;
            else if (j && j.error) detail = JSON.stringify(j.error);
        } catch (e) {
            detail = content || "";
        }
        if (status === 400) return new Error("HTTP400：请求参数错误" + (detail ? " —— " + detail : ""));
        if (status === 401) return new Error("HTTP401：API Key无效或缺失" + (detail ? " —— " + detail : ""));
        if (status === 403) return new Error("HTTP403：账号未激活或已停用" + (detail ? " —— " + detail : ""));
        if (status === 429) return new Error("HTTP429：触发限速（联网搜索 QPS独立限额，Tier0=1/秒）或限速服务暂不可用，稍后重试");
        if (status === 504) return new Error("HTTP504：搜索超时，可调大 timeout_seconds或精简查询词");
        return new Error("HTTP " + status + "：" + (detail || "请求失败"));
    }
    async function viaToolsNet(url, method, headers, bodyText, guardMs) {
        const resp = await raceGuard(Tools.Net.http({
            url: url,
            method: method,
            headers: headers,
            body: bodyText,
            follow_redirects: true,
            connect_timeout: 15000,
            read_timeout: 90000,
            validateStatus: false
        }), guardMs, "Tools.Net");
        let text = "";
        const saved = resp ? (resp.content_saved_to || (resp.data && resp.data.content_saved_to) || resp.output_saved_to) : null;
        if (saved) {
            try { text = await readText(saved); } catch (e) { }
        }
        if (!text && resp) {
            if (typeof resp.content === "string") text = resp.content;
            else if (typeof resp.body === "string") text = resp.body;
            else if (typeof resp.text === "string") text = resp.text;
            else if (resp.data && typeof resp.data.content === "string") text = resp.data.content;
        }
        let status = null;
        if (resp) {
            if (resp.statusCode != null) status = resp.statusCode;
            else if (resp.status != null) status = resp.status;
            else if (resp.code != null) status = resp.code;
            else if (resp.data && resp.data.status != null) status = resp.data.status;
        }
        return { status: status, text: text, tier: "Tools.Net" };
    }
    async function request(method, url, headers, bodyObj, guardMs) {
        try {
            let req = client.newRequest().url(url).method(method).headers(headers);
            if (bodyObj != null) {
                req = req.body(JSON.stringify(bodyObj), "json");
            }
            const response = await raceGuard(req.build().execute(), guardMs, "OkHttp");
            let status = null;
            if (response) {
                if (response.statusCode != null) status = response.statusCode;
                else if (response.code != null) status = response.code;
            }
            const text = response && response.content != null ? String(response.content) : "";
            return { status: status, text: text, tier: "OkHttp" };
        } catch (okErr) {
            try {
                return await viaToolsNet(url, method, headers, bodyObj == null ? undefined : JSON.stringify(bodyObj), guardMs);
            } catch (netErr) {
                throw new Error("网络请求失败（OkHttp：" + msgOf(okErr) + "；Tools.Net：" + msgOf(netErr) + "）");
            }
        }
    }
    async function postJson(url, bodyObj, apiKey, guardMs) {
        const key = await getApiKey(apiKey || undefined);
        if (!key) throw keyMissingError();
        const r = await request("POST", url, { "Authorization": "Bearer " + key, "Content-Type": "application/json" }, bodyObj, guardMs);
        if (r.status !== 200) throw buildHttpError(r.status, r.text);
        if (!r.text) throw new Error("HTTP " + r.status + "但响应为空（tier=" + r.tier + "）");
        return JSON.parse(r.text);
    }
    function pickStr(v) {
        return typeof v === "string" ? v : "";
    }
    function normLimit(v) {
        const n = typeof v === "number" ? v : parseInt(v, 10);
        if (!n || n < 1) return 5;
        return Math.min(20, n);
    }
    function normTimeout(v) {
        const n = typeof v === "number" ? v : parseInt(v, 10);
        if (!n || n < 1) return 30;
        return Math.min(60, n);
    }
    function normMaxChars(v) {
        const n = typeof v === "number" ? v : parseInt(v, 10);
        if (!n || n < 1000) return 30000;
        return Math.min(200000, n);
    }
    function mapResults(items) {
        if (!items || !Array.isArray(items)) return [];
        return items.map(function (item) {
            const r = {
                title: pickStr(item.title),
                url: pickStr(item.url),
                site_name: pickStr(item.site_name),
                date: pickStr(item.date),
                authority: pickStr(item.authority),
                snippet: pickStr(item.snippet)
            };
            if (typeof item.text === "string" && item.text) r.text = item.text;
            if (item.chunks && Array.isArray(item.chunks)) {
                r.chunks = item.chunks.map(function (c) {
                    return { text: pickStr(c.text), score: typeof c.score === "number" ? c.score : null };
                });
            }
            return r;
        });
    }
    async function doSearch(params) {
        if (!params.query) throw new Error("缺少 query参数");
        const body = { text_query: params.query, limit: normLimit(params.limit) };
        if (params.include_content === true) body.include_content = true;
        if (params.timeout_seconds) body.timeout_seconds = normTimeout(params.timeout_seconds);
        const result = await postJson(SEARCH_URL, body, params.api_key, NET_GUARD_MS);
        const list = mapResults(result.search_results);
        return { success: true, query: params.query, count: list.length, charged: list.length > 0, results: list };
    }
    async function doSearchPro(params) {
        if (!params.query) throw new Error("缺少 query参数");
        const body = { text_query: params.query, limit: normLimit(params.limit) };
        let sitesArr = [];
        if (params.sites) {
            if (Array.isArray(params.sites)) sitesArr = params.sites.slice();
            else sitesArr = String(params.sites).split(/[,，\s]+/);
        }
        sitesArr = sitesArr.filter(function (s) {
            return typeof s === "string" && s.length > 0;
        }).slice(0, 5);
        if (sitesArr.length > 0) body.sites = sitesArr;
        if (params.time_start || params.time_end) {
            const tw = {};
            if (params.time_start) tw.start = String(params.time_start);
            if (params.time_end) tw.end = String(params.time_end);
            body.time_window = tw;
        }
        if (params.timeout_seconds) body.timeout_seconds = normTimeout(params.timeout_seconds);
        const result = await postJson(SEARCH_PRO_URL, body, params.api_key, NET_GUARD_MS);
        const list = mapResults(result.search_results);
        return { success: true, query: params.query, count: list.length, charged: list.length > 0, results: list };
    }
    async function doFetch(params) {
        if (!params.url) throw new Error("缺少 url参数");
        const result = await postJson(FETCH_URL, { url: params.url }, params.api_key, NET_GUARD_MS);
        const md = pickStr(result.markdown);
        if (!md) throw new Error("未取到正文（页面不可访问或无可提取内容；此情况官方不计费）");
        const maxChars = normMaxChars(params.max_chars);
        let markdown = md;
        let truncated = false;
        if (markdown.length > maxChars) {
            markdown = markdown.slice(0, maxChars);
            truncated = true;
        }
        return { success: true, url: pickStr(result.url) || params.url, title: pickStr(result.title), length: md.length, truncated: truncated, markdown: markdown };
    }
    async function doBalanceCheck() {
        const key = await getApiKey(null);
        if (!key) throw keyMissingError();
        const r = await request("GET", BALANCE_URL, { "Authorization": "Bearer " + key }, null, BALANCE_GUARD_MS);
        if (r.status !== 200) throw buildHttpError(r.status, r.text);
        if (!r.text) throw new Error("余额接口空响应");
        const j = JSON.parse(r.text);
        const d = j && j.data ? j.data : {};
        return {
            success: true,
            available_balance: d.available_balance != null ? d.available_balance : null,
            cash_balance: d.cash_balance != null ? d.cash_balance : null,
            voucher_balance: d.voucher_balance != null ? d.voucher_balance : null
        };
    }
    async function searchWrapper(params) {
        try {
            const r = await doSearch(params || {});
            complete({
                success: true,
                message: "Kimi搜索完成：" + r.count + "条结果" + (r.count > 0 ? "（本次计费约 ¥0.01）" : "（空结果不计费）"),
                data: r
            });
        } catch (error) {
            complete({ success: false, message: "搜索失败：" + msgOf(error), error_stack: error && error.stack ? error.stack : null });
        }
    }
    async function searchProWrapper(params) {
        try {
            const r = await doSearchPro(params || {});
            complete({
                success: true,
                message: "Kimi Pro搜索完成：" + r.count + "条结果" + (r.count > 0 ? "（本次计费约 ¥0.015）" : "（空结果不计费）"),
                data: r
            });
        } catch (error) {
            complete({ success: false, message: "Pro搜索失败：" + msgOf(error), error_stack: error && error.stack ? error.stack : null });
        }
    }
    async function fetchWrapper(params) {
        try {
            const r = await doFetch(params || {});
            complete({
                success: true,
                message: "抓取完成：" + (r.title || r.url) + "（正文 " + r.length + "字符" + (r.truncated ? "，已截断" : "") + "，计费 ¥0.01）",
                data: r
            });
        } catch (error) {
            complete({ success: false, message: "抓取失败：" + msgOf(error), error_stack: error && error.stack ? error.stack : null });
        }
    }
    async function testWrapper() {
        try {
            const r = await doBalanceCheck();
            complete({
                success: true,
                message: "连接正常。可用余额 ¥" + r.available_balance + "（现金 ¥" + r.cash_balance + "，代金券 ¥" + r.voucher_balance + "）",
                data: r
            });
        } catch (error) {
            complete({ success: false, message: "自检失败：" + msgOf(error), error_stack: error && error.stack ? error.stack : null });
        }
    }
    return {
        search: searchWrapper,
        search_pro: searchProWrapper,
        fetch: fetchWrapper,
        test: testWrapper
    };
})();
exports.search = kimiSearch.search;
exports.search_pro = kimiSearch.search_pro;
exports.fetch = kimiSearch.fetch;
exports.test = kimiSearch.test;
