/*
METADATA
{
    "name": "dl_kit",
    "description": "Operit 内建下载器（应用进程内，不依赖 Termux）：多连接分片下载（HTTP Range 并发）、按字节偏移乱序写入、自动降级、内置 DoH+SNI 绕过兜底。先探测文件大小与分片支持，再并发拉取分片并写入同一文件。",
    "tools": [
        {
            "name": "dl_probe",
            "description": "探测 URL：文件大小、是否支持 Range 分片、最终跳转地址、建议下载模式、是否需要绕过。下载前先跑它，避免盲下。",
            "parameters": [
                { "name": "url", "description": "目标 URL", "type": "string", "required": true },
                { "name": "headers", "description": "自定义请求头，JSON 字符串或对象", "type": "string", "required": false },
                { "name": "bypass", "description": "是否允许 DoH+IP 直连兜底，默认 true", "type": "boolean", "required": false }
            ]
        },
        {
            "name": "dl_get",
            "description": "多连接分片下载到文件。流程：探测大小与分片支持 → N 路并发 Range 拉取 → 按字节偏移写入（Java RandomAccessFile，乱序到达也不怕）→ 校验大小。不支持分片时自动降级内置单流下载；直连被阻断时自动走 DoH+IP 直连兜底。",
            "parameters": [
                { "name": "url", "description": "目标 URL", "type": "string", "required": true },
                { "name": "dest", "description": "保存路径（含文件名），默认 /sdcard/Download/<从URL推断的名称>", "type": "string", "required": false },
                { "name": "connections", "description": "并发分片数，默认 8，范围 1-16", "type": "number", "required": false },
                { "name": "chunk_mb", "description": "单分片上限 MB，默认 4（用于控制内存峰值）", "type": "number", "required": false },
                { "name": "headers", "description": "自定义请求头，JSON 字符串或对象", "type": "string", "required": false },
                { "name": "bypass", "description": "是否允许 DoH+IP 直连兜底，默认 true", "type": "boolean", "required": false }
            ]
        }
    ]
}
*/

// ===================== 常量 =====================
const DLK = "dl_kit";
const ENV = "android";
const DEFAULT_DIR = "/sdcard/Download";
const UA = "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0 Safari/537.36";
const CONNECT_TIMEOUT = 8000;
const READ_TIMEOUT = 60000;
const CHUNK_RETRY = 3;
const SIDECAR_SUFFIX = ".dlkit.json";
const BACKOFF_BASE_MS = 1500;
const MAX_BACKOFF_MS = 20000;
const PROBE_TIMEOUT = 15000;
const DOH_ENDPOINTS = [
    "https://dns.alidns.com/resolve?name={host}&type=A",
    "https://doh.pub/dns-query?name={host}&type=A"
];
const DOH_TIMEOUT = 6000;

// ===================== 基础返回 =====================
function ok(data, message) {
    const payload = { success: true, message: message || "ok", data: data };
    if (typeof complete === "function") complete(payload);
    return payload;
}

function fail(message, extra) {
    const payload = Object.assign({ success: false, message: String(message || "error") }, extra || {});
    if (typeof complete === "function") complete(payload);
    return payload;
}

function str(v) { return v == null ? "" : String(v); }

function errMsg(e) { return e && e.message ? String(e.message) : String(e); }

function clampNum(n, a, b, dflt) {
    n = Number(n);
    if (!isFinite(n)) return dflt;
    return Math.max(a, Math.min(b, Math.round(n)));
}

function fmtBytes(n) {
    n = Number(n) || 0;
    const u = ["B", "KB", "MB", "GB", "TB"];
    let i = 0;
    while (n >= 1024 && i < u.length - 1) { n = n / 1024; i += 1; }
    return (i === 0 ? n : n.toFixed(2)) + " " + u[i];
}

function parseHeaders(h) {
    if (!h) return {};
    if (typeof h === "object") return h;
    try {
        const o = JSON.parse(str(h));
        return (o && typeof o === "object") ? o : {};
    } catch (e) { return {}; }
}

function headerOf(headers, name) {
    if (!headers) return "";
    const want = str(name).toLowerCase();
    const keys = Object.keys(headers);
    for (let i = 0; i < keys.length; i += 1) {
        if (str(keys[i]).toLowerCase() === want) return str(headers[keys[i]]);
    }
    return "";
}

function parseUrlParts(url) {
    const m = /^(https?):\/\/([^\/\?#]+)([^\?#]*)(\?[^#]*)?/.exec(str(url));
    if (!m) return null;
    return { scheme: m[1], hostport: m[2], path: m[3] || "/", query: m[4] || "" };
}

function baseNameFromUrl(url) {
    const p = parseUrlParts(url);
    if (!p) return "download.bin";
    let seg = p.path.split("/").filter(function (x) { return x; }).pop() || "";
    try { seg = decodeURIComponent(seg); } catch (e) { /* keep */ }
    seg = seg.replace(/[\\:*?"<>|]/g, "_");
    return seg || "download.bin";
}

// ===================== Java 文件写入 =====================
function javaWriteAt(path, offset, b64) {
    const File = Java.type("java.io.File");
    const RAF = Java.type("java.io.RandomAccessFile");
    const B64 = Java.type("java.util.Base64");
    const raf = new RAF(new File(path), "rw");
    try {
        raf.seek(offset);
        raf.write(B64.getDecoder().decode(b64));
    } finally {
        raf.close();
    }
}

function javaReset(path) {
    const File = Java.type("java.io.File");
    const RAF = Java.type("java.io.RandomAccessFile");
    const raf = new RAF(new File(path), "rw");
    try { raf.setLength(0); } finally { raf.close(); }
}

function javaLen(path) {
    const File = Java.type("java.io.File");
    return new File(path).length();
}

function javaEnsureDir(path) {
    const File = Java.type("java.io.File");
    const f = new File(path);
    if (!f.exists()) f.mkdirs();
}

function javaTruncateTo(path, size) {
    const File = Java.type("java.io.File");
    const RAF = Java.type("java.io.RandomAccessFile");
    const raf = new RAF(new File(path), "rw");
    try { raf.setLength(size); } finally { raf.close(); }
}

// ===================== 断点续传状态（sidecar） =====================
function sidecarPath(dest) { return dest + SIDECAR_SUFFIX; }

async function existsAny(path) {
    try {
        const ex = await Tools.Files.exists(path, ENV);
        if (ex && typeof ex.exists === "boolean") return ex.exists;
        if (ex === true || ex === false) return ex;
        return false;
    } catch (e) { return false; }
}

async function loadSidecar(dest) {
    try {
        const p = sidecarPath(dest);
        if (!(await existsAny(p))) return null;
        const r = await Tools.Files.read(p);
        let text = "";
        if (typeof r === "string") text = r;
        else if (r && typeof r.content === "string") text = r.content;
        else if (r && r.toString) text = String(r);
        if (!text) return null;
        const o = JSON.parse(text);
        if (!o || o.v !== 1) return null;
        if (!o.done || typeof o.done !== "object") o.done = {};
        return o;
    } catch (e) {
        console.log("读取续传状态失败: " + errMsg(e));
        return null;
    }
}

async function saveSidecar(dest, state) {
    try {
        await Tools.Files.write(sidecarPath(dest), JSON.stringify(state), false, ENV);
        return true;
    } catch (e) {
        console.log("保存续传状态失败: " + errMsg(e));
        return false;
    }
}

async function clearSidecar(dest) {
    try { await Tools.Files.deleteFile(sidecarPath(dest), false, ENV); } catch (e) { /* ignore */ }
}

// ===================== 网络层 =====================
async function netRequest(url, opts) {
    const o = opts || {};
    const r = await Tools.Net.http({
        url: url,
        method: o.method || "GET",
        headers: o.headers || undefined,
        connect_timeout: o.connectTimeout || CONNECT_TIMEOUT,
        read_timeout: o.readTimeout || READ_TIMEOUT,
        follow_redirects: o.followRedirects !== false,
        ignore_ssl: !!o.ignoreSsl,
        responseType: o.responseType || "text"
    });
    return {
        code: r.statusCode,
        statusMessage: r.statusMessage,
        headers: r.headers || {},
        contentType: r.contentType,
        text: r.content,
        b64: r.contentBase64 || "",
        size: r.size,
        finalUrl: r.url || url
    };
}

async function dohResolve(host) {
    const ips = [];
    for (let i = 0; i < DOH_ENDPOINTS.length; i += 1) {
        const u = DOH_ENDPOINTS[i].replace("{host}", encodeURIComponent(host));
        try {
            const r = await netRequest(u, { responseType: "text", readTimeout: DOH_TIMEOUT, connectTimeout: 4000 });
            if (r.code !== 200 || !r.text) continue;
            let data;
            try { data = JSON.parse(r.text); } catch (e) { continue; }
            const ans = (data && data.Answer) || [];
            for (let k = 0; k < ans.length; k += 1) {
                if (ans[k] && (ans[k].type === 1 || ans[k].type === "1") && ans[k].data) {
                    if (ips.indexOf(ans[k].data) < 0) ips.push(ans[k].data);
                }
            }
            if (ips.length) break;
        } catch (e) { /* try next */ }
    }
    return ips;
}

// 发起一次请求；直连失败且允许时，走 DoH + IP 直连（SNI=IP + Host 头 + 忽略证书）
async function smartRequest(url, opts) {
    const o = opts || {};
    const allowBypass = o.bypass !== false;
    let directErr = "";
    try {
        const r = await netRequest(url, o);
        if (r.code >= 200 && r.code < 300) return Object.assign(r, { tier: "direct" });
        if (r.code === 206) return Object.assign(r, { tier: "direct" });
        directErr = "HTTP " + r.code;
    } catch (e) {
        directErr = errMsg(e);
    }
    if (!allowBypass) throw new Error("直连失败: " + directErr);

    const p = parseUrlParts(url);
    if (!p || p.scheme !== "https") throw new Error("直连失败(" + directErr + ")且无法绕过(非https)");

    const host = p.hostport.split(":")[0];
    const ips = await dohResolve(host);
    if (!ips.length) throw new Error("直连失败(" + directErr + ")且 DoH 未解析到 IP");

    const maxTry = Math.min(ips.length, 4);
    let lastErr = "";
    for (let i = 0; i < maxTry; i += 1) {
        const target = "https://" + ips[i] + p.path + p.query;
        const headers = Object.assign({}, o.headers || {});
        headers["Host"] = p.hostport;
        try {
            const r = await netRequest(target, Object.assign({}, o, {
                headers: headers,
                ignoreSsl: true,
                followRedirects: false
            }));
            if ((r.code >= 200 && r.code < 300) || r.code === 206) {
                return Object.assign(r, { tier: "bypass", resolvedIp: ips[i] });
            }
            lastErr = "HTTP " + r.code;
        } catch (e) {
            lastErr = errMsg(e);
        }
    }
    throw new Error("直连失败(" + directErr + ")，绕过也失败(" + lastErr + ")");
}

// ===================== 探测 =====================
async function probe(url, headers, bypass) {
    const h = Object.assign({}, headers || {}, { "User-Agent": UA });
    let size = -1;
    let acceptRanges = false;
    let finalUrl = url;
    let tier = "direct";
    let note = "";

    // 先 HEAD
    try {
        const r = await smartRequest(url, { method: "HEAD", headers: h, responseType: "text", readTimeout: PROBE_TIMEOUT, bypass: bypass });
        tier = r.tier;
        finalUrl = r.finalUrl || url;
        const cl = headerOf(r.headers, "content-length");
        if (cl) size = Number(cl);
        const ar = headerOf(r.headers, "accept-ranges");
        acceptRanges = str(ar).toLowerCase().indexOf("bytes") >= 0;
    } catch (e) {
        note = "HEAD 失败: " + errMsg(e);
    }

    // HEAD 不可用或信息不全 → 用 0-0 探测
    if (size < 0 || !acceptRanges) {
        try {
            const h2 = Object.assign({}, h, { "Range": "bytes=0-0" });
            const r2 = await smartRequest(url, { headers: h2, responseType: "arraybuffer", readTimeout: PROBE_TIMEOUT, bypass: bypass });
            tier = r2.tier;
            finalUrl = r2.finalUrl || finalUrl;
            const cr = headerOf(r2.headers, "content-range");
            if (r2.code === 206 && cr) {
                const mm = /\/(\d+)\s*$/.exec(str(cr));
                if (mm) size = Number(mm[1]);
                acceptRanges = true;
            } else if (r2.code === 200) {
                acceptRanges = false;
                const cl2 = headerOf(r2.headers, "content-length");
                if (cl2) size = Number(cl2);
                note = note || "服务器不支持 Range，将走单流下载";
            }
        } catch (e) {
            if (!note) note = "Range 探测失败: " + errMsg(e);
        }
    }

    return {
        url: url,
        final_url: finalUrl,
        size_bytes: size,
        size_text: size >= 0 ? fmtBytes(size) : "未知",
        accept_ranges: acceptRanges,
        suggested_mode: acceptRanges ? "multi" : "single",
        tier: tier,
        note: note
    };
}

// ===================== 并发池 =====================
async function runPool(count, worker) {
    let next = 0;
    const runners = [];
    for (let k = 0; k < count; k += 1) {
        runners.push((async function () {
            while (true) {
                const idx = next;
                next += 1;
                if (idx >= countTotal) return;
                await worker(idx);
            }
        })());
    }
    await Promise.all(runners);
}

// ===================== 主下载 =====================
function isRateLimit(msg) {
    const m = str(msg);
    return m.indexOf("429") >= 0 || m.indexOf("503") >= 0;
}

async function downloadMulti(url, dest, headers, bypass, connections, chunkMb, info, state) {
    const total = info.size_bytes;
    let chunkSize;
    let chunkCount;

    if (state && state.chunk_size && state.chunk_count) {
        chunkSize = state.chunk_size;
        chunkCount = state.chunk_count;
    } else {
        chunkSize = Math.min(chunkMb * 1024 * 1024, Math.ceil(total / connections) + 1);
        chunkCount = Math.ceil(total / chunkSize);
        state = {
            v: 1,
            url: url,
            size_bytes: total,
            chunk_size: chunkSize,
            chunk_count: chunkCount,
            done: {},
            updated_at: new Date().toISOString()
        };
    }

    const doneMap = state.done || {};
    const skipped = Object.keys(doneMap).length;

    console.log("分片计划: 总 " + fmtBytes(total) + " / " + chunkCount + " 片 × " + fmtBytes(chunkSize) + " / 并发 " + connections + (skipped > 0 ? " / 续传跳过 " + skipped + " 片" : ""));

    await saveSidecar(dest, state);

    const startedAt = Date.now();
    let doneBytes = 0;
    let fetchedChunks = 0;
    let backoffEvents = 0;
    let penaltyUntil = 0;

    async function respectPenalty() {
        const w = penaltyUntil - Date.now();
        if (w > 0) await Tools.System.sleep(Math.min(w, MAX_BACKOFF_MS));
    }

    function penalize(ms) {
        const capped = Math.min(ms, MAX_BACKOFF_MS);
        const until = Date.now() + capped;
        if (until > penaltyUntil) {
            penaltyUntil = until;
            backoffEvents += 1;
            console.log("⚠ 触发限流退避: 全局暂停 " + Math.round(capped / 1000) + " 秒");
        }
    }

    async function fetchChunk(idx) {
        const start = idx * chunkSize;
        const end = Math.min(start + chunkSize - 1, total - 1);
        const h = Object.assign({}, headers, {
            "User-Agent": UA,
            "Range": "bytes=" + start + "-" + end
        });
        let lastErr = "";
        for (let attempt = 1; attempt <= CHUNK_RETRY; attempt += 1) {
            await respectPenalty();
            try {
                const r = await smartRequest(url, { headers: h, responseType: "arraybuffer", bypass: bypass });
                if (r.code !== 206) {
                    if (r.code === 429 || r.code === 503) penalize(BACKOFF_BASE_MS * Math.pow(2, attempt - 1));
                    throw new Error("期望206，实得 " + r.code);
                }
                const b64 = r.b64 || "";
                if (!b64) throw new Error("空响应体");
                javaWriteAt(dest, start, b64);
                let pad = 0;
                const tail2 = b64.slice(-2);
                if (tail2 === "==") pad = 2; else if (b64.slice(-1) === "=") pad = 1;
                const got = Math.floor(b64.length * 3 / 4) - pad;
                doneMap[String(idx)] = got > 0 ? got : (end - start + 1);
                state.done = doneMap;
                state.updated_at = new Date().toISOString();
                await saveSidecar(dest, state);
                doneBytes += doneMap[String(idx)];
                fetchedChunks += 1;
                if (fetchedChunks % 4 === 0 || fetchedChunks === (chunkCount - skipped)) {
                    const el = (Date.now() - startedAt) / 1000;
                    console.log("进度 " + fetchedChunks + "/" + (chunkCount - skipped) + "(新增)  已下 " + fmtBytes(doneBytes) + "  " + (el > 0 ? fmtBytes(doneBytes / el) + "/s" : ""));
                }
                return;
            } catch (e) {
                lastErr = errMsg(e);
                if (isRateLimit(lastErr)) penalize(BACKOFF_BASE_MS * Math.pow(2, attempt - 1));
                else if (attempt < CHUNK_RETRY) await Tools.System.sleep(BACKOFF_BASE_MS * attempt);
            }
        }
        throw new Error("分片 #" + idx + " 失败: " + lastErr);
    }

    const todo = [];
    for (let i = 0; i < chunkCount; i += 1) {
        if (!doneMap[String(i)]) todo.push(i);
    }

    let next = 0;
    const workerCount = Math.min(connections, Math.max(todo.length, 1));
    const runners = [];
    for (let k = 0; k < workerCount; k += 1) {
        runners.push((async function () {
            while (true) {
                const i = next;
                next += 1;
                if (i >= todo.length) return;
                await fetchChunk(todo[i]);
            }
        })());
    }
    await Promise.all(runners);

    javaTruncateTo(dest, total);
    const elapsed = (Date.now() - startedAt) / 1000;
    const realLen = javaLen(dest);
    return {
        mode: "multi",
        chunks: chunkCount,
        resumed_chunks: skipped,
        connections: workerCount,
        chunk_size: chunkSize,
        elapsed_sec: Number(elapsed.toFixed(2)),
        avg_speed: elapsed > 0 ? fmtBytes(realLen / elapsed) + "/s" : "-",
        backoff_events: backoffEvents,
        expected_bytes: total,
        written_bytes: realLen,
        size_match: realLen === total
    };
}

async function downloadSingle(url, dest, headers, bypass) {
    const startedAt = Date.now();
    const r = await smartRequest(url, { headers: Object.assign({}, headers, { "User-Agent": UA }), responseType: "arraybuffer", bypass: bypass });
    if (r.code !== 200) throw new Error("HTTP " + r.code);
    const b64 = r.b64 || "";
    if (!b64) throw new Error("空响应体");
    javaReset(dest);
    javaWriteAt(dest, 0, b64);
    const elapsed = (Date.now() - startedAt) / 1000;
    const realLen = javaLen(dest);
    return {
        mode: "single",
        tier: r.tier,
        elapsed_sec: Number(elapsed.toFixed(2)),
        avg_speed: elapsed > 0 ? fmtBytes(realLen / elapsed) + "/s" : "-",
        written_bytes: realLen
    };
}

// ===================== 工具实现 =====================
async function dl_probe(params) {
    const url = str(params && params.url).trim();
    if (!url) return fail("缺少 url");
    const headers = parseHeaders(params && params.headers);
    const p = await probe(url, headers, !(params && params.bypass === false));
    return ok(p, "探测完成");
}

async function dl_get(params) {
    const url = str(params && params.url).trim();
    if (!url) return fail("缺少 url");
    const headers = parseHeaders(params && params.headers);
    const bypass = !(params && params.bypass === false);
    const connections = clampNum(params && params.connections, 1, 16, 8);
    const chunkMb = clampNum(params && params.chunk_mb, 1, 16, 4);

    let dest = str(params && params.dest).trim();
    if (!dest) dest = DEFAULT_DIR + "/" + baseNameFromUrl(url);
    javaEnsureDir(dest.substring(0, Math.max(dest.lastIndexOf("/"), 1)));

    const info = await probe(url, headers, bypass);
    if (info.size_bytes <= 0) {
        return fail("无法确定文件大小（服务器可能不支持 HEAD/Range）", { probe: info });
    }

    let state = null;
    if (info.accept_ranges) {
        const sc = await loadSidecar(dest);
        if (sc && sc.url === url && sc.size_bytes === info.size_bytes) {
            state = sc;
            const n = Object.keys(sc.done || {}).length;
            if (n > 0) console.log("发现未完成记录，续传模式（已有 " + n + " 片）");
        } else if (sc) {
            console.log("续传记录与当前任务不匹配，重新开始");
        }
    }

    let result;
    try {
        if (info.accept_ranges) {
            result = await downloadMulti(url, dest, headers, bypass, connections, chunkMb, info, state);
        } else {
            result = await downloadSingle(url, dest, headers, bypass);
        }
    } catch (e) {
        return fail("下载未完成（进度已保存，可重跑续传）: " + errMsg(e), {
            file_path: dest,
            sidecar: sidecarPath(dest),
            hint: "再调用一次 dl_get（相同 url 与 dest）即可从断点继续"
        });
    }

    if (result.mode === "multi" && result.size_match === false) {
        return fail("下载完成但大小不符（已保留续传记录）", {
            expected_bytes: result.expected_bytes,
            written_bytes: result.written_bytes,
            file_path: dest
        });
    }

    await clearSidecar(dest);

    return ok({
        file_path: dest,
        file_uri: "file://" + dest,
        size_bytes: result.written_bytes,
        size_text: fmtBytes(result.written_bytes),
        mode: result.mode,
        tier: result.tier || info.tier,
        connections: result.connections || 0,
        chunks: result.chunks || 1,
        resumed_chunks: result.resumed_chunks || 0,
        backoff_events: result.backoff_events || 0,
        elapsed_sec: result.elapsed_sec,
        avg_speed: result.avg_speed,
        probe: { size: info.size_text, accept_ranges: info.accept_ranges, final_url: info.final_url },
        markdown: "[下载完成](" + "file://" + dest + ")"
    }, "下载完成 " + fmtBytes(result.written_bytes));
}

var countTotal = 0;

// ===================== 导出 =====================
const DlKitPkg = (function () {
    async function wrap(fn, params) {
        try {
            return await fn(params || {});
        } catch (e) {
            console.log("ERROR: " + errMsg(e));
            return fail("执行失败: " + errMsg(e));
        }
    }
    return {
        dl_probe: function (params) { return wrap(dl_probe, params); },
        dl_get: function (params) { return wrap(dl_get, params); }
    };
})();

exports.dl_probe = DlKitPkg.dl_probe;
exports.dl_get = DlKitPkg.dl_get;
