/*
METADATA
{
    "name": "rsshub_monitor",
    "display_name": { "zh": "RSSHub 资讯监控", "en": "RSSHub Feed Monitor" },
    "category": "Information",
    "description": {
        "zh": "万物皆可 RSS：通过公共 RSSHub 实例直连各平台资讯流（36氪快讯/B站/微博/知乎/华尔街见闻/财新/YouTube 等）。feed 拉取任意路由（多实例自动回退，RSS/Atom 双解析）；routes 查内置路由字典。手机独立运行，无需凭据。部分路由在公共实例上 503（上游反爬），会如实报错并给出换源建议。",
        "en": "Fetch anything-as-RSS via public RSSHub instances. Multi-instance fallback, RSS/Atom parsing, curated route dictionary. Phone-independent."
    },
    "enabledByDefault": true,
    "tools": [
        {
            "name": "feed",
            "description": "拉取 RSSHub 路由的资讯流。route 必填（如 /36kr/newsflashes 或完整 URL）；limit 返回条数（默认 10，最大 30）；instance 可指定实例。多实例自动回退，解析失败如实报错。",
            "parameters": [
                { "name": "route", "description": "RSSHub 路由路径（如 /36kr/newsflashes）或完整 URL", "type": "string", "required": true },
                { "name": "limit", "description": "返回条数，默认 10，最大 30", "type": "number", "required": false },
                { "name": "instance", "description": "指定实例基址（默认自动回退）", "type": "string", "required": false }
            ]
        },
        {
            "name": "routes",
            "description": "查内置路由字典（实测可用/热门路由，含参数说明）。keyword 可选过滤。",
            "parameters": [
                { "name": "keyword", "description": "关键词过滤（如 bilibili/快讯/财经）", "type": "string", "required": false }
            ]
        }
    ]
}
*/

const rsshub_monitorPackage = (function () {
    const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
    // 实例顺序：rssforever 今晚实测活跃（500万请求/27%健康率）；其余为连通但路由覆盖不一的备用
    const INSTANCES = [
        "https://rsshub.rssforever.com",
        "https://hub.slarker.me",
        "https://rsshub.pseudoyu.com"
    ];

    // 已验证/高热度路由字典（verified=true = 2026-09-09 当晚实测或实例热榜确认高频可用；false = 存在但公共实例成功率未知）
    const ROUTE_DICT = [
        { route: "/36kr/newsflashes", name: "36氪快讯", category: "科技/财经", verified: true, note: "实测直接可用，分钟级更新" },
        { route: "/wallstreetcn/live/:category?", name: "华尔街见闻直播", category: "财经", verified: false, note: ":category 可选（如 a-stock 全部/美股等），热榜高频" },
        { route: "/jin10/:important?", name: "金十数据快讯", category: "财经", verified: false, note: ":important 传 1 只看重要快讯，热榜高频" },
        { route: "/caixin/latest", name: "财新最新文章", category: "财经", verified: false, note: "热榜高频" },
        { route: "/zaobao/realtime/:section?", name: "联合早报", category: "新闻", verified: false, note: ":section 可选栏目" },
        { route: "/bilibili/user/video/:uid", name: "B站UP主投稿", category: "视频", verified: false, note: ":uid 填UP主数字UID（rsshub.app 亦可直拼）" },
        { route: "/bilibili/user/dynamic/:uid", name: "B站UP主动态", category: "视频", verified: false, note: "热榜高频" },
        { route: "/bilibili/live/room/:roomID", name: "B站直播间状态", category: "视频", verified: false, note: "开播状态监听" },
        { route: "/weibo/user/:uid", name: "微博用户", category: "社媒", verified: false, note: "反爬严格，公共实例常 503，失败属预期" },
        { route: "/zhihu/people/activities/:id", name: "知乎用户动态", category: "社媒", verified: false, note: "反爬严格，公共实例成功率低" },
        { route: "/youtube/channel/:id/:routeParams?", name: "YouTube频道", category: "视频", verified: false, note: "需实例能访问 YT" },
        { route: "/github/repos/:owner", name: "GitHub 用户仓库", category: "开发", verified: false, note: "监控用户仓库发布" },
        { route: "/cls/telegraph/:category?", name: "财联社电报", category: "财经", verified: false, note: "rssforever 上实测 503（上游问题），换实例再试" },
        { route: "/ithome/rss", name: "IT之家", category: "科技", verified: false, note: "未实测" },
        { route: "/sspai/matrix", name: "少数派", category: "科技", verified: false, note: "未实测" }
    ];

    function createClient() {
        try {
            return OkHttp.newBuilder()
                .connectTimeout(8000)
                .readTimeout(25000)
                .writeTimeout(8000)
                .followRedirects(true)
                .retryOnConnectionFailure(false)
                .build();
        } catch (_) {
            return OkHttp.newClient();
        }
    }
    const client = createClient();

    function decodeEntities(s) {
        return String(s)
            .replace(/&#x([0-9a-fA-F]+);/g, function (_, h) { try { return String.fromCodePoint(parseInt(h, 16)); } catch (e) { return ""; } })
            .replace(/&#(\d+);/g, function (_, d) { try { return String.fromCodePoint(parseInt(d, 10)); } catch (e) { return ""; } })
            .replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/"/g, '"')
            .replace(/&#0?39;/g, "'").replace(/'/g, "'").replace(/&nbsp;/gi, " ").replace(/&amp;/g, "&");
    }

    function stripHtml(s) {
        return String(s)
            .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
            .replace(/<(script|style)[\s\S]*?<\/\1>/gi, " ")
            .replace(/<[^>]+>/g, " ")
            .replace(/\s+/g, " ")
            .trim();
    }

    function extractTag(block, tagName) {
        const re = new RegExp("<" + tagName + "(?:\\s[^>]*)?>([\\s\\S]*?)<\\/" + tagName + ">", "i");
        const m = block.match(re);
        if (!m) return "";
        let inner = m[1];
        const cd = inner.match(/<!\[CDATA\[([\s\S]*?)\]\]>/);
        if (cd) return cd[1].trim();
        return inner.trim();
    }

    function extractLink(block) {
        // Atom: <link rel="alternate" href="..." />；RSS: <link>text</link>
        const href = block.match(/<link\b[^>]*\bhref=["']([^"']+)["'][^>]*\/?>/i);
        if (href) return href[1].trim();
        const rss = block.match(/<link(?:\s[^>]*)?>([\s\S]*?)<\/link>/i);
        if (rss) return rss[1].trim();
        return "";
    }

    function parseFeed(xml) {
        const isAtom = /<feed[\s>]/i.test(xml);
        const feedTitle = stripHtml(extractTag(xml, "title")) || "";
        const blocks = isAtom
            ? xml.match(/<entry(?:\s[^>]*)?>[\s\S]*?<\/entry>/gi) || []
            : xml.match(/<item(?:\s[^>]*)?>[\s\S]*?<\/item>/gi) || [];
        const items = blocks.map(function (b) {
            const title = decodeEntities(stripHtml(extractTag(b, "title")));
            const link = decodeEntities(extractLink(b));
            let desc = extractTag(b, "description") || extractTag(b, "summary") || extractTag(b, "content") || "";
            desc = decodeEntities(stripHtml(desc));
            const date = extractTag(b, "pubDate") || extractTag(b, "updated") || extractTag(b, "published") || "";
            return { title: title.slice(0, 200), link: link, date: date, summary: desc.slice(0, 300) };
        }).filter(function (it) { return it.title || it.link; });
        return { feedTitle: feedTitle, items: items };
    }

    function looksLikeFeed(body) {
        return /<(item|entry)[\s>]/i.test(body) && (/<rss/i.test(body) || /<feed/i.test(body) || /<channel/i.test(body));
    }

    async function fetchFromInstance(base, route) {
        const url = base.replace(/\/+$/, "") + (route.charAt(0) === "/" ? route : "/" + route);
        const response = await client.newRequest()
            .url(url)
            .method("GET")
            .header("User-Agent", UA)
            .header("Accept", "application/rss+xml, application/xml, text/xml, */*")
            .build()
            .execute();
        const body = String(response && response.content || "");
        return { ok: response.isSuccessful() && looksLikeFeed(body), status: response.statusCode, body: body };
    }

    async function feed(params) {
        params = params || {};
        let route = String(params.route || "").trim();
        if (!route) throw new Error("route 必填，如 /36kr/newsflashes（可用 routes 工具查字典）");
        // 允许直接传完整 URL（锁定单实例）
        let explicitBase = null;
        if (/^https?:\/\//i.test(route)) {
            const m = route.match(/^(https?:\/\/[^/]+)/i);
            explicitBase = m ? m[1] : null;
            route = route.slice(m[1].length) || "/";
        }
        if (explicitBase) {
            // SSRF：仅允许公网 http(s)
            const host = (explicitBase.split("://")[1] || "").toLowerCase();
            if (!host || host.indexOf(".") < 0 || host === "localhost" || /^(\d+\.){3}\d+$/.test(host.split(":")[0])) {
                throw new Error("实例地址需为公网域名");
            }
        }
        const limit = Math.max(1, Math.min(30, Number(params.limit) || 10));

        const bases = explicitBase ? [explicitBase]
            : (params.instance ? [params.instance] : INSTANCES);

        const errors = [];
        for (let i = 0; i < bases.length; i++) {
            const base = bases[i];
            try {
                const r = await fetchFromInstance(base, route);
                if (r.ok) {
                    const parsed = parseFeed(r.body);
                    return {
                        success: true,
                        route: route,
                        instance: base,
                        feedTitle: parsed.feedTitle,
                        count: Math.min(limit, parsed.items.length),
                        items: parsed.items.slice(0, limit)
                    };
                }
                errors.push(base + " → HTTP " + r.status + (r.status === 503 ? "（该路由在此实例不可用，可能上游反爬）" : ""));
            } catch (e) {
                errors.push(base + " → " + (e && e.message ? e.message : String(e)));
            }
        }
        throw new Error("所有实例均失败：" + errors.join("；") + "。提示：路由在公共实例上可能因上游反爬失效，可换实例（instance 参数）或换路由（routes 字典里 verified=true 的最稳）");
    }

    function routes(params) {
        params = params || {};
        const kw = String(params.keyword || "").toLowerCase();
        const list = ROUTE_DICT.filter(function (r) {
            if (!kw) return true;
            return (r.route + " " + r.name + " " + r.category + " " + r.note).toLowerCase().indexOf(kw) >= 0;
        });
        return { success: true, total: list.length, hint: "verified=true 为实测/热榜确认可用；路由详情文档被墙，新路由可通过 mirror (rsshub-docs-mirror.github.io) 查", routes: list };
    }

    return { feed: feed, routes: routes };
})();

exports.feed = rsshub_monitorPackage.feed;
exports.routes = rsshub_monitorPackage.routes;
