/*
METADATA
{
    "name": "scraper",
    "description": "综合爬虫工具：单页/批量抓取、简易 CSS 选择器提取、缓存与历史。搜索请先用 various_search，再把结果传入 search_and_scrape(source_text=...)。",
    "tools": [
        {
            "name": "scrape",
            "description": "爬取单个网页。可选用简易 CSS 选择器提取标题/正文/链接/图片。",
            "parameters": [
                {
                    "name": "url",
                    "description": "要爬取的网页 URL",
                    "type": "string",
                    "required": true
                },
                {
                    "name": "selector",
                    "description": "简易选择器：标签如 h1/p，class 如 .title，id 如 #content；也可用 text/links/images",
                    "type": "string",
                    "required": false
                },
                {
                    "name": "include_links",
                    "description": "是否额外提取页面链接，默认 false",
                    "type": "boolean",
                    "required": false
                },
                {
                    "name": "include_images",
                    "description": "是否额外提取图片 URL，默认 false",
                    "type": "boolean",
                    "required": false
                },
                {
                    "name": "max_items",
                    "description": "选择器/链接/图片最大条数，默认 50",
                    "type": "number",
                    "required": false
                },
                {
                    "name": "cache",
                    "description": "是否使用缓存，默认 true",
                    "type": "boolean",
                    "required": false
                }
            ]
        },
        {
            "name": "batch_scrape",
            "description": "批量爬取多个 URL。urls 用逗号或换行分隔。",
            "parameters": [
                {
                    "name": "urls",
                    "description": "URL 列表，逗号或换行分隔",
                    "type": "string",
                    "required": true
                },
                {
                    "name": "selector",
                    "description": "简易选择器，可选",
                    "type": "string",
                    "required": false
                },
                {
                    "name": "max_items",
                    "description": "每页最大提取条数，默认 30",
                    "type": "number",
                    "required": false
                },
                {
                    "name": "cache",
                    "description": "是否使用缓存，默认 true",
                    "type": "boolean",
                    "required": false
                }
            ]
        },
        {
            "name": "search_and_scrape",
            "description": "对外部搜索结果做解析，可选继续爬取前 N 条正文。必须传入 source_text（various_search 的 content）或 results。本包不直连搜索引擎。",
            "parameters": [
                {
                    "name": "query",
                    "description": "原始搜索词（记录用）",
                    "type": "string",
                    "required": true
                },
                {
                    "name": "source_text",
                    "description": "various_search 等返回的搜索原文 content",
                    "type": "string",
                    "required": false
                },
                {
                    "name": "results",
                    "description": "结构化结果 JSON 字符串/数组，元素含 title/url/snippet",
                    "type": "string",
                    "required": false
                },
                {
                    "name": "max_results",
                    "description": "最多处理条数，默认 5，最大 10",
                    "type": "number",
                    "required": false
                },
                {
                    "name": "scrape_content",
                    "description": "是否继续爬取每个结果页面正文，默认 false",
                    "type": "boolean",
                    "required": false
                },
                {
                    "name": "selector",
                    "description": "爬取正文时的选择器，可选",
                    "type": "string",
                    "required": false
                }
            ]
        },
        {
            "name": "parse_html",
            "description": "本地解析 HTML 文本，用简易选择器提取内容。不访问网络。",
            "parameters": [
                {
                    "name": "html",
                    "description": "HTML 或纯文本内容",
                    "type": "string",
                    "required": true
                },
                {
                    "name": "selector",
                    "description": "简易选择器：h1/.title/#id/text/links/images",
                    "type": "string",
                    "required": true
                },
                {
                    "name": "max_items",
                    "description": "最大条数，默认 50",
                    "type": "number",
                    "required": false
                }
            ]
        },
        {
            "name": "get_cache",
            "description": "读取某个 URL 的缓存内容",
            "parameters": [
                {
                    "name": "url",
                    "description": "缓存对应的 URL",
                    "type": "string",
                    "required": true
                }
            ]
        },
        {
            "name": "clear_cache",
            "description": "清除缓存。不传 url 则清空全部缓存。",
            "parameters": [
                {
                    "name": "url",
                    "description": "可选，指定 URL；不传则清空全部",
                    "type": "string",
                    "required": false
                }
            ]
        },
        {
            "name": "get_history",
            "description": "获取最近爬取历史",
            "parameters": [
                {
                    "name": "limit",
                    "description": "返回条数，默认 20，最大 100",
                    "type": "number",
                    "required": false
                }
            ]
        }
    ]
}
*/

// ===================== 配置 =====================
const PKG = "scraper";
const ROOT = "/sdcard/Download/Operit/scraper";
const CACHE_DIR = ROOT + "/cache";
const HISTORY_PATH = ROOT + "/history/history.json";
const RESULTS_DIR = ROOT + "/results";
const CACHE_TTL_MS = 3600 * 1000;

const HTTP_HEADERS = {
  "User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
  "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
  "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8"
};

// ===================== 基础 =====================
function ok(data, message) {
  const payload = { success: true, message: message || "ok", data: data };
  if (typeof complete === "function") complete(payload);
  return payload;
}

function fail(message, extra) {
  const payload = Object.assign({ success: false, message: String(message || "error") }, extra || {});
  if (typeof complete === "function") complete(payload);
  return payload;
}

function clamp(n, a, b) {
  n = Number(n);
  if (!isFinite(n)) return a;
  return Math.max(a, Math.min(b, n));
}

function nowIso() {
  return new Date().toISOString();
}

function stripHtml(s) {
  return String(s || "")
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/"/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

function simpleHash(str) {
  let h = 0;
  const s = String(str || "");
  for (let i = 0; i < s.length; i++) {
    h = ((h << 5) - h) + s.charCodeAt(i);
    h |= 0;
  }
  return Math.abs(h).toString(16);
}

function cacheKeyForUrl(url) {
  return simpleHash(String(url || "").trim());
}

// ===================== 文件 IO =====================
async function ensureDirs() {
  if (!Tools || !Tools.Files || typeof Tools.Files.mkdir !== "function") return;
  try {
    await Tools.Files.mkdir(ROOT, true, "android");
    await Tools.Files.mkdir(CACHE_DIR, true, "android");
    await Tools.Files.mkdir(ROOT + "/history", true, "android");
    await Tools.Files.mkdir(RESULTS_DIR, true, "android");
  } catch (e) {}
}

async function readTextFile(path) {
  try {
    if (!Tools || !Tools.Files || typeof Tools.Files.read !== "function") return "";
    let r;
    try {
      r = await Tools.Files.read({ path: path, environment: "android" });
    } catch (e1) {
      r = await Tools.Files.read(path);
    }
    if (r == null) return "";
    if (typeof r === "string") return r;
    if (typeof r.content === "string") return r.content;
    if (r.data && typeof r.data.content === "string") return r.data.content;
    return "";
  } catch (e) {
    return "";
  }
}

async function writeTextFile(path, content) {
  try {
    if (!Tools || !Tools.Files || typeof Tools.Files.write !== "function") return false;
    const text = String(content == null ? "" : content);
    try {
      await Tools.Files.write(path, text, false, "android");
    } catch (e1) {
      await Tools.Files.write(path, text, false);
    }
    return true;
  } catch (e) {
    return false;
  }
}

async function fileExists(path) {
  try {
    if (!Tools || !Tools.Files || typeof Tools.Files.exists !== "function") return false;
    const r = await Tools.Files.exists(path, "android");
    if (r === true) return true;
    if (r && r.exists === true) return true;
    if (r && r.data && r.data.exists === true) return true;
    return !!r;
  } catch (e) {
    return false;
  }
}

// ===================== HTTP =====================
async function httpGetText(url) {
  if (!Tools || !Tools.Net || typeof Tools.Net.http !== "function") {
    throw new Error("Tools.Net.http unavailable in sandbox");
  }
  const resp = await Tools.Net.http({
    url: url,
    method: "GET",
    headers: HTTP_HEADERS,
    follow_redirects: true,
    connect_timeout: 20000,
    read_timeout: 45000,
    validateStatus: false
  });
  if (resp == null) return "";

  const saved =
    resp.content_saved_to ||
    (resp.data && resp.data.content_saved_to) ||
    resp.output_saved_to ||
    "";
  if (saved) {
    const fileText = await readTextFile(saved);
    if (fileText) return fileText;
  }

  if (typeof resp.content === "string") return resp.content;
  if (typeof resp.body === "string") return resp.body;
  if (typeof resp.text === "string") return resp.text;
  if (typeof resp === "string") return resp;
  if (resp.data && typeof resp.data.content === "string") return resp.data.content;
  return "";
}

// ===================== 解析 =====================
function extractLinks(html, maxItems) {
  const out = [];
  const seen = {};
  const re = /href\s*=\s*["'](https?:\/\/[^"'>\s]+)["']/gi;
  let m;
  while ((m = re.exec(html)) !== null) {
    const u = m[1].replace(/[),.]+$/, "");
    if (!u || seen[u]) continue;
    seen[u] = 1;
    out.push(u);
    if (out.length >= maxItems) break;
  }
  return out;
}

function extractImages(html, maxItems) {
  const out = [];
  const seen = {};
  const re = /(?:src|data-src)\s*=\s*["'](https?:\/\/[^"'>\s]+\.(?:jpg|jpeg|png|gif|webp|svg)[^"'>\s]*)["']/gi;
  let m;
  while ((m = re.exec(html)) !== null) {
    const u = m[1];
    if (!u || seen[u]) continue;
    seen[u] = 1;
    out.push(u);
    if (out.length >= maxItems) break;
  }
  return out;
}

function extractTitle(html) {
  const m = String(html || "").match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  return m ? stripHtml(m[1]) : "";
}

function extractWithSelector(html, selector, maxItems) {
  maxItems = clamp(maxItems || 50, 1, 200);
  const raw = String(html || "");
  const sel = String(selector || "").trim();
  if (!sel || sel === "text") {
    return [stripHtml(raw).slice(0, 8000)];
  }
  if (sel === "links") return extractLinks(raw, maxItems);
  if (sel === "images") return extractImages(raw, maxItems);
  if (sel === "title") {
    const t = extractTitle(raw);
    return t ? [t] : [];
  }

  // tag: h1 / p / div
  if (/^[a-zA-Z][a-zA-Z0-9]*$/.test(sel)) {
    const re = new RegExp("<" + sel + "\\b[^>]*>([\\s\\S]*?)<\\/" + sel + ">", "gi");
    const out = [];
    let m;
    while ((m = re.exec(raw)) !== null) {
      const t = stripHtml(m[1]);
      if (t) out.push(t);
      if (out.length >= maxItems) break;
    }
    return out;
  }

  // .class
  if (sel.charAt(0) === ".") {
    const className = sel.slice(1).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const re = new RegExp("class=[\"'][^\"']*" + className + "[^\"']*[\"'][^>]*>([\\s\\S]*?)<\\/", "gi");
    const out = [];
    let m;
    while ((m = re.exec(raw)) !== null) {
      const t = stripHtml(m[1]);
      if (t) out.push(t);
      if (out.length >= maxItems) break;
    }
    return out;
  }

  // #id
  if (sel.charAt(0) === "#") {
    const idName = sel.slice(1).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const re = new RegExp("id=[\"']" + idName + "[\"'][^>]*>([\\s\\S]*?)<\\/", "gi");
    const out = [];
    let m;
    while ((m = re.exec(raw)) !== null) {
      const t = stripHtml(m[1]);
      if (t) out.push(t);
      if (out.length >= maxItems) break;
    }
    return out;
  }

  return [stripHtml(raw).slice(0, 8000)];
}

function parseSearchResults(text) {
  const out = [];
  const seen = {};
  const lines = String(text || "").split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    // [n] title - https://...
    let m = line.match(/^\[(\d+)\]\s+(.+)$/);
    if (m) {
      const rest = m[2];
      const urls = rest.match(/https?:\/\/[^\s]+/g) || [];
      if (!urls.length) continue;
      const url = urls[urls.length - 1].replace(/[),.]+$/, "");
      let title = rest
        .replace(/\s+-\s+https?:\/\/\S+$/, "")
        .replace(/https?:\/\/\S+/g, " ")
        .replace(/翻译此结果/g, "")
        .replace(/\s+/g, " ")
        .trim();
      if (!title) title = url;
      if (seen[url]) continue;
      seen[url] = 1;
      out.push({ index: Number(m[1]), title: title, url: url, snippet: "" });
      continue;
    }

    // 1. title - url
    m = line.match(/^\d+\.\s+(.+?)\s+-\s+(https?:\/\/\S+)$/);
    if (m) {
      const url = m[2].replace(/[),.]+$/, "");
      if (seen[url]) continue;
      seen[url] = 1;
      out.push({ title: m[1].trim(), url: url, snippet: "" });
    }
  }
  return out;
}

function parseExternalResults(params) {
  const out = [];
  const seen = {};

  function pushItem(it) {
    if (!it || typeof it !== "object") return;
    const url = String(it.url || it.link || it.href || "").trim();
    if (!/^https?:\/\//i.test(url) || seen[url]) return;
    seen[url] = 1;
    out.push({
      title: stripHtml(it.title || it.name || "") || url,
      url: url,
      snippet: stripHtml(it.snippet || it.description || it.desc || "")
    });
  }

  let rawResults = params && params.results;
  if (rawResults != null) {
    if (typeof rawResults === "string") {
      const t = rawResults.trim();
      if (t) {
        try {
          rawResults = JSON.parse(t);
        } catch (e) {
          const parsed = parseSearchResults(t);
          for (let i = 0; i < parsed.length; i++) pushItem(parsed[i]);
          rawResults = null;
        }
      } else {
        rawResults = null;
      }
    }
    if (Array.isArray(rawResults)) {
      for (let i = 0; i < rawResults.length; i++) pushItem(rawResults[i]);
    } else if (rawResults && typeof rawResults === "object") {
      const list =
        (Array.isArray(rawResults.results) && rawResults.results) ||
        (Array.isArray(rawResults.items) && rawResults.items) ||
        null;
      if (list) {
        for (let i = 0; i < list.length; i++) pushItem(list[i]);
      }
    }
  }

  if (!out.length && params && params.source_text) {
    const parsed = parseSearchResults(params.source_text);
    for (let i = 0; i < parsed.length; i++) pushItem(parsed[i]);
  }
  return out;
}

// ===================== 缓存 / 历史 =====================
async function readCache(url) {
  const key = cacheKeyForUrl(url);
  const path = CACHE_DIR + "/" + key + ".json";
  const text = await readTextFile(path);
  if (!text) return null;
  try {
    const obj = JSON.parse(text);
    if (!obj || !obj.saved_at) return null;
    if (Date.now() - Number(obj.saved_at) > CACHE_TTL_MS) return null;
    return obj;
  } catch (e) {
    return null;
  }
}

async function writeCache(url, payload) {
  await ensureDirs();
  const key = cacheKeyForUrl(url);
  const path = CACHE_DIR + "/" + key + ".json";
  const obj = Object.assign({}, payload || {}, {
    url: url,
    saved_at: Date.now(),
    saved_at_iso: nowIso()
  });
  await writeTextFile(path, JSON.stringify(obj));
  return key;
}

async function appendHistory(entry) {
  await ensureDirs();
  let list = [];
  const text = await readTextFile(HISTORY_PATH);
  if (text) {
    try {
      const parsed = JSON.parse(text);
      if (Array.isArray(parsed)) list = parsed;
    } catch (e) {}
  }
  list.unshift(Object.assign({ at: nowIso() }, entry || {}));
  if (list.length > 100) list = list.slice(0, 100);
  await writeTextFile(HISTORY_PATH, JSON.stringify(list, null, 2));
}

async function saveResultSnapshot(data) {
  await ensureDirs();
  const name = Date.now() + ".json";
  const path = RESULTS_DIR + "/" + name;
  await writeTextFile(path, JSON.stringify(data || {}, null, 2));
  return path;
}

// ===================== 核心抓取 =====================
async function fetchPage(url, useCache) {
  if (useCache !== false) {
    const cached = await readCache(url);
    if (cached && cached.html != null) {
      return { html: cached.html, from_cache: true, title: cached.title || extractTitle(cached.html) };
    }
  }
  const html = await httpGetText(url);
  const title = extractTitle(html);
  if (useCache !== false && html) {
    await writeCache(url, { html: html, title: title });
  }
  return { html: html || "", from_cache: false, title: title };
}

// ===================== 工具实现 =====================
async function scrape(params) {
  try {
    const url = String((params && params.url) || "").trim();
    if (!url) return fail("url 不能为空");
    if (!/^https?:\/\//i.test(url)) return fail("url 必须以 http/https 开头");

    const selector = params && params.selector ? String(params.selector).trim() : "";
    const include_links = !!(params && params.include_links);
    const include_images = !!(params && params.include_images);
    const max_items = clamp((params && params.max_items) || 50, 1, 200);
    const useCache = params && params.cache === false ? false : true;

    await ensureDirs();
    const page = await fetchPage(url, useCache);
    if (!page.html) {
      await appendHistory({ action: "scrape", url: url, success: false, reason: "empty" });
      return fail("页面内容为空或抓取失败: " + url);
    }

    const data = {
      url: url,
      title: page.title || "",
      from_cache: page.from_cache,
      timestamp: nowIso()
    };

    if (selector) {
      data.selector = selector;
      data.content = extractWithSelector(page.html, selector, max_items);
    } else {
      data.content = stripHtml(page.html).slice(0, 8000);
    }

    if (include_links) data.links = extractLinks(page.html, max_items);
    if (include_images) data.images = extractImages(page.html, max_items);

    await appendHistory({ action: "scrape", url: url, success: true, from_cache: page.from_cache });
    await saveResultSnapshot({ type: "scrape", data: data });
    return ok(data, page.from_cache ? "爬取完成（缓存）" : "爬取完成");
  } catch (e) {
    return fail(e && e.message ? e.message : e);
  }
}

async function batch_scrape(params) {
  try {
    const raw = String((params && params.urls) || "").trim();
    if (!raw) return fail("urls 不能为空");
    const selector = params && params.selector ? String(params.selector).trim() : "";
    const max_items = clamp((params && params.max_items) || 30, 1, 200);
    const useCache = params && params.cache === false ? false : true;

    const urlList = raw
      .split(/[\n,]+/)
      .map(function (x) { return x.trim(); })
      .filter(function (x) { return /^https?:\/\//i.test(x); });

    if (!urlList.length) return fail("未解析到有效 URL");

    await ensureDirs();
    const results = [];
    for (let i = 0; i < urlList.length; i++) {
      const url = urlList[i];
      try {
        const page = await fetchPage(url, useCache);
        if (!page.html) {
          results.push({ url: url, success: false, error: "empty" });
          continue;
        }
        const item = {
          url: url,
          title: page.title || "",
          from_cache: page.from_cache,
          success: true
        };
        if (selector) item.content = extractWithSelector(page.html, selector, max_items);
        else item.content = stripHtml(page.html).slice(0, 3000);
        results.push(item);
      } catch (err) {
        results.push({
          url: url,
          success: false,
          error: err && err.message ? err.message : String(err)
        });
      }
    }

    const data = {
      total: urlList.length,
      successful: results.filter(function (r) { return r.success; }).length,
      failed: results.filter(function (r) { return !r.success; }).length,
      results: results,
      timestamp: nowIso()
    };
    await appendHistory({ action: "batch_scrape", total: data.total, successful: data.successful });
    await saveResultSnapshot({ type: "batch_scrape", data: data });
    return ok(data, "批量爬取完成");
  } catch (e) {
    return fail(e && e.message ? e.message : e);
  }
}

async function search_and_scrape(params) {
  try {
    const query = String((params && params.query) || "").trim();
    if (!query) return fail("query 不能为空");

    const hasExternal =
      (params && params.source_text && String(params.source_text).trim()) ||
      (params && params.results != null && String(params.results).trim() !== "");
    if (!hasExternal) {
      return fail("search_and_scrape 需要 source_text 或 results。本包不直连搜索。", {
        data: {
          tip: "推荐：various_search:search_bing → scraper:search_and_scrape(query, source_text=content)"
        }
      });
    }

    const max_results = clamp((params && params.max_results) || 5, 1, 10);
    const scrape_content = !!(params && params.scrape_content);
    const selector = params && params.selector ? String(params.selector).trim() : "";

    const parsed = parseExternalResults(params).slice(0, max_results);
    if (!parsed.length) {
      return fail("未能从 source_text/results 解析出有效链接", {
        data: { query: query, tip: "确认传入 various_search 的 content 原文" }
      });
    }

    await ensureDirs();
    const results = [];
    for (let i = 0; i < parsed.length; i++) {
      const it = parsed[i];
      const row = {
        title: it.title,
        url: it.url,
        snippet: it.snippet || ""
      };
      if (scrape_content) {
        try {
          const page = await fetchPage(it.url, true);
          if (selector) row.content = extractWithSelector(page.html, selector, 30);
          else row.content = stripHtml(page.html).slice(0, 2000);
          row.title = row.title || page.title || it.url;
          row.scraped = true;
        } catch (err) {
          row.scraped = false;
          row.error = err && err.message ? err.message : String(err);
        }
      }
      results.push(row);
    }

    const data = {
      query: query,
      mode: "external_search",
      result_count: results.length,
      scrape_content: scrape_content,
      results: results,
      timestamp: nowIso()
    };
    await appendHistory({ action: "search_and_scrape", query: query, count: results.length });
    await saveResultSnapshot({ type: "search_and_scrape", data: data });
    return ok(data, "搜索结果处理完成");
  } catch (e) {
    return fail(e && e.message ? e.message : e);
  }
}

async function parse_html(params) {
  try {
    const html = String((params && params.html) || "");
    if (!html.trim()) return fail("html 不能为空");
    const selector = String((params && params.selector) || "").trim();
    if (!selector) return fail("selector 不能为空");
    const max_items = clamp((params && params.max_items) || 50, 1, 200);

    const content = extractWithSelector(html, selector, max_items);
    return ok({
      selector: selector,
      count: Array.isArray(content) ? content.length : 1,
      content: content,
      timestamp: nowIso()
    }, "解析完成");
  } catch (e) {
    return fail(e && e.message ? e.message : e);
  }
}

async function get_cache(params) {
  try {
    const url = String((params && params.url) || "").trim();
    if (!url) return fail("url 不能为空");
    const cached = await readCache(url);
    if (!cached) return fail("缓存不存在或已过期", { data: { url: url } });
    return ok({
      url: url,
      title: cached.title || "",
      saved_at_iso: cached.saved_at_iso || "",
      content_preview: stripHtml(cached.html || "").slice(0, 500)
    }, "缓存命中");
  } catch (e) {
    return fail(e && e.message ? e.message : e);
  }
}

async function clear_cache(params) {
  try {
    await ensureDirs();
    const url = params && params.url ? String(params.url).trim() : "";
    if (url) {
      const key = cacheKeyForUrl(url);
      const path = CACHE_DIR + "/" + key + ".json";
      await writeTextFile(path, "");
      return ok({ cleared: "one", url: url }, "已清除指定缓存");
    }
    // 无 list API 时用占位：写空 marker，提示用户可手动清目录
    await writeTextFile(CACHE_DIR + "/.cleared_at", nowIso());
    return ok({
      cleared: "marker",
      tip: "已写入清空标记。若需彻底删除，请手动清空 " + CACHE_DIR
    }, "缓存清理标记已写入");
  } catch (e) {
    return fail(e && e.message ? e.message : e);
  }
}

async function get_history(params) {
  try {
    const limit = clamp((params && params.limit) || 20, 1, 100);
    const text = await readTextFile(HISTORY_PATH);
    let list = [];
    if (text) {
      try {
        const parsed = JSON.parse(text);
        if (Array.isArray(parsed)) list = parsed;
      } catch (e) {}
    }
    return ok({
      count: Math.min(limit, list.length),
      history: list.slice(0, limit)
    }, "历史读取完成");
  } catch (e) {
    return fail(e && e.message ? e.message : e);
  }
}

// ===================== 导出 =====================
exports.scrape = scrape;
exports.batch_scrape = batch_scrape;
exports.search_and_scrape = search_and_scrape;
exports.parse_html = parse_html;
exports.get_cache = get_cache;
exports.clear_cache = clear_cache;
exports.get_history = get_history;
