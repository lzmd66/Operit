/*
METADATA
{
    "name": "game_price_kit",
    "display_name": {
        "zh": "游戏价格查询",
        "en": "Game Price Query"
    },
    "description": {
        "zh": "查询港区游戏价格、折扣与热度。三平台九工具：Steam（搜索 / 查价 / 在线人数 / 特惠列表）、PS5（搜索 / 优惠列表）、NS（搜索 / 减价列表）、网络诊断（net_diag）。Steam 走官方接口秒回，内置三级降级：OkHttp → Tools.Net.http → DoH 解析真 IP + IP 直连（绕 DNS 污染）；PS5/NS 基于应用内浏览器渲染，单次约 10-15 秒。折扣列表覆盖：Steam 约 8900 款 / PS5 约 3100 款 / NS 约 1000 件在打折。全链路自守卫超时，坏网络日绝不无限挂死。",
        "en": "Query game prices and deals in HK region: Steam (search/price/players/deals), PS Store HK (search/deals), Nintendo HK (search/deals)."
    },
    "category": "Game",
    "tools": [
        {
            "name": "steam_search",
            "description": {
                "zh": "按关键词搜索 Steam 游戏，返回匹配游戏的 appid、港区价格、折扣、Metascore 与支持平台。用于先找到游戏的 appid，再配合 steam_price 查询详情。",
                "en": "Search Steam games by keyword, returning appid, price, discount, metascore and platforms."
            },
            "parameters": [
                {
                    "name": "keyword",
                    "description": { "zh": "游戏名称关键词，支持中文或英文，例如「艾尔登法环」。", "en": "Game name keyword, e.g. 'Elden Ring'." },
                    "type": "string",
                    "required": true
                },
                {
                    "name": "cc",
                    "description": { "zh": "地区代码，默认 hk（港区）。可选 us、cn、jp 等。", "en": "Region code, default hk." },
                    "type": "string",
                    "required": false
                }
            ]
        },
        {
            "name": "steam_price",
            "description": {
                "zh": "按 appid 查询 Steam 游戏在指定地区的价格与折扣详情。",
                "en": "Query Steam game price detail by appid."
            },
            "parameters": [
                {
                    "name": "appid",
                    "description": { "zh": "Steam 游戏的 appid，例如 1245620。", "en": "Steam appid, e.g. 1245620." },
                    "type": "string",
                    "required": true
                },
                {
                    "name": "cc",
                    "description": { "zh": "地区代码，默认 hk（港区）。", "en": "Region code, default hk." },
                    "type": "string",
                    "required": false
                }
            ]
        },
        {
            "name": "steam_players",
            "description": {
                "zh": "查询 Steam 游戏的当前在线人数，用于判断热度。",
                "en": "Query the current player count of a Steam game."
            },
            "parameters": [
                {
                    "name": "appid",
                    "description": { "zh": "Steam 游戏的 appid。", "en": "Steam appid." },
                    "type": "string",
                    "required": true
                }
            ]
        },
        {
            "name": "ps5_search",
            "description": {
                "zh": "搜索 PlayStation Store 港区（zh-hans-hk）游戏，返回商品名、价格、折扣与平台标签。基于应用内浏览器实时渲染提取，单次约需 10-15 秒。",
                "en": "Search PlayStation Store HK region games with prices via the in-app browser."
            },
            "parameters": [
                {
                    "name": "keyword",
                    "description": { "zh": "游戏名称关键词，支持中文或英文，例如「god of war」。", "en": "Game name keyword." },
                    "type": "string",
                    "required": true
                }
            ]
        },
        {
            "name": "ns_search",
            "description": {
                "zh": "搜索香港 Nintendo eShop（store.nintendo.com.hk）游戏，返回商品名、HKD 价格与发售日。经浏览器通过站点 WAF 人机验证后直接抓取数据（不依赖页面渲染），单次约 10-20 秒。",
                "en": "Search Nintendo HK eShop games with HKD prices via the in-app browser."
            },
            "parameters": [
                {
                    "name": "keyword",
                    "description": { "zh": "游戏名称关键词，支持繁体或英文，例如「薩爾達」。", "en": "Game name keyword." },
                    "type": "string",
                    "required": true
                }
            ]
        },
        {
            "name": "steam_deals",
            "description": {
                "zh": "查询 Steam 港区当前正在打折的游戏（官方特惠接口，全站约 8900+ 款在打折），返回最热门的一批折扣：名称、折扣%、现价、原价。用于回答「Steam 最近有什么打折」。",
                "en": "List currently discounted games on Steam HK store."
            },
            "parameters": [
                {
                    "name": "count",
                    "description": { "zh": "返回条数，默认 30，最多 100。", "en": "Number of items, default 30, max 100." },
                    "type": "number",
                    "required": false
                }
            ]
        },
        {
            "name": "ps5_deals",
            "description": {
                "zh": "查询 PlayStation Store 港区「所有优惠」列表（共 3100+ 款在打折），返回当前页 24 条：名称、版本标签、折扣%、现价与原价，按官方「最畅销」排序。基于应用内浏览器渲染，单次约 10-15 秒。",
                "en": "List PS Store HK deals (all discounts), sorted by best-selling."
            },
            "parameters": [
                {
                    "name": "page",
                    "description": { "zh": "页码，默认 1（共约 130 页，每页 24 条）。", "en": "Page number, default 1." },
                    "type": "number",
                    "required": false
                }
            ]
        },
        {
            "name": "ns_deals",
            "description": {
                "zh": "查询香港 Nintendo eShop「减价」专区（约 1000 件在打折），返回当前页 12 条：名称、发售日、现价与原价。可选按折扣率排序。直接抓取数据（不依赖页面渲染），单次约 10-20 秒。",
                "en": "List Nintendo HK eShop current offers."
            },
            "parameters": [
                {
                    "name": "page",
                    "description": { "zh": "页码，默认 1（共约 84 页，每页 12 条）。", "en": "Page number, default 1." },
                    "type": "number",
                    "required": false
                },
                {
                    "name": "sort",
                    "description": { "zh": "排序：留空=官方默认（主流游戏优先）；填 discount=按折扣率高到低。", "en": "Sort: empty=default, 'discount'=by discount rate desc." },
                    "type": "string",
                    "required": false
                }
            ]
        },
        {
            "name": "net_diag",
            "description": {
                "zh": "网络诊断：测试 DoH 解析 + IP 直连绕污染链路是否可用。当 Steam 查询出现「网络不可达」时用它排障。",
                "en": "Network diagnostic for DoH resolve + direct-IP fallback."
            },
            "parameters": [
                {
                    "name": "host",
                    "description": { "zh": "要诊断的域名，默认 store.steampowered.com", "en": "Host to diagnose, default store.steampowered.com." },
                    "type": "string",
                    "required": false
                }
            ]
        }
    ]
}*/

const game_price_kit = (function () {

    // 长超时 + 连接失败自动重试：Steam 接口在国内网络下容易出现慢响应
    const client = OkHttp.newBuilder()
        .connectTimeout(20000)
        .readTimeout(30000)
        .writeTimeout(30000)
        .retryOnConnectionFailure(true)
        .build();
    const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
    const STEAM_STORE = "https://store.steampowered.com";
    const STEAM_API = "https://api.steampowered.com";

    /**
     * Steam 价格接口返回的是「分」为单位的整数，这里转成带货币符号的字符串。
     */
    function money(cents, currency) {
        if (cents === null || cents === undefined) {
            return null;
        }
        const amount = (cents / 100).toFixed(2);
        let symbol = currency ? String(currency) : "";
        if (currency === "HKD") {
            symbol = "HK$";
        } else if (currency === "CNY") {
            symbol = "\u00A5";
        } else if (currency === "USD") {
            symbol = "$";
        }
        return symbol + " " + amount;
    }

    function discountPercent(initial, final) {
        if (!initial || !final || initial <= final) {
            return 0;
        }
        return Math.round((1 - final / initial) * 100);
    }

    // ===== 网络层公共件：自守卫（2026-10-01 加固） =====
    const DOH_TIMEOUT_MS = 4000;
    const DOH_GRACE_MS = 500;
    const IP_TRY_TIMEOUT_MS = 8000;
    const GJSON_TRY_TIMEOUT_MS = 15000;
    const BROWSER_NAV_TIMEOUT_MS = 20000;
    const BROWSER_EVAL_TIMEOUT_MS = 15000;

    function msgOf(e) { return e && e.message ? e.message : String(e); }

    /** 给任意 Promise 加自守卫超时：到点即以 Error 拒绝，防止宿主层 timeout 参数不生效导致无限挂起。 */
    function raceGuard(promise, ms, label) {
        return new Promise(function (resolve, reject) {
            let done = false;
            const timer = setTimeout(function () {
                if (!done) { done = true; reject(new Error("guard-timeout " + ms + "ms" + (label ? "（" + label + "）" : ""))); }
            }, ms);
            promise.then(function (v) {
                if (!done) { done = true; clearTimeout(timer); resolve(v); }
            }, function (e) {
                if (!done) { done = true; clearTimeout(timer); reject(e); }
            });
        });
    }

    /** 查询单个 DoH 源（带自守卫超时，绝不无限挂起）。 */
    function queryDohSource(source, host, timeoutMs) {
        const started = Date.now();
        const url = source.url.replace("{host}", encodeURIComponent(host));
        return raceGuard(Tools.Net.http({
            url: url,
            method: "GET",
            connect_timeout: timeoutMs,
            read_timeout: timeoutMs,
            responseType: "text",
            validateStatus: false
        }), timeoutMs + 300, source.name).then(function (resp) {
            const ms = Date.now() - started;
            const text = resp && resp.content !== undefined ? resp.content : (resp ? resp.body : null);
            if (!text) return { name: source.name, ok: false, ms: ms, err: "空响应" };
            let data;
            try { data = JSON.parse(String(text)); } catch (e2) {
                return { name: source.name, ok: false, ms: ms, err: "非 JSON 响应" };
            }
            const answers = (data && data.Answer) || [];
            const ips = [];
            for (let j = 0; j < answers.length; j++) {
                const a = answers[j];
                if (a && a.type === 1 && a.data) ips.push(String(a.data));
            }
            return { name: source.name, ok: true, ms: ms, ips: ips };
        }, function (e) {
            return { name: source.name, ok: false, ms: Date.now() - started, err: msgOf(e) };
        });
    }

    /** 两源并行解析真 IP（每源自守卫；首个结果后再等 500ms 收集快源即返回，绝不等慢源/死源）。 */
    async function dohResolve(host) {
        const sources = [
            { name: "alidns", url: "https://dns.alidns.com/resolve?name={host}&type=A" },
            { name: "tencent", url: "https://doh.pub/dns-query?name={host}&type=A" }
        ];
        const details = [];
        for (let i = 0; i < sources.length; i++) details.push({ name: sources[i].name, status: "pending" });
        let gotAny = false;
        let overall = null;
        const collected = await new Promise(function (resolve) {
            let pending = sources.length;
            let graceTimer = null;
            let finished = false;
            function finish(why) {
                if (finished) return;
                finished = true;
                if (graceTimer) clearTimeout(graceTimer);
                if (overall) clearTimeout(overall);
                const snap = [];
                for (let k = 0; k < details.length; k++) {
                    const d = details[k];
                    if (d.status === "pending") snap.push(Object.assign({}, d, { status: "skipped(" + why + ")" }));
                    else snap.push(Object.assign({}, d));
                }
                resolve(snap);
            }
            overall = setTimeout(function () { finish("overall-cap"); }, DOH_TIMEOUT_MS + 800);
            sources.forEach(function (source, idx) {
                queryDohSource(source, host, DOH_TIMEOUT_MS).then(function (r) {
                    if (finished) return;
                    details[idx] = Object.assign({}, r, { status: "done" });
                    if (r.ok && r.ips && r.ips.length > 0) gotAny = true;
                    pending--;
                    if (gotAny && !graceTimer) {
                        graceTimer = setTimeout(function () { finish("first+grace"); }, DOH_GRACE_MS);
                    }
                    if (pending === 0) {
                        clearTimeout(overall);
                        finish("all-settled");
                    }
                });
            });
        });
        const ips = [];
        const seen = {};
        for (let i = 0; i < collected.length; i++) {
            const srcIps = (collected[i] && collected[i].ips) || [];
            for (let j = 0; j < srcIps.length; j++) {
                if (!seen[srcIps[j]]) { seen[srcIps[j]] = 1; ips.push(srcIps[j]); }
            }
        }
        return ips;
    }

    /** 判断响应是否"疑似空结果"（用于触发换 IP 重试，防 CDN 边缘静默返回空） */
    function isEmptyResult(obj) {
        if (!obj || typeof obj !== "object") {
            return false;
        }
        if (Array.isArray(obj)) {
            return obj.length === 0;
        }
        if (obj.items && Array.isArray(obj.items) && obj.items.length === 0 && obj.total === 0) {
            return true;
        }
        return false;
    }

    /**
     * 第 3 层兜底：DoH 拿真实 IP → IP 直连（SNI=IP，忽略证书校验）+ Host 头写域名。
     * 原理同 steam302.py，但内置在包内、无需 Termux 常驻。
     * 多 IP 逐个尝试；返回"空结果"视为可疑，换下一个 IP。
     */
    async function fetchViaDoh(rawUrl) {
        if (typeof toolCall !== "function") {
            throw new Error("当前沙盒不支持 toolCall，无法使用 DoH 直连兜底");
        }
        const m = String(rawUrl).match(/^https:\/\/([^\/]+)(\/[\s\S]*)?$/);
        if (!m) {
            throw new Error("DoH 兜底仅支持 https URL");
        }
        const host = m[1];
        const path = m[2] ? m[2] : "/";
        const ips = await dohResolve(host);
        if (!ips.length) {
            throw new Error("DoH 解析 " + host + " 未获得可用 IP");
        }
        const tryList = ips.slice(0, 3);
        let lastMsg = "";
        for (let i = 0; i < tryList.length; i++) {
            const ip = tryList[i];
            try {
                const resp = await raceGuard(toolCall({
                    name: "http_request",
                    params: {
                        url: "https://" + ip + path,
                        method: "GET",
                        headers: JSON.stringify({
                            "Host": host,
                            "User-Agent": UA,
                            "Accept": "application/json, text/plain, */*",
                            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8"
                        }),
                        ignore_ssl: true
                    }
                }), IP_TRY_TIMEOUT_MS, "IP " + ip);
                const status = resp && (resp.statusCode !== undefined ? resp.statusCode : resp.status);
                const text = resp && (resp.content !== undefined ? resp.content : resp.body);
                if (status !== 200 || text === null || text === undefined) {
                    lastMsg = "IP " + ip + " 返回 HTTP " + status;
                    continue;
                }
                const parsed = JSON.parse(String(text));
                if (isEmptyResult(parsed) && i < tryList.length - 1) {
                    lastMsg = "IP " + ip + " 返回空结果（疑似 CDN 边缘静默错误）";
                    console.log("[game_price_kit] " + lastMsg + "，换 IP 重试");
                    continue;
                }
                console.log("[game_price_kit] DoH 直连成功（IP " + ip + "）");
                return parsed;
            }
            catch (e) {
                lastMsg = "IP " + ip + " 失败: " + (e && e.message ? e.message : String(e));
                console.log("[game_price_kit] " + lastMsg);
            }
        }
        throw new Error("DoH 直连全部失败：" + lastMsg);
    }

    /** 网络诊断：测 DoH 解析 + IP 直连链路（排障用） */
    async function net_diag(params) {
        const host = (params && params.host) ? String(params.host) : "store.steampowered.com";
        const result = { host: host, steps: [] };
        let ips = [];
        try {
            ips = await dohResolve(host);
            result.steps.push({ step: "DoH 解析", ok: ips.length > 0, ip_count: ips.length, ips: ips });
        }
        catch (e) {
            result.steps.push({ step: "DoH 解析", ok: false, error: String(e && e.message ? e.message : e) });
        }
        if (ips.length > 0) {
            const testUrl = "https://" + ips[0] + "/api/appdetails?appids=1245620&cc=hk&filters=price_overview";
            try {
                const resp = await raceGuard(toolCall({
                    name: "http_request",
                    params: {
                        url: testUrl,
                        method: "GET",
                        headers: JSON.stringify({ "Host": host, "User-Agent": UA }),
                        ignore_ssl: true
                    }
                }), IP_TRY_TIMEOUT_MS, "IP直连");
                const status = resp && (resp.statusCode !== undefined ? resp.statusCode : resp.status);
                const text = resp && (resp.content !== undefined ? resp.content : resp.body);
                result.steps.push({
                    step: "IP 直连（" + ips[0] + "）",
                    ok: status === 200 && !!text,
                    status: status,
                    preview: text ? String(text).slice(0, 150) : null
                });
            }
            catch (e2) {
                result.steps.push({ step: "IP 直连（" + ips[0] + "）", ok: false, error: String(e2 && e2.message ? e2.message : e2) });
            }
        }
        let allOk = result.steps.length > 0;
        for (let i = 0; i < result.steps.length; i++) {
            if (!result.steps[i].ok) {
                allOk = false;
            }
        }
        result.conclusion = allOk ? "DoH + IP 直连链路正常，第 3 层兜底可用" : "存在失败步骤，请看 steps";
        return result;
    }

    async function getJson(url) {
        const maxAttempts = 2;
        let lastError = null;
        for (let attempt = 0; attempt < maxAttempts; attempt++) {
            try {
                const request = client.newRequest()
                    .url(url)
                    .method("GET")
                    .headers({
                        "User-Agent": UA,
                        "Accept": "application/json, text/plain, */*",
                        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8"
                    });
                const response = await raceGuard(request.build().execute(), GJSON_TRY_TIMEOUT_MS, "OkHttp");
                if (!response.isSuccessful()) {
                    throw new Error("HTTP " + response.statusCode + " 请求失败");
                }
                const text = response.content;
                try {
                    return JSON.parse(text);
                }
                catch (parseErr) {
                    throw new Error("响应不是合法 JSON（可能被拦截或为空），前 200 字符: " + String(text).slice(0, 200));
                }
            }
            catch (e) {
                lastError = e;
                const msg = e && e.message ? e.message : String(e);
                const isNetworkIssue = msg.indexOf("failed to connect") >= 0
                    || msg.indexOf("timeout") >= 0
                    || msg.indexOf("resolve") >= 0;
                if (!isNetworkIssue || attempt === maxAttempts - 1) {
                    break;
                }
                console.log("[game_price_kit] 第 " + (attempt + 1) + " 次请求失败，重试中: " + msg);
                await new Promise(function (resolve) { setTimeout(resolve, 800); });
            }
        }
        // ===== 第 2 层：OkHttp 失败后，改用 Tools.Net.http 备用栈再试一次 =====
        // 不同网络实现，可绕过 OkHttp 侧的偶发握手失败（实测两栈互补）
        let stackErr = null;
        try {
            console.log("[game_price_kit] OkHttp 失败，尝试备用栈 Tools.Net.http: " + url);
            const resp = await raceGuard(Tools.Net.http({
                url: url,
                method: "GET",
                connect_timeout: 20000,
                read_timeout: 30000,
                responseType: "text",
                validateStatus: false
            }), GJSON_TRY_TIMEOUT_MS + 3000, "Tools.Net.http");
            const status = resp ? (resp.statusCode !== undefined ? resp.statusCode : resp.status) : null;
            const text = resp && resp.content !== undefined ? resp.content : (resp ? resp.body : null);
            if (status === 200 && text !== null && text !== undefined) {
                return JSON.parse(String(text));
            }
            stackErr = new Error("备用栈 HTTP " + status);
        }
        catch (fallbackErr) {
            stackErr = fallbackErr;
        }

        // ===== 第 3 层：DoH 解析真实 IP → IP 直连（忽略证书 + Host 头），绕过 DNS 污染 =====
        // 典型场景：系统 DNS 把 store.steampowered.com 解析到不可达 IP（污染）
        try {
            console.log("[game_price_kit] 前两栈失败，尝试第 3 层 DoH + IP 直连: " + url);
            return await fetchViaDoh(url);
        }
        catch (dohErr) {
            const fbMsg = stackErr && stackErr.message ? stackErr.message : String(stackErr);
            const priorMsg = lastError && lastError.message ? lastError.message : String(lastError);
            const dMsg = dohErr && dohErr.message ? dohErr.message : String(dohErr);
            throw new Error("三栈均失败｜OkHttp: " + priorMsg + "｜Tools.Net.http: " + fbMsg + "｜DoH直连: " + dMsg + "。可能是 DNS 污染、网络中断或域名被阻断，可稍后重试。");
        }
    }

    async function steam_search(params) {
        const keyword = params ? params.keyword : null;
        if (!keyword) {
            throw new Error("keyword 不能为空");
        }
        const cc = (params.cc ? String(params.cc) : "hk").toLowerCase();
        const url = STEAM_STORE + "/api/storesearch/?term=" + encodeURIComponent(keyword) + "&cc=" + cc + "&l=schinese";
        const json = await getJson(url);
        const raw = json.items || [];
        const items = raw.map(function (it) {
            const p = it.price || null;
            return {
                appid: it.id,
                name: it.name,
                price: p ? money(p.final, p.currency) : null,
                original_price: p && p.initial !== p.final ? money(p.initial, p.currency) : null,
                discount_percent: p ? discountPercent(p.initial, p.final) : 0,
                metascore: it.metascore ? it.metascore : null,
                platforms: it.platforms || null
            };
        });
        return {
            region: cc.toUpperCase(),
            total: json.total ? json.total : items.length,
            returned: items.length,
            items: items
        };
    }

    async function steam_price(params) {
        const appid = params && params.appid ? String(params.appid).trim() : "";
        if (!appid) {
            throw new Error("appid 不能为空");
        }
        const cc = (params.cc ? String(params.cc) : "hk").toLowerCase();
        const url = STEAM_STORE + "/api/appdetails?appids=" + encodeURIComponent(appid) + "&cc=" + cc + "&l=schinese&filters=price_overview";
        const json = await getJson(url);
        const entry = json[appid];
        if (!entry) {
            throw new Error("接口未返回 appid=" + appid + " 的数据");
        }
        if (!entry.success) {
            throw new Error("该 appid 在 " + cc.toUpperCase() + " 区无数据（可能不存在或未在该区销售）");
        }
        const p = entry.data ? entry.data.price_overview : null;
        if (!p) {
            return {
                appid: appid,
                region: cc.toUpperCase(),
                is_free: true,
                note: "该商品在所选地区为免费，或没有价格信息"
            };
        }
        return {
            appid: appid,
            region: cc.toUpperCase(),
            currency: p.currency,
            price: money(p.final, p.currency),
            original_price: p.discount_percent > 0 ? money(p.initial, p.currency) : null,
            discount_percent: p.discount_percent ? p.discount_percent : discountPercent(p.initial, p.final),
            is_free: false,
            raw_final: p.final
        };
    }

    async function steam_players(params) {
        const appid = params && params.appid ? String(params.appid).trim() : "";
        if (!appid) {
            throw new Error("appid 不能为空");
        }
        const url = STEAM_API + "/ISteamUserStats/GetNumberOfCurrentPlayers/v1/?appid=" + encodeURIComponent(appid);
        let json = null;
        try {
            json = await getJson(url);
        }
        catch (e) {
            const reason = e && e.message ? e.message : String(e);
            throw new Error("在线人数接口 api.steampowered.com 当前不可达（" + reason + "）。该域名在国内网络下可达性不稳定，属已知问题，可稍后重试；价格查询走 store.steampowered.com，不受影响。");
        }
        const r = json.response || {};
        if (r.result !== 1) {
            throw new Error("查询失败，Steam 返回 result=" + r.result + "（appid 可能无效）");
        }
        return {
            appid: appid,
            current_players: r.player_count
        };
    }

    // ===== 浏览器链路（PS5 / NS）：渲染页面后提取 =====

    /**
     * 沙盒 browser 的报告格式为整份 Playwright 文本，
     * 我们的 JSON 在末尾的 "### Result" 段落里，需要定位并解析。
     */
    function extractResult(raw) {
        const text = String(raw);
        const marker = "### Result";
        const idx = text.lastIndexOf(marker);
        if (idx < 0) {
            throw new Error("浏览器返回中未找到 ### Result 段（页面可能未渲染完成）。返回前 300 字符: " + text.slice(0, 300));
        }
        let body = text.slice(idx + marker.length).trim();
        const nl = body.indexOf("\n### ");
        if (nl >= 0) {
            body = body.slice(0, nl).trim();
        }
        try {
            return JSON.parse(body);
        }
        catch (e) {
            throw new Error("浏览器返回的结果不是合法 JSON。片段: " + body.slice(0, 300));
        }
    }

    async function browserExtract(url, waitSec, code) {
        await raceGuard(Tools.Net.browserNavigate(url), BROWSER_NAV_TIMEOUT_MS, "browserNavigate");
        await raceGuard(Tools.Net.browserWaitFor({ time: waitSec }), waitSec * 1000 + 5000, "browserWaitFor");
        let data = null;
        try { data = extractResult(await raceGuard(Tools.Net.browserEvaluate({ function: code }), BROWSER_EVAL_TIMEOUT_MS, "browserEvaluate")); }
        catch (e0) { data = { count: 0, items: [] }; }
        if (!data || !data.count) {
            // 首轮可能仍在渲染：再等 4 秒重试一次
            await raceGuard(Tools.Net.browserWaitFor({ time: 4 }), 9000, "browserWaitFor");
            const retry = extractResult(await raceGuard(Tools.Net.browserEvaluate({ function: code }), BROWSER_EVAL_TIMEOUT_MS, "browserEvaluate"));
            if (retry && retry.count) {
                data = retry;
            }
        }
        return data;
    }

    const PS5_EXTRACT = "() => { const main = document.querySelector('main') || document.body; if (!main) return JSON.stringify({ count: 0, items: [] }); const out = []; main.querySelectorAll('li').forEach(li => { if (li.querySelector('li')) return; const t = (li.innerText || '').replace(/\\s+/g, ' ').trim(); if (!t || t.length >= 180) return; const hasPrice = t.includes('HK$'); const isFree = (t.includes('免费') || t.includes('免費')) && !t.includes('免费游戏') && !t.includes('免費遊戲'); if (hasPrice || isFree) out.push(t); }); const seen = new Set(); const uniq = out.filter(x => { if (seen.has(x)) return false; seen.add(x); return true; }); const h1 = document.querySelector('h1'); const region = document.querySelector('[role=\\\"region\\\"]'); return JSON.stringify({ heading: h1 ? h1.innerText.replace(/\\s+/g, ' ').trim() : null, summary: region ? region.innerText.replace(/\\s+/g, ' ').trim().slice(0, 80) : null, count: uniq.length, items: uniq.slice(0, 12) }); }";

    async function ps5_search(params) {
        const keyword = params && params.keyword ? String(params.keyword).trim() : "";
        if (!keyword) {
            throw new Error("keyword 不能为空");
        }
        const url = "https://store.playstation.com/zh-hans-hk/search/" + encodeURIComponent(keyword);
        const data = await browserExtract(url, 6, PS5_EXTRACT);
        return {
            region: "HK",
            source: "PlayStation Store (store.playstation.com/zh-hans-hk)",
            heading: data.heading,
            summary: data.summary,
            count: data.count,
            items: data.items
        };
    }

    const NS_EXTRACT = "() => { const main = document.querySelector('main') || document.body; if (!main) return JSON.stringify({ count: 0, items: [] }); const out = []; main.querySelectorAll('li').forEach(el => { if (el.querySelector('li')) return; const txt = el.innerText || ''; if (/HKD/.test(txt) && txt.length < 250) { const img = el.querySelector('img'); let name = (img && img.alt) ? img.alt.trim() : null; if (!name) { const a = el.querySelector('a'); name = (a && a.innerText) ? a.innerText.trim().split('\\n')[0] : txt.replace(/\\s+/g, ' ').trim().slice(0, 60); } const prices = (txt.match(/HKD[\\s]*[\\d,]+/g) || []).map(s => s.replace(/\\s+/g, ' ')); const date = (txt.match(/\\d{2}\\.\\d{1,2}\\.\\d{1,2}/) || [])[0]; out.push({ name: name, prices: prices, date: date }); } }); return JSON.stringify({ count: out.length, items: out.slice(0, 12) }); }";

    const NS_PRODUCT_EXTRACT = "() => { const h1 = document.querySelector('h1'); const path = location.pathname || ''; const onProduct = path.indexOf('catalogsearch') < 0 && h1 && (h1.innerText || '').trim().length > 0; if (!onProduct) { return JSON.stringify({ product: false, count: 0, items: [] }); } const t = (document.body.innerText || '').replace(/\\s+/g, ' '); const prices = []; (t.match(/HKD\\s*[\\d,]+/g) || []).forEach(function (p) { if (prices.indexOf(p) < 0) prices.push(p); }); const dateM = t.match(/發售日\\s*(\\d{4}\\/\\d{1,2}\\/\\d{1,2})/); return JSON.stringify({ product: true, count: 1, items: [{ name: (h1.innerText || '').trim().slice(0, 90), price: prices[0] || null, date: dateM ? dateM[1] : null }] }); }";

    // ===== NS 站 WAF 适配层（2026-10-06 新增）=====
    // store.nintendo.com.hk 已启用 AWS WAF JS Challenge（人机验证）：普通访问先被挑战，
    // 浏览器完成挑战后获得 aws-waf-token cookie，此后同源 fetch 可直接取回 SSR HTML，
    // 不依赖页面渲染是否完成（该站前端在部分环境下会长时间不完成渲染）。
    const WAF_STATE_EXTRACT = "() => { const d = document; const html = d.documentElement ? d.documentElement.outerHTML : ''; const token = d.cookie.indexOf('aws-waf-token') >= 0; const challenge = html.indexOf('gokuProps') >= 0 || !!d.querySelector('#challenge-container'); return JSON.stringify({ token: token, challenge: challenge, len: html.length }); }";

    /** 等待 WAF 挑战完成（令牌出现）。每轮评估一次状态，最多 maxRounds 轮。 */
    async function waitForWafToken(maxRounds) {
        let state = null;
        for (let i = 0; i < maxRounds; i++) {
            try {
                state = extractResult(await raceGuard(Tools.Net.browserEvaluate({ function: WAF_STATE_EXTRACT }), BROWSER_EVAL_TIMEOUT_MS, "waf-state"));
                if (state && state.token) {
                    return state;
                }
            } catch (e) { /* 挑战中页面会在 reload：忽略本轮错误 */ }
            await raceGuard(Tools.Net.browserWaitFor({ time: 1 }), 6000, "waf-wait");
        }
        return state;
    }

    /** NS 站抓取通道：浏览器内 fetch + 解析；必要时先导航触发挑战并等待令牌。 */
    async function nsWafFetch(url, buildCode, label) {
        const run = async function () {
            return extractResult(await raceGuard(Tools.Net.browserEvaluate({ function: buildCode(url) }), BROWSER_EVAL_TIMEOUT_MS, label));
        };
        // 快路径：会话已持有令牌时直接 fetch
        try {
            const fast = await run();
            if (fast && typeof fast.len === "number" && fast.len > 30000 && !fast.waf) {
                return fast;
            }
        } catch (e) { /* 继续走慢路径 */ }
        // 慢路径：导航触发挑战 → 等令牌 → fetch
        try {
            await raceGuard(Tools.Net.browserNavigate(url), BROWSER_NAV_TIMEOUT_MS, "ns-navigate");
        } catch (e) { /* 导航超时也继续：令牌可能已发放 */ }
        const st = await waitForWafToken(8);
        let last = null;
        for (let i = 0; i < 2; i++) {
            try {
                last = await run();
                if (last && typeof last.len === "number" && last.len > 30000 && !last.waf) {
                    return last;
                }
                if (last && last.waf) {
                    await raceGuard(Tools.Net.browserWaitFor({ time: 2 }), 5000, "waf-retry-wait");
                    continue;
                }
                break;
            } catch (e) {
                await raceGuard(Tools.Net.browserWaitFor({ time: 2 }), 5000, "waf-retry-wait");
            }
        }
        if (last) { last.token = st ? !!st.token : null; }
        return last;
    }

    /** 构建「NS 搜索页 fetch + 解析」代码（URL 动态注入）。 */
    function buildNsSearchFetchCode(url) {
        return "async () => { " +
            "const url = " + JSON.stringify(url) + "; " +
            "let html = null; let fetchErr = null; " +
            "try { const r = await fetch(url, { cache: 'no-store' }); html = await r.text(); } " +
            "catch (e) { fetchErr = (e && e.message) ? e.message : String(e); } " +
            "if (html === null) { return JSON.stringify({ count: 0, items: [], fetchError: fetchErr }); } " +
            "if (html.length < 5000 || html.indexOf('gokuProps') >= 0 || html.indexOf('awsWafChallenge') >= 0) { return JSON.stringify({ count: 0, items: [], waf: true, len: html.length }); } " +
            "const doc = new DOMParser().parseFromString(html, 'text/html'); " +
            "Array.prototype.slice.call(doc.querySelectorAll('style,script,noscript,template')).forEach(function (n) { if (n.parentNode) n.parentNode.removeChild(n); }); " +
            "const out = []; " +
            "Array.prototype.slice.call(doc.querySelectorAll('li.product-item')).forEach(function (el) { " +
            "if (el.querySelector('li.product-item')) return; " +
            "const tx = (el.textContent || '').replace(/\\s+/g, ' ').trim(); " +
            "const prices = (tx.match(/HKD[\\s]*[\\d,]+/g) || []).map(function (s) { return s.replace(/\\s+/g, ' '); }); " +
            "if (!prices.length) return; " +
            "const img = el.querySelector('img'); " +
            "let name = (img && img.alt) ? img.alt.trim() : null; " +
            "if (!name) { const mm = tx.match(/發售日期[：:]?\\s*[\\d.]+\\s*([\\s\\S]+?)\\s*HKD/); name = mm ? mm[1] : tx.slice(0, 60); } " +
            "const dm = tx.match(/發售日期[：:]?\\s*(\\d{2}\\.\\d{1,2}\\.\\d{1,2})/); " +
            "out.push({ name: name.slice(0, 90), prices: prices, date: dm ? dm[1] : null }); " +
            "}); " +
            "if (!out.length) { " +
            "const h1 = doc.querySelector('h1'); " +
            "const bodyTx = (doc.body ? doc.body.textContent : '').replace(/\\s+/g, ' '); " +
            "const hm = bodyTx.match(/HKD\\s*[\\d,]+/g) || []; " +
            "if (h1 && hm.length) { const dm2 = bodyTx.match(/發售日\\s*(\\d{4}[\\/\\.]\\d{1,2}[\\/\\.]\\d{1,2})/); out.push({ name: (h1.textContent || '').replace(/\\s+/g, ' ').trim().slice(0, 90), prices: [hm[0]], date: dm2 ? dm2[1] : null }); } " +
            "} " +
            "return JSON.stringify({ count: out.length, items: out.slice(0, 12), len: html.length }); " +
            "}";
    }

    async function ns_search(params) {
        const keyword = params && params.keyword ? String(params.keyword).trim() : "";
        if (!keyword) {
            throw new Error("keyword 不能为空");
        }
        const url = "https://store.nintendo.com.hk/catalogsearch/result/?q=" + encodeURIComponent(keyword);
        let data = null;
        const diag = { waf: false, fetchError: null, pageLen: null };
        // 1) 主通道：过挑战 → fetch HTML → 解析（不依赖渲染）
        try {
            const d = await nsWafFetch(url, buildNsSearchFetchCode, "ns-search-fetch");
            if (d) {
                if (typeof d.len === "number" && d.len > 30000 && !d.waf) {
                    data = d;
                } else {
                    diag.waf = !!d.waf;
                    diag.fetchError = d.fetchError || null;
                    diag.pageLen = d.len || null;
                }
            }
        } catch (e) {
            diag.fetchError = msgOf(e);
        }
        // 2) 兜底：原渲染提取（适配「抓取链路异常但页面可渲染」的边缘情形）
        if (!data) {
            try {
                const rendered = await browserExtract(url, 6, NS_EXTRACT);
                if (rendered && rendered.count) {
                    data = rendered;
                }
            } catch (e2) { /* 忽略：保留上方诊断信息 */ }
        }
        // 3) 判定与报错（明确区分「被防护拦截」与「真 0 结果」）
        if (!data) {
            if (diag.waf) {
                throw new Error("NS 站被 AWS WAF 人机验证拦截：挑战后仍被拒绝。这不是网络问题；稍后重试通常可恢复；如持续出现，属站点防护升级，请改用商店网页版人工查询。");
            }
            if (diag.fetchError) {
                throw new Error("NS 站抓取失败（浏览器内 fetch）：" + diag.fetchError + "。这不是 DNS/网络波动本身；稍后重试即可。");
            }
            throw new Error("NS 站未取得有效页面（可能被防护隔断或页面异常）。稍后重试；持续出现请反馈。");
        }
        return {
            region: "HK",
            source: "Nintendo eShop HK (store.nintendo.com.hk)",
            count: data.count,
            items: data.items || []
        };
    }

    // ===== 折扣列表（deals）链路：Steam 官方接口 / PS5、NS 渲染 =====

    async function steam_deals(params) {
        let count = params && params.count ? parseInt(String(params.count), 10) : 30;
        if (!count || count < 1) {
            count = 30;
        }
        if (count > 100) {
            count = 100;
        }
        const url = STEAM_STORE + "/search/results/?query&start=0&count=" + count + "&specials=1&infinite=1&cc=hk&l=zh";
        const json = await getJson(url);
        const html = String(json.results_html || "");
        const blocks = html.split("search_result_row");
        const items = [];
        for (let i = 1; i < blocks.length && items.length < count; i++) {
            const b = blocks[i];
            const mt = b.match(/<span class="title">([^<]+)<\/span>/);
            if (!mt) {
                continue;
            }
            const md = b.match(/<div class="discount_pct">(-?\d+%)<\/div>/);
            const mp = b.match(/<div class="discount_final_price">([^<]+)<\/div>/);
            const mo = b.match(/<div class="discount_original_price">([^<]+)<\/div>/);
            items.push({
                name: mt[1],
                discount: md ? md[1] : null,
                price: mp ? mp[1].trim() : null,
                original: mo ? mo[1].trim() : null
            });
        }
        return {
            region: "HK",
            source: "Steam 特惠（store.steampowered.com）",
            total_discounted: json.total_count,
            returned: items.length,
            items: items
        };
    }

    const PS5_DEALS_EXTRACT = "() => { const out = []; document.querySelectorAll('main li').forEach(li => { if (li.querySelector('li')) return; const t = (li.innerText || '').replace(/\\s+/g, ' ').trim(); if (!t || t.length >= 300) return; const md = t.match(/-(\\d+)%/); if (!md) return; const a = li.querySelector('a'); let name = ''; if (a) { const raw = (a.getAttribute('aria-label') || a.innerText || '').trim(); name = raw.split('\\n')[0]; } const prices = []; (t.match(/HK\\$[\\d,]+(?:\\.[\\d]+)?/g) || []).forEach(p => { if (prices.indexOf(p) < 0) prices.push(p); }); out.push({ name: name.replace(/\\s*\\([^)]*\\)\\s*$/, '').slice(0, 90), discount: '-' + md[1] + '%', price: prices[0] || null, original: prices[1] || null }); }); return JSON.stringify({ count: out.length, items: out.slice(0, 30) }); }";

    async function ps5_deals(params) {
        let page = params && params.page ? parseInt(String(params.page), 10) : 1;
        if (!page || page < 1) {
            page = 1;
        }
        if (page > 130) {
            page = 130;
        }
        const url = "https://store.playstation.com/zh-hans-hk/category/3f772501-f6f8-49b7-abac-874a88ca4897/" + page;
        const data = await browserExtract(url, 6, PS5_DEALS_EXTRACT);
        return {
            region: "HK",
            source: "PlayStation Store 港区「所有优惠」（共 3100+ 款在打折）",
            page: page,
            total_pages: 130,
            count: data.count,
            items: data.items
        };
    }

    const NS_DEALS_EXTRACT = "() => { const out = []; document.querySelectorAll('li').forEach(el => { if (el.querySelector('li')) return; const t = (el.innerText || '').replace(/\\s+/g, ' ').trim(); if (!t || t.length >= 300) return; const img = el.querySelector('img[alt]'); const prices = t.match(/HKD\\s*[\\d,]+/g) || []; if (img && prices.length >= 1) { const date = ((el.textContent || '').match(/發售日期[：:]\\s*(\\d{2}\\.\\d{1,2}\\.\\d{1,2})/) || [])[1] || null; out.push({ name: img.alt.trim().slice(0, 90), date: date, price: prices[0], original: prices[1] || null }); } }); const h1 = document.querySelector('h1'); return JSON.stringify({ header: h1 ? h1.innerText.replace(/\\s+/g, ' ').trim().slice(0, 60) : null, count: out.length, items: out.slice(0, 30) }); }";

    /** 构建「NS 减价专区 fetch + 解析」代码（URL 动态注入）。 */
    function buildNsDealsFetchCode(url) {
        return "async () => { " +
            "const url = " + JSON.stringify(url) + "; " +
            "let html = null; let fetchErr = null; " +
            "try { const r = await fetch(url, { cache: 'no-store' }); html = await r.text(); } " +
            "catch (e) { fetchErr = (e && e.message) ? e.message : String(e); } " +
            "if (html === null) { return JSON.stringify({ count: 0, items: [], fetchError: fetchErr }); } " +
            "if (html.length < 5000 || html.indexOf('gokuProps') >= 0 || html.indexOf('awsWafChallenge') >= 0) { return JSON.stringify({ count: 0, items: [], waf: true, len: html.length }); } " +
            "const doc = new DOMParser().parseFromString(html, 'text/html'); " +
            "Array.prototype.slice.call(doc.querySelectorAll('style,script,noscript,template')).forEach(function (n) { if (n.parentNode) n.parentNode.removeChild(n); }); " +
            "const out = []; " +
            "Array.prototype.slice.call(doc.querySelectorAll('li.product-item')).forEach(function (el) { " +
            "if (el.querySelector('li.product-item')) return; " +
            "const tx = (el.textContent || '').replace(/\\s+/g, ' ').trim(); " +
            "const prices = (tx.match(/HKD[\\s]*[\\d,]+/g) || []).map(function (s) { return s.replace(/\\s+/g, ' '); }); " +
            "if (!prices.length) return; " +
            "const img = el.querySelector('img'); " +
            "let name = (img && img.alt) ? img.alt.trim().slice(0, 90) : null; " +
            "if (!name) { const mm = tx.match(/發售日期[：:]?\\s*[\\d.]+\\s*([\\s\\S]+?)\\s*(?:特價|HKD)/); name = mm ? mm[1].slice(0, 90) : tx.slice(0, 60); } " +
            "const dm = tx.match(/發售日期[：:]?\\s*(\\d{2}\\.\\d{1,2}\\.\\d{1,2})/); " +
            "out.push({ name: name, date: dm ? dm[1] : null, price: prices[0], original: prices[1] ? prices[1] : null }); " +
            "}); " +
            "const h1 = doc.querySelector('h1'); " +
            "return JSON.stringify({ header: h1 ? (h1.textContent || '').replace(/\\s+/g, ' ').trim().slice(0, 60) : null, count: out.length, items: out.slice(0, 30), len: html.length }); " +
            "}";
    }

    async function ns_deals(params) {
        let page = params && params.page ? parseInt(String(params.page), 10) : 1;
        if (!page || page < 1) {
            page = 1;
        }
        let url = "https://store.nintendo.com.hk/digital-games/current-offers?p=" + page;
        const sort = params && params.sort ? String(params.sort).toLowerCase() : "";
        if (sort === "discount") {
            url += "&product_list_order=discount-rate-desc";
        }
        let data = null;
        const diag = { waf: false, fetchError: null };
        // 1) 主通道：过挑战 → fetch HTML → 解析（不依赖渲染）
        try {
            const d = await nsWafFetch(url, buildNsDealsFetchCode, "ns-deals-fetch");
            if (d) {
                if (typeof d.len === "number" && d.len > 30000 && !d.waf) {
                    data = d;
                } else {
                    diag.waf = !!d.waf;
                    diag.fetchError = d.fetchError || null;
                }
            }
        } catch (e) {
            diag.fetchError = msgOf(e);
        }
        // 2) 兜底：原渲染提取（适配「抓取链路异常但页面可渲染」的边缘情形）
        if (!data) {
            try {
                const rendered = await browserExtract(url, 6, NS_DEALS_EXTRACT);
                if (rendered && rendered.count) {
                    data = rendered;
                }
            } catch (e2) { /* 忽略：保留上方诊断信息 */ }
        }
        // 3) 判定与报错（明确区分「被防护拦截」与「真 0 结果」）
        if (!data) {
            if (diag.waf) {
                throw new Error("NS 减价专区被 AWS WAF 人机验证拦截（挑战未通过）。这不是网络问题；稍后重试通常可恢复。");
            }
            if (diag.fetchError) {
                throw new Error("NS 减价专区抓取失败（浏览器内 fetch）：" + diag.fetchError + "。稍后重试即可。");
            }
            throw new Error("NS 减价专区未取得有效页面（可能被防护隔断或页面异常）。稍后重试；持续出现请反馈。");
        }
        return {
            region: "HK",
            source: "Nintendo eShop HK「減價」專區（约 1000 件）",
            page: page,
            header: data.header || null,
            count: data.count,
            items: data.items || []
        };
    }

    async function wrap(label, func, params) {
        try {
            console.log("[game_price_kit] 开始: " + label);
            const data = await func(params || {});
            console.log("[game_price_kit] 完成: " + label);
            complete({ success: true, message: label + " 完成", data: data });
        }
        catch (error) {
            const msg = error && error.message ? error.message : String(error);
            console.error("[game_price_kit] 失败: " + label + " - " + msg);
            complete({ success: false, message: label + " 失败: " + msg, error_stack: error ? error.stack : null });
        }
    }

    return {
        steam_search: function (params) { return wrap("Steam 搜索", steam_search, params); },
        steam_price: function (params) { return wrap("Steam 价格查询", steam_price, params); },
        steam_players: function (params) { return wrap("Steam 在线人数查询", steam_players, params); },
        steam_deals: function (params) { return wrap("Steam 特惠列表", steam_deals, params); },
        ps5_search: function (params) { return wrap("PS5 港区搜索", ps5_search, params); },
        ps5_deals: function (params) { return wrap("PS5 优惠列表", ps5_deals, params); },
        ns_search: function (params) { return wrap("NS 港区搜索", ns_search, params); },
        ns_deals: function (params) { return wrap("NS 减价列表", ns_deals, params); },
        net_diag: function (params) { return wrap("网络诊断", net_diag, params); }
    };
})();

exports.steam_search = game_price_kit.steam_search;
exports.steam_price = game_price_kit.steam_price;
exports.steam_players = game_price_kit.steam_players;
exports.steam_deals = game_price_kit.steam_deals;
exports.ps5_search = game_price_kit.ps5_search;
exports.ps5_deals = game_price_kit.ps5_deals;
exports.ns_search = game_price_kit.ns_search;
exports.ns_deals = game_price_kit.ns_deals;
exports.net_diag = game_price_kit.net_diag;
