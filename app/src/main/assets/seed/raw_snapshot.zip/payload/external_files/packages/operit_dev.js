/*
METADATA
{
    "name": "operit_dev",
    "description": "Operit 自身编程工具包（手机轻度开发）：脚手架生成 JS 沙盒包、开发目录状态、JS 片段冒烟、准备安装路径。不依赖 OpenCode/WSL。重工程仍走 WSL。",
    "tools": [
        {
            "name": "project_status",
            "description": "查看开发目录与已安装包状态。默认扫描 /sdcard/Download/Operit/dev_package 与外部 packages。",
            "parameters": [
                { "name": "dev_root", "description": "开发根目录，默认 /sdcard/Download/Operit/dev_package", "type": "string", "required": false }
            ]
        },
        {
            "name": "scaffold_package",
            "description": "一键生成标准 JS 沙盒包骨架（METADATA + exports + 示例工具 hello）。写入 dev_package/<package_name>/。",
            "parameters": [
                { "name": "package_name", "description": "包名，仅字母数字下划线，如 my_tools", "type": "string", "required": true },
                { "name": "description", "description": "包描述，可选", "type": "string", "required": false },
                { "name": "tool_name", "description": "首个示例工具名，默认 hello", "type": "string", "required": false },
                { "name": "overwrite", "description": "若已存在是否覆盖，默认 false", "type": "boolean", "required": false }
            ]
        },
        {
            "name": "run_js",
            "description": "在沙盒内执行一段 ES5 兼容 JS 片段做冒烟测试。可 return 值；console.log 会收集到 logs。禁止依赖 Node/DOM。",
            "parameters": [
                { "name": "script", "description": "要执行的 JS 代码字符串", "type": "string", "required": true },
                { "name": "timeout_hint", "description": "仅作说明用的超时提示毫秒，默认 5000（沙盒本身可能另有限制）", "type": "number", "required": false }
            ]
        },
        {
            "name": "prepare_install",
            "description": "把 dev_package/<name>/<name>.js 复制到外部 packages 目录，并返回 operit_editor:debug_install_js_package 推荐参数（沙盒无法可靠跨包直接烧录）。",
            "parameters": [
                { "name": "package_name", "description": "包名", "type": "string", "required": true },
                { "name": "source_path", "description": "可选自定义源 js 路径；默认 dev_package/<name>/<name>.js", "type": "string", "required": false }
            ]
        },
        {
            "name": "read_package_source",
            "description": "读取某个开发包源码摘要（前 N 行 + 工具名列表），便于快速检查。",
            "parameters": [
                { "name": "package_name", "description": "包名", "type": "string", "required": true },
                { "name": "max_lines", "description": "预览行数，默认 40，最大 120", "type": "number", "required": false }
            ]
        }
    ]
}
*/

const operitDev = (function () {
  const DEFAULT_DEV_ROOT = "/sdcard/Download/Operit/dev_package";
  const DEFAULT_PACKAGES_DIR =
    "/sdcard/Android/data/com.ai.assistance.operit/files/packages";
  const DEFAULT_BACKUP_DIR = "/sdcard/Download/Operit/packages";

  function ok(data, message) {
    return {
      success: true,
      message: message || "ok",
      data: data
    };
  }

  function fail(message, data) {
    return {
      success: false,
      message: String(message || "failed"),
      data: data || null
    };
  }

  function isSafePackageName(name) {
    return typeof name === "string" && /^[a-zA-Z_][a-zA-Z0-9_]*$/.test(name);
  }

  function joinPath(a, b) {
    if (!a) return b;
    if (!b) return a;
    if (a.charAt(a.length - 1) === "/") return a + b;
    return a + "/" + b;
  }

  function extractTextPayload(r) {
    if (r == null) return "";
    if (typeof r === "string") return r;
    if (typeof r.content === "string") return r.content;
    if (typeof r.text === "string") return r.text;
    if (typeof r.data === "string") return r.data;
    if (r.data && typeof r.data.content === "string") return r.data.content;
    try {
      return JSON.stringify(r);
    } catch (e) {
      return String(r);
    }
  }

  function extractList(r) {
    if (!r) return [];
    if (Array.isArray(r)) return r;
    if (Array.isArray(r.files)) return r.files;
    if (Array.isArray(r.entries)) return r.entries;
    if (Array.isArray(r.data)) return r.data;
    if (r.data && Array.isArray(r.data.files)) return r.data.files;
    if (r.data && Array.isArray(r.data.entries)) return r.data.entries;
    return [];
  }

  async function fileExists(path) {
    try {
      if (Tools && Tools.Files && typeof Tools.Files.exists === "function") {
        const r = await Tools.Files.exists(path, "android");
        if (typeof r === "boolean") return r;
        if (r && typeof r.exists === "boolean") return r.exists;
        if (r && r.data && typeof r.data.exists === "boolean") return r.data.exists;
      }
    } catch (e) {}
    try {
      if (Tools && Tools.Files && typeof Tools.Files.read === "function") {
        const r = await Tools.Files.read(path);
        const t = extractTextPayload(r);
        return !!(t && t.length >= 0 && !/not found|does not exist|No such file/i.test(t));
      }
    } catch (e2) {
      return false;
    }
    return false;
  }

  async function ensureDir(path) {
    try {
      if (Tools && Tools.Files && typeof Tools.Files.mkdir === "function") {
        await Tools.Files.mkdir(path, true, "android");
        return true;
      }
    } catch (e) {}
    try {
      if (Tools && Tools.Files && typeof Tools.Files.mkdir === "function") {
        await Tools.Files.mkdir(path);
        return true;
      }
    } catch (e2) {}
    return false;
  }

  async function readText(path) {
    try {
      if (Tools && Tools.Files && typeof Tools.Files.read === "function") {
        let r = null;
        try {
          r = await Tools.Files.read({ path: path, environment: "android" });
        } catch (e1) {
          r = await Tools.Files.read(path);
        }
        return extractTextPayload(r);
      }
    } catch (e) {
      throw new Error("read failed: " + path + " :: " + (e && e.message ? e.message : e));
    }
    throw new Error("Tools.Files.read unavailable");
  }

  async function writeText(path, content) {
    const text = String(content == null ? "" : content);
    try {
      if (Tools && Tools.Files && typeof Tools.Files.write === "function") {
        try {
          await Tools.Files.write(path, text, false, "android");
        } catch (e1) {
          await Tools.Files.write(path, text, false);
        }
        return true;
      }
    } catch (e) {
      throw new Error("write failed: " + path + " :: " + (e && e.message ? e.message : e));
    }
    throw new Error("Tools.Files.write unavailable");
  }

  async function listDir(path) {
    try {
      if (Tools && Tools.Files && typeof Tools.Files.list === "function") {
        let r = null;
        try {
          r = await Tools.Files.list(path, "android");
        } catch (e1) {
          r = await Tools.Files.list(path);
        }
        return extractList(r);
      }
    } catch (e) {}
    return [];
  }

  function entryName(item) {
    if (!item) return "";
    if (typeof item === "string") {
      const parts = item.split("/");
      return parts[parts.length - 1] || item;
    }
    return item.name || item.fileName || item.filename || item.path || "";
  }

  function entryIsDir(item) {
    if (!item || typeof item === "string") return false;
    if (typeof item.isDirectory === "boolean") return item.isDirectory;
    if (typeof item.isDir === "boolean") return item.isDir;
    if (item.type === "directory" || item.type === "dir") return true;
    const perms = String(item.permissions || item.mode || "");
    return perms.charAt(0) === "d";
  }

  function buildTemplate(packageName, description, toolName) {
    const desc =
      description ||
      ("Operit sandbox package: " + packageName + " (generated by operit_dev)");
    const tool = toolName || "hello";
    return (
      "/*\n" +
      "METADATA\n" +
      "{\n" +
      '    "name": "' +
      packageName +
      '",\n' +
      '    "description": ' +
      JSON.stringify(desc) +
      ",\n" +
      '    "tools": [\n' +
      "        {\n" +
      '            "name": "' +
      tool +
      '",\n' +
      '            "description": "示例工具：回显输入并返回时间戳。",\n' +
      '            "parameters": [\n' +
      '                { "name": "text", "description": "可选文本", "type": "string", "required": false }\n' +
      "            ]\n" +
      "        }\n" +
      "    ]\n" +
      "}\n" +
      "*/\n\n" +
      "const " +
      packageName +
      "Package = (function () {\n" +
      "    async function " +
      tool +
      "(params) {\n" +
      "        params = params || {};\n" +
      "        const text = params.text == null ? \"hello from " +
      packageName +
      "\" : String(params.text);\n" +
      "        return {\n" +
      "            success: true,\n" +
      "            package: \"" +
      packageName +
      "\",\n" +
      "            text: text,\n" +
      "            ts: Date.now()\n" +
      "        };\n" +
      "    }\n\n" +
      "    return {\n" +
      "        " +
      tool +
      ": " +
      tool +
      "\n" +
      "    };\n" +
      "})();\n\n" +
      "exports." +
      tool +
      " = " +
      packageName +
      "Package." +
      tool +
      ";\n"
    );
  }

  function parseToolsFromSource(src) {
    const tools = [];
    if (!src) return tools;
    const re = /"name"\s*:\s*"([a-zA-Z_][a-zA-Z0-9_]*)"/g;
    let m;
    let count = 0;
    while ((m = re.exec(src)) && count < 50) {
      // skip package name first hits roughly; still useful as preview
      tools.push(m[1]);
      count++;
    }
    // unique
    const seen = {};
    const out = [];
    for (let i = 0; i < tools.length; i++) {
      const t = tools[i];
      if (!seen[t]) {
        seen[t] = 1;
        out.push(t);
      }
    }
    return out;
  }

  async function project_status(params) {
    params = params || {};
    const devRoot = params.dev_root || DEFAULT_DEV_ROOT;
    const packagesDir = DEFAULT_PACKAGES_DIR;

    const devEntries = await listDir(devRoot);
    const pkgEntries = await listDir(packagesDir);

    const installedNames = {};
    for (let i = 0; i < pkgEntries.length; i++) {
      const n = entryName(pkgEntries[i]);
      if (!n) continue;
      installedNames[n] = true;
      if (n.indexOf(".js") > -1) {
        installedNames[n.replace(/\.js$/, "")] = true;
      }
    }

    const projects = [];
    for (let i = 0; i < devEntries.length; i++) {
      const item = devEntries[i];
      const name = entryName(item);
      if (!name || name === "types" || name.charAt(0) === ".") continue;

      // prefer directories; also accept loose files later
      const dirPath = joinPath(devRoot, name);
      const mainJs = joinPath(dirPath, name + ".js");
      let hasMain = false;
      try {
        hasMain = await fileExists(mainJs);
      } catch (e) {
        hasMain = false;
      }

      // if listing gave a file ending with .js
      const isJsFile = name.indexOf(".js") === name.length - 3;
      const packageName = isJsFile ? name.replace(/\.js$/, "") : name;

      projects.push({
        name: packageName,
        dev_path: isJsFile ? joinPath(devRoot, name) : dirPath,
        main_js: isJsFile ? joinPath(devRoot, name) : mainJs,
        has_main_js: isJsFile ? true : hasMain,
        installed_external:
          !!(installedNames[packageName] || installedNames[packageName + ".js"]),
        is_dir_hint: entryIsDir(item) || !isJsFile
      });
    }

    return ok(
      {
        dev_root: devRoot,
        packages_dir: packagesDir,
        project_count: projects.length,
        projects: projects,
        installed_sample: Object.keys(installedNames).slice(0, 30),
        next:
          "开发: scaffold_package → 改源码 → prepare_install → operit_editor:debug_install_js_package → use_package 冒烟"
      },
      "project_status done"
    );
  }

  async function scaffold_package(params) {
    params = params || {};
    const packageName = params.package_name;
    if (!isSafePackageName(packageName)) {
      return fail(
        "package_name 非法：请用字母/数字/下划线，且不能以数字开头",
        { package_name: packageName }
      );
    }
    if (packageName === "operit_dev" || packageName === "types") {
      return fail("保留名，请换一个 package_name");
    }

    const description = params.description || "";
    const toolName = params.tool_name || "hello";
    if (!isSafePackageName(toolName)) {
      return fail("tool_name 非法");
    }
    const overwrite = !!params.overwrite;

    const dir = joinPath(DEFAULT_DEV_ROOT, packageName);
    const mainPath = joinPath(dir, packageName + ".js");
    const readmePath = joinPath(dir, "README.md");

    const existsMain = await fileExists(mainPath);
    if (existsMain && !overwrite) {
      return fail("目标已存在，若确认覆盖请传 overwrite=true", {
        path: mainPath
      });
    }

    await ensureDir(dir);
    const source = buildTemplate(packageName, description, toolName);
    await writeText(mainPath, source);
    await writeText(
      readmePath,
      "# " +
        packageName +
        "\n\n" +
        "由 operit_dev.scaffold_package 生成。\n\n" +
        "## 开发\n" +
        "1. 编辑 `" +
        packageName +
        ".js`\n" +
        "2. operit_dev.prepare_install\n" +
        "3. operit_editor:debug_install_js_package\n" +
        "4. use_package + 冒烟\n"
    );

    return ok(
      {
        package_name: packageName,
        dir: dir,
        main_js: mainPath,
        readme: readmePath,
        first_tool: toolName,
        next_steps: [
          "编辑 " + mainPath,
          "operit_dev:prepare_install({ package_name: '" + packageName + "' })",
          "operit_editor:debug_install_js_package({ source_path: '" +
            mainPath +
            "', enable_after_install: true, activate_after_install: true })",
          "use_package('" + packageName + "') 后调用 " + toolName
        ]
      },
      "scaffold created"
    );
  }

  async function run_js(params) {
    params = params || {};
    const script = params.script;
    if (!script || typeof script !== "string") {
      return fail("script 必填");
    }
    if (script.length > 20000) {
      return fail("script 过长（>20KB），请拆小测");
    }

    const logs = [];
    const fakeConsole = {
      log: function () {
        const args = [];
        for (let i = 0; i < arguments.length; i++) {
          try {
            args.push(
              typeof arguments[i] === "string"
                ? arguments[i]
                : JSON.stringify(arguments[i])
            );
          } catch (e) {
            args.push(String(arguments[i]));
          }
        }
        logs.push(args.join(" "));
      }
    };

    const started = Date.now();
    try {
      // ES5 Function body; user can return a value
      const fn = new Function(
        "console",
        "params",
        script + "\n//# sourceURL=operit_dev_run_js.js"
      );
      const result = fn(fakeConsole, params);
      return ok(
        {
          result: result === undefined ? null : result,
          logs: logs,
          duration_ms: Date.now() - started,
          note: "同步执行；需要异步请改写为同步逻辑或拆到正式包 async 工具"
        },
        "run_js ok"
      );
    } catch (e) {
      return fail("run_js error: " + (e && e.message ? e.message : e), {
        logs: logs,
        duration_ms: Date.now() - started
      });
    }
  }

  async function prepare_install(params) {
    params = params || {};
    const packageName = params.package_name;
    if (!isSafePackageName(packageName)) {
      return fail("package_name 非法");
    }

    const sourcePath =
      params.source_path ||
      joinPath(joinPath(DEFAULT_DEV_ROOT, packageName), packageName + ".js");
    const exists = await fileExists(sourcePath);
    if (!exists) {
      return fail("源文件不存在", { source_path: sourcePath });
    }

    const content = await readText(sourcePath);
    if (!content || content.length < 20) {
      return fail("源文件为空或过短", { source_path: sourcePath });
    }
    if (content.indexOf("METADATA") < 0) {
      return fail("源文件缺少 METADATA 块", { source_path: sourcePath });
    }
    if (content.indexOf("exports.") < 0) {
      return fail("源文件缺少 exports.xxx 导出", { source_path: sourcePath });
    }

    const externalPath = joinPath(DEFAULT_PACKAGES_DIR, packageName + ".js");
    const backupPath = joinPath(DEFAULT_BACKUP_DIR, packageName + ".js");

    await ensureDir(DEFAULT_PACKAGES_DIR);
    await ensureDir(DEFAULT_BACKUP_DIR);
    await writeText(externalPath, content);
    await writeText(backupPath, content);

    return ok(
      {
        package_name: packageName,
        source_path: sourcePath,
        external_path: externalPath,
        backup_path: backupPath,
        bytes: content.length,
        install_with_operit_editor: {
          tool: "operit_editor:debug_install_js_package",
          params: {
            source_path: sourcePath,
            enable_after_install: true,
            activate_after_install: true
          }
        },
        note:
          "沙盒包之间不能可靠调用 operit_editor；请由助手在会话中执行 debug_install_js_package。"
      },
      "prepare_install done"
    );
  }

  async function read_package_source(params) {
    params = params || {};
    const packageName = params.package_name;
    if (!isSafePackageName(packageName)) {
      return fail("package_name 非法");
    }
    let maxLines = parseInt(params.max_lines, 10);
    if (!maxLines || maxLines < 1) maxLines = 40;
    if (maxLines > 120) maxLines = 120;

    const mainPath = joinPath(
      joinPath(DEFAULT_DEV_ROOT, packageName),
      packageName + ".js"
    );
    const exists = await fileExists(mainPath);
    if (!exists) {
      return fail("找不到开发源码", { path: mainPath });
    }
    const content = await readText(mainPath);
    const lines = String(content).split(/\r?\n/);
    const preview = lines.slice(0, maxLines).join("\n");
    return ok(
      {
        path: mainPath,
        total_lines: lines.length,
        preview_lines: Math.min(maxLines, lines.length),
        names_detected: parseToolsFromSource(content).slice(0, 30),
        preview: preview
      },
      "read_package_source done"
    );
  }

  return {
    project_status: project_status,
    scaffold_package: scaffold_package,
    run_js: run_js,
    prepare_install: prepare_install,
    read_package_source: read_package_source
  };
})();

exports.project_status = operitDev.project_status;
exports.scaffold_package = operitDev.scaffold_package;
exports.run_js = operitDev.run_js;
exports.prepare_install = operitDev.prepare_install;
exports.read_package_source = operitDev.read_package_source;
