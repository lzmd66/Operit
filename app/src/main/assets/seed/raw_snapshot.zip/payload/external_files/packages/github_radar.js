/*
METADATA
{
  "name": "github_radar",
  "description": "GitHub 发现与精搜：Trending + HN 新货 + 反刷星 + 主流/小众/精搜/核实。对齐博主供稿台（推送源+过滤），不替代 github 包的 Issues/PR/写仓。",
  "tools": [
    {
      "name": "trending",
      "description": "GitHub Trending 热榜。since=daily|weekly|monthly；可选 language。含反刷星打分。",
      "parameters": [
        { "name": "since", "description": "daily/weekly/monthly，默认 daily", "type": "string", "required": false },
        { "name": "language", "description": "语言过滤，如 python/kotlin/typescript", "type": "string", "required": false },
        { "name": "limit", "description": "条数，默认 10，最大 25", "type": "number", "required": false },
        { "name": "drop_suspicious", "description": "剔除高刷星嫌疑，默认 false", "type": "boolean", "required": false },
        { "name": "token", "description": "可选 GITHUB_TOKEN", "type": "string", "required": false }
      ]
    },
    {
      "name": "hn_feed",
      "description": "Hacker News 新货：Show HN + 含 github.com 的帖，解析成仓库候选（博主同款推送源）。",
      "parameters": [
        { "name": "limit", "description": "条数，默认 10，最大 25", "type": "number", "required": false },
        { "name": "min_points", "description": "最低 HN 分，默认 0（收新货可 0；要稳可 5+）", "type": "number", "required": false },
        { "name": "hours", "description": "只看最近 N 小时，默认 72", "type": "number", "required": false },
        { "name": "github_only", "description": "只保留能解析出 GitHub 仓的，默认 true", "type": "boolean", "required": false },
        { "name": "enrich", "description": "是否拉 GitHub API 补全，默认 true", "type": "boolean", "required": false },
        { "name": "drop_suspicious", "description": "剔除高刷星嫌疑，默认 false", "type": "boolean", "required": false },
        { "name": "token", "description": "可选 token", "type": "string", "required": false }
      ]
    },
    {
      "name": "daily_brief",
      "description": "每日供稿台：Trending ∪ HN → 去重 → 反刷星 → TopN。最接近博主打开手机看到的候选表。",
      "parameters": [
        { "name": "limit", "description": "最终条数，默认 12，最大 25", "type": "number", "required": false },
        { "name": "language", "description": "Trending 语言过滤，可选", "type": "string", "required": false },
        { "name": "since", "description": "Trending 窗口，默认 daily", "type": "string", "required": false },
        { "name": "hn_hours", "description": "HN 最近小时，默认 72", "type": "number", "required": false },
        { "name": "min_points", "description": "HN 最低分，默认 1", "type": "number", "required": false },
        { "name": "drop_suspicious", "description": "默认 true（日报更干净）", "type": "boolean", "required": false },
        { "name": "token", "description": "可选 token", "type": "string", "required": false }
      ]
    },
    {
      "name": "search_precise",
      "description": "解题精搜：自动加 stars/pushed/fork:false 等约束 + 反刷星排序。",
      "parameters": [
        { "name": "query", "description": "核心词或高级语法", "type": "string", "required": true },
        { "name": "language", "description": "language", "type": "string", "required": false },
        { "name": "topic", "description": "topic", "type": "string", "required": false },
        { "name": "min_stars", "description": "默认 10", "type": "number", "required": false },
        { "name": "max_stars", "description": "可选上限", "type": "number", "required": false },
        { "name": "pushed_after", "description": "YYYY-MM-DD，默认约一年内", "type": "string", "required": false },
        { "name": "sort", "description": "stars/forks/updated，默认 stars", "type": "string", "required": false },
        { "name": "limit", "description": "默认 8", "type": "number", "required": false },
        { "name": "drop_suspicious", "description": "默认 false", "type": "boolean", "required": false },
        { "name": "token", "description": "可选 token", "type": "string", "required": false }
      ]
    },
    {
      "name": "niche_find",
      "description": "小众：中星+近 push+低刷星嫌疑。默认 stars 20..2000。",
      "parameters": [
        { "name": "query", "description": "主题词", "type": "string", "required": true },
        { "name": "language", "description": "语言", "type": "string", "required": false },
        { "name": "topic", "description": "topic", "type": "string", "required": false },
        { "name": "min_stars", "description": "默认 20", "type": "number", "required": false },
        { "name": "max_stars", "description": "默认 2000", "type": "number", "required": false },
        { "name": "pushed_after", "description": "默认约 18 个月前", "type": "string", "required": false },
        { "name": "limit", "description": "默认 8", "type": "number", "required": false },
        { "name": "drop_suspicious", "description": "默认 true", "type": "boolean", "required": false },
        { "name": "token", "description": "可选 token", "type": "string", "required": false }
      ]
    },
    {
      "name": "mainstream_find",
      "description": "主流稳仓：较高星+近活+有 license+反空壳。适合要可靠底座。",
      "parameters": [
        { "name": "query", "description": "主题词", "type": "string", "required": true },
        { "name": "language", "description": "语言", "type": "string", "required": false },
        { "name": "topic", "description": "topic", "type": "string", "required": false },
        { "name": "min_stars", "description": "默认 500", "type": "number", "required": false },
        { "name": "pushed_after", "description": "默认约 180 天内", "type": "string", "required": false },
        { "name": "limit", "description": "默认 8", "type": "number", "required": false },
        { "name": "drop_suspicious", "description": "默认 true", "type": "boolean", "required": false },
        { "name": "token", "description": "可选 token", "type": "string", "required": false }
      ]
    },
    {
      "name": "verify_repo",
      "description": "单仓核实：质量分、刷星红旗、verdict。",
      "parameters": [
        { "name": "repo", "description": "owner/name 或 URL", "type": "string", "required": true },
        { "name": "token", "description": "可选 token", "type": "string", "required": false }
      ]
    },
    {
      "name": "radar",
      "description": "统一入口：hot|fresh|daily|niche|mainstream|solve|verify。",
      "parameters": [
        { "name": "mode", "description": "hot|fresh|daily|niche|mainstream|solve|verify", "type": "string", "required": true },
        { "name": "query", "description": "niche/mainstream/solve 必填；verify 填 owner/name", "type": "string", "required": false },
        { "name": "language", "description": "可选", "type": "string", "required": false },
        { "name": "topic", "description": "可选", "type": "string", "required": false },
        { "name": "since", "description": "hot/daily 的 trending 窗口", "type": "string", "required": false },
        { "name": "limit", "description": "条数", "type": "number", "required": false },
        { "name": "drop_suspicious", "description": "是否剔除高嫌疑", "type": "boolean", "required": false },
        { "name": "min_points", "description": "HN 最低分", "type": "number", "required": false },
        { "name": "token", "description": "可选 token", "type": "string", "required": false }
      ]
    }
  ]
}
*/

const githubRadar = (function () {
  const UA = "Operit-GitHubRadar/1.1";
  const API = "https://api.github.com";
  const HN_API = "https://hn.algolia.com/api/v1";

  function ok(data, message) {
    return { success: true, message: message || "ok", data: data };
  }

  function fail(message, data) {
    return { success: false, message: String(message || "failed"), data: data || null };
  }

  function clampInt(v, def, min, max) {
    var n = parseInt(v, 10);
    if (isNaN(n)) n = def;
    if (n < min) n = min;
    if (n > max) n = max;
    return n;
  }

  function toBool(v, def) {
    if (v === undefined || v === null || v === "") return def;
    if (typeof v === "boolean") return v;
    var s = String(v).toLowerCase();
    if (s === "true" || s === "1" || s === "yes") return true;
    if (s === "false" || s === "0" || s === "no") return false;
    return def;
  }

  function trimStr(v) {
    return v == null ? "" : String(v).trim();
  }

  function daysAgoISO(days) {
    var d = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
    var y = d.getUTCFullYear();
    var m = d.getUTCMonth() + 1;
    var day = d.getUTCDate();
    return y + "-" + (m < 10 ? "0" + m : "" + m) + "-" + (day < 10 ? "0" + day : "" + day);
  }

  function parseOwnerRepo(input) {
    var s = trimStr(input);
    if (!s) return null;
    s = s.replace(/^https?:\/\/(www\.)?github\.com\//i, "");
    s = s.replace(/\.git$/i, "");
    s = s.replace(/\/+$/, "");
    var parts = s.split(/[\/?#]/);
    if (parts.length < 2) return null;
    var owner = parts[0];
    var repo = parts[1];
    if (!owner || !repo) return null;
    if (!/^[A-Za-z0-9_.-]+$/.test(owner) || !/^[A-Za-z0-9_.-]+$/.test(repo)) return null;
    return { owner: owner, repo: repo };
  }

  function extractGithubFromText(text) {
    var s = String(text || "");
    var m = s.match(/https?:\/\/(?:www\.)?github\.com\/([A-Za-z0-9_.-]+)\/([A-Za-z0-9_.-]+)/i);
    if (m) return parseOwnerRepo(m[1] + "/" + m[2]);
    m = s.match(/\bgithub\.com\/([A-Za-z0-9_.-]+)\/([A-Za-z0-9_.-]+)/i);
    if (m) return parseOwnerRepo(m[1] + "/" + m[2]);
    return null;
  }

  async function readTextFile(path) {
    if (!path || !Tools || !Tools.Files) return "";
    try {
      if (typeof Tools.Files.read === "function") {
        var r = await Tools.Files.read(path);
        if (typeof r === "string") return r;
        if (r && typeof r.content === "string") return r.content;
        if (r && typeof r.data === "string") return r.data;
      }
    } catch (e) {}
    return "";
  }

  async function httpGet(url, token) {
    if (!Tools || !Tools.Net || typeof Tools.Net.http !== "function") {
      throw new Error("Tools.Net.http unavailable");
    }
    var headers = {
      Accept: "application/json",
      "User-Agent": UA
    };
    if (url.indexOf("api.github.com") >= 0) {
      headers.Accept = "application/vnd.github+json";
      headers["X-GitHub-Api-Version"] = "2022-11-28";
      if (token) headers.Authorization = "Bearer " + token;
    }

    var resp = await Tools.Net.http({
      url: url,
      method: "GET",
      headers: headers,
      follow_redirects: true,
      connect_timeout: 20000,
      read_timeout: 45000,
      validateStatus: false
    });

    if (resp == null) throw new Error("empty HTTP response");

    var saved =
      resp.content_saved_to ||
      (resp.data && resp.data.content_saved_to) ||
      resp.output_saved_to ||
      "";
    var content = "";
    if (saved) content = await readTextFile(saved);
    if (!content) {
      if (typeof resp.content === "string") content = resp.content;
      else if (resp.data && typeof resp.data.content === "string") content = resp.data.content;
      else if (typeof resp === "string") content = resp;
      else content = JSON.stringify(resp);
    }

    var i = content.indexOf("{");
    var j = content.indexOf("[");
    var start = -1;
    if (i >= 0 && j >= 0) start = Math.min(i, j);
    else start = i >= 0 ? i : j;
    if (start > 0) content = content.slice(start);

    var status =
      resp.statusCode ||
      resp.status ||
      (resp.data && (resp.data.statusCode || resp.data.status)) ||
      0;

    return { status: status, text: content, raw: resp };
  }

  async function visitPage(url) {
    if (!Tools || !Tools.Net || typeof Tools.Net.visit !== "function") {
      throw new Error("Tools.Net.visit unavailable");
    }
    var response = await Tools.Net.visit({
      url: url,
      user_agent_preset: "android"
    });
    if (!response) throw new Error("visit returned empty");
    return response;
  }

  function decodeBasicEntities(s) {
    return String(s || "")
      .replace(/&amp;/g, "&")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/"/g, '"')
      .replace(/&#39;/g, "'");
  }

  function isNoiseOwner(owner) {
    owner = String(owner || "").toLowerCase();
    if (!owner) return true;
    var noise = {
      trending: 1, topics: 1, explore: 1, settings: 1, login: 1, signup: 1,
      apps: 1, sponsors: 1, features: 1, marketplace: 1, orgs: 1, collections: 1,
      events: 1, about: 1, pricing: 1, security: 1, site: 1, https: 1, http: 1,
      search: 1, notifications: 1, account: 1, session: 1, pull: 1, issues: 1,
      gist: 1, gists: 1, codespaces: 1, copilot: 1, enterprise: 1, customer: 1,
      team: 1, organizations: 1, users: 1, new: 1
    };
    return !!noise[owner];
  }

  function isNoiseRepoName(name) {
    name = String(name || "").toLowerCase();
    if (!name || name === "following" || name === "sponsors" || name === "explore") return true;
    if (name === "repositories" || name === "projects" || name === "packages") return true;
    if (name === "dashboard" || name === "home" || name === "feed") return true;
    return false;
  }

  function extractTrendingFromHtml(html, limit) {
    var items = [];
    var seen = {};
    var reBlock = /<article[\s\S]*?href="\/([^"\/]+)\/([^"\/\?"]+)"[\s\S]*?<\/article>/gi;
    var text = String(html || "");
    var bm;
    while ((bm = reBlock.exec(text)) && items.length < limit * 3) {
      var o1 = bm[1];
      var n1 = bm[2];
      if (isNoiseOwner(o1) || isNoiseRepoName(n1)) continue;
      if (!/^[A-Za-z0-9_.-]+$/.test(o1) || !/^[A-Za-z0-9_.-]+$/.test(n1)) continue;
      var k1 = o1 + "/" + n1;
      if (seen[k1]) continue;
      seen[k1] = true;
      var desc1 = "";
      var d1 = bm[0].match(/itemprop="description"[^>]*>\s*([^<]{8,200})/i);
      if (!d1) d1 = bm[0].match(/<p[^>]*>\s*([^<]{8,200})/i);
      if (d1) desc1 = decodeBasicEntities(d1[1].replace(/\s+/g, " ").trim());
      items.push({
        full_name: k1,
        url: "https://github.com/" + k1,
        description: desc1,
        source: "trending"
      });
    }
    if (items.length >= Math.min(3, limit)) return items.slice(0, limit);

    var re = /href="\/([^"\/]+)\/([^"\/\?"]+)"/g;
    var m;
    while ((m = re.exec(text)) && items.length < limit * 4) {
      var owner = m[1];
      var name = m[2];
      if (!owner || !name) continue;
      if (isNoiseOwner(owner) || isNoiseRepoName(name)) continue;
      if (!/^[A-Za-z0-9_.-]+$/.test(owner) || !/^[A-Za-z0-9_.-]+$/.test(name)) continue;
      var key = owner + "/" + name;
      if (seen[key]) continue;
      seen[key] = true;
      var sliceStart = Math.max(0, m.index - 80);
      var sliceEnd = Math.min(text.length, m.index + 500);
      var slice = text.slice(sliceStart, sliceEnd);
      var desc = "";
      var dm = slice.match(/<p[^>]*class="[^"]*col-9[^"]*"[^>]*>\s*([^<]{8,180})/i);
      if (!dm) dm = slice.match(/itemprop="description"[^>]*>\s*([^<]{8,180})/i);
      if (dm) desc = decodeBasicEntities(dm[1].replace(/\s+/g, " ").trim());
      items.push({
        full_name: key,
        url: "https://github.com/" + key,
        description: desc,
        source: "trending"
      });
      if (items.length >= limit) break;
    }
    return items;
  }

  function extractTrendingFromVisit(response, limit) {
    var items = [];
    var seen = {};
    var links = response.links || response.Results || [];
    var content = response.content || response.text || "";
    if (typeof content === "string" && content.length > 200) {
      items = extractTrendingFromHtml(content, limit);
      if (items.length >= Math.min(5, limit)) return items;
    }
    if (links && links.length) {
      for (var i = 0; i < links.length && items.length < limit; i++) {
        var L = links[i];
        var href = "";
        var title = "";
        if (typeof L === "string") href = L;
        else {
          href = L.url || L.href || L.link || "";
          title = L.title || L.text || "";
        }
        var pr = parseOwnerRepo(href);
        if (!pr) continue;
        if (isNoiseOwner(pr.owner) || isNoiseRepoName(pr.repo)) continue;
        var key = pr.owner + "/" + pr.repo;
        if (seen[key]) continue;
        seen[key] = true;
        items.push({
          full_name: key,
          url: "https://github.com/" + key,
          description: trimStr(title),
          source: "trending_links"
        });
      }
    }
    return items;
  }

  function collectFlags(repo, extra) {
    var flags = [];
    var stars = repo.stargazers_count || 0;
    var forks = repo.forks_count || 0;
    var watchers = repo.subscribers_count != null ? repo.subscribers_count : repo.watchers_count || 0;
    var desc = trimStr(repo.description);
    var size = repo.size || 0;
    var created = repo.created_at ? Date.parse(repo.created_at) : NaN;
    var pushed = repo.pushed_at ? Date.parse(repo.pushed_at) : NaN;

    if (repo.archived) flags.push("archived");
    if (repo.disabled) flags.push("disabled");
    if (repo.fork) flags.push("fork");
    if (!desc) flags.push("no_description");
    else if (desc.length < 8) flags.push("thin_description");
    if (!(repo.license && (repo.license.spdx_id || repo.license.name))) flags.push("no_license");

    if (stars >= 200 && forks <= 2) flags.push("star_farm_suspected");
    else if (stars >= 80 && forks === 0) flags.push("star_farm_suspected");
    else if (stars >= 500 && forks > 0 && stars / forks >= 80) flags.push("star_skew");

    if (stars >= 1000 && (repo.open_issues_count || 0) === 0 && !repo.has_issues) flags.push("no_issue_tracker");
    if (stars >= 300 && size > 0 && size < 15) flags.push("tiny_repo_high_stars");
    if (stars >= 200 && watchers >= 0 && watchers <= 2 && forks <= 3) flags.push("low_watch_high_star");

    if (!isNaN(created)) {
      var ageDays = (Date.now() - created) / (24 * 3600 * 1000);
      if (ageDays <= 14 && stars >= 200) flags.push("new_burst_stars");
      else if (ageDays <= 45 && stars >= 1000) flags.push("new_burst_stars");
      if (ageDays <= 7 && stars >= 50 && forks <= 1) flags.push("brand_new_hyped");
    }

    if (!isNaN(pushed)) {
      var idle = (Date.now() - pushed) / (24 * 3600 * 1000);
      if (idle > 730) flags.push("stale_2y");
      else if (idle > 365) flags.push("stale_1y");
      else if (idle <= 30) flags.push("active_month");
      else if (idle <= 90) flags.push("active_quarter");
    }

    if (stars < 10) flags.push("very_low_stars");
    if (desc && /(最好|最强|神器|免费下载|破解|加微信|点击领取)/.test(desc)) flags.push("seo_spammy");

    if (extra && extra.hn_points != null && extra.hn_points >= 20) flags.push("hn_traction");
    if (extra && extra.hn_points != null && extra.hn_points >= 5) flags.push("hn_mentioned");

    return flags;
  }

  function qualityScore(repo, extra) {
    var s = 0.5;
    var stars = repo.stargazers_count || 0;
    var forks = repo.forks_count || 0;
    var desc = trimStr(repo.description);
    var flags = collectFlags(repo, extra);
    extra = extra || {};

    if (desc.length >= 20) s += 0.1;
    if (desc.length < 5) s -= 0.18;
    if (repo.license && (repo.license.spdx_id || repo.license.name)) s += 0.08;
    if (!repo.fork) s += 0.04;
    if (repo.fork) s -= 0.15;
    if (repo.archived) s -= 0.4;
    if (repo.disabled) s -= 0.5;

    if (stars >= 50) s += 0.03;
    if (stars >= 500) s += 0.03;
    if (stars >= 5000) s += 0.02;

    if (forks > 0 && stars > 0) {
      var ratio = stars / Math.max(forks, 1);
      if (ratio >= 3 && ratio <= 40) s += 0.06;
      if (ratio > 100) s -= 0.2;
      if (ratio > 200) s -= 0.15;
    }
    if (forks === 0 && stars >= 80) s -= 0.22;

    if ((repo.open_issues_count || 0) > 0) s += 0.03;

    var updated = repo.pushed_at || repo.updated_at || "";
    if (updated) {
      var t = Date.parse(updated);
      if (!isNaN(t)) {
        var ageDays = (Date.now() - t) / (24 * 3600 * 1000);
        if (ageDays <= 90) s += 0.1;
        else if (ageDays <= 365) s += 0.04;
        else if (ageDays > 800) s -= 0.15;
      }
    }

    if (extra.hn_points != null) {
      if (extra.hn_points >= 50) s += 0.16;
      else if (extra.hn_points >= 20) s += 0.12;
      else if (extra.hn_points >= 5) s += 0.07;
      else if (extra.hn_points >= 1) s += 0.03;
    }
    if (extra.hn_comments != null && extra.hn_comments >= 10) s += 0.05;
    else if (extra.hn_comments != null && extra.hn_comments >= 3) s += 0.02;

    for (var i = 0; i < flags.length; i++) {
      var f = flags[i];
      if (f === "star_farm_suspected") s -= 0.28;
      else if (f === "star_skew") s -= 0.16;
      else if (f === "new_burst_stars") s -= 0.12;
      else if (f === "brand_new_hyped") s -= 0.1;
      else if (f === "tiny_repo_high_stars") s -= 0.14;
      else if (f === "low_watch_high_star") s -= 0.08;
      else if (f === "seo_spammy") s -= 0.2;
      else if (f === "no_license") s -= 0.04;
      else if (f === "thin_description") s -= 0.06;
    }

    var name = (repo.full_name || repo.name || "").toLowerCase();
    if (/awesome-/.test(name) && stars < 30) s -= 0.04;
    if (!repo.homepage && desc.length < 10 && stars < 20) s -= 0.08;

    if (s < 0) s = 0;
    if (s > 1) s = 1;
    return {
      score: Math.round(s * 1000) / 1000,
      flags: flags,
      suspicious:
        flags.indexOf("star_farm_suspected") >= 0 ||
        flags.indexOf("seo_spammy") >= 0 ||
        (flags.indexOf("new_burst_stars") >= 0 && flags.indexOf("star_skew") >= 0) ||
        (flags.indexOf("tiny_repo_high_stars") >= 0 && flags.indexOf("star_farm_suspected") >= 0)
    };
  }

  function summarizeRepo(repo, extra) {
    extra = extra || {};
    var q = qualityScore(repo, extra);
    var item = {
      full_name: repo.full_name,
      url: repo.html_url || "https://github.com/" + repo.full_name,
      description: trimStr(repo.description),
      stars: repo.stargazers_count || 0,
      forks: repo.forks_count || 0,
      language: repo.language || "",
      pushed_at: repo.pushed_at || "",
      updated_at: repo.updated_at || "",
      created_at: repo.created_at || "",
      license: (repo.license && (repo.license.spdx_id || repo.license.name)) || "",
      archived: !!repo.archived,
      fork: !!repo.fork,
      open_issues: repo.open_issues_count || 0,
      score: q.score,
      flags: q.flags,
      suspicious: q.suspicious,
      topics: repo.topics || []
    };
    if (extra.hn_points != null) item.hn_points = extra.hn_points;
    if (extra.hn_comments != null) item.hn_comments = extra.hn_comments;
    if (extra.hn_title) item.hn_title = extra.hn_title;
    if (extra.hn_url) item.hn_url = extra.hn_url;
    if (extra.source) item.source = extra.source;
    return item;
  }

  function applyDropFilter(rows, dropSuspicious) {
    if (!dropSuspicious) return rows;
    var out = [];
    for (var i = 0; i < rows.length; i++) {
      if (!rows[i].suspicious) out.push(rows[i]);
    }
    return out;
  }

  function sortByScore(rows) {
    rows.sort(function (a, b) {
      return (b.score || 0) - (a.score || 0);
    });
    return rows;
  }

  function buildSearchQuery(base, opts) {
    var q = trimStr(base);
    opts = opts || {};
    if (opts.language) q += " language:" + trimStr(opts.language);
    if (opts.topic) q += " topic:" + trimStr(opts.topic);
    if (opts.min_stars != null && opts.max_stars != null) {
      q += " stars:" + opts.min_stars + ".." + opts.max_stars;
    } else if (opts.min_stars != null) {
      q += " stars:>=" + opts.min_stars;
    } else if (opts.max_stars != null) {
      q += " stars:<=" + opts.max_stars;
    }
    if (opts.pushed_after) q += " pushed:>" + trimStr(opts.pushed_after);
    if (q.indexOf("fork:") < 0) q += " fork:false";
    return q.replace(/\s+/g, " ").trim();
  }

  async function searchApi(q, sort, order, perPage, token) {
    var url =
      API +
      "/search/repositories?q=" +
      encodeURIComponent(q) +
      "&sort=" +
      encodeURIComponent(sort || "stars") +
      "&order=" +
      encodeURIComponent(order || "desc") +
      "&per_page=" +
      encodeURIComponent(String(perPage || 10));
    var res = await httpGet(url, token);
    var obj;
    try {
      obj = JSON.parse(res.text);
    } catch (e) {
      throw new Error("Search API JSON parse failed: " + String(e) + " status=" + res.status);
    }
    if (obj.message && !obj.items) {
      throw new Error("GitHub API: " + obj.message + (obj.documentation_url ? " " + obj.documentation_url : ""));
    }
    return obj;
  }

  async function getRepoApi(owner, repo, token) {
    var url = API + "/repos/" + encodeURIComponent(owner) + "/" + encodeURIComponent(repo);
    var res = await httpGet(url, token);
    var obj;
    try {
      obj = JSON.parse(res.text);
    } catch (e) {
      throw new Error("Repo API JSON parse failed: " + String(e));
    }
    if (obj.message && !obj.full_name) {
      throw new Error("GitHub API: " + obj.message);
    }
    return obj;
  }

  function formatTable(rows) {
    if (!rows || !rows.length) return "(no results)";
    var lines = [];
    lines.push("| # | repo | stars | forks | score | flags | src | desc |");
    lines.push("|---|---|---:|---:|---:|---|---|---|");
    for (var i = 0; i < rows.length; i++) {
      var r = rows[i];
      var desc = trimStr(r.description || r.hn_title || "").replace(/\|/g, "/").slice(0, 60);
      var fl = (r.flags || []).filter(function (x) {
        return (
          x === "star_farm_suspected" ||
          x === "star_skew" ||
          x === "new_burst_stars" ||
          x === "hn_traction" ||
          x === "hn_mentioned" ||
          x === "active_month" ||
          x === "seo_spammy" ||
          x === "archived"
        );
      });
      lines.push(
        "| " +
          (i + 1) +
          " | " +
          (r.full_name || "") +
          " | " +
          (r.stars != null ? r.stars : "") +
          " | " +
          (r.forks != null ? r.forks : "") +
          " | " +
          (r.score != null ? r.score : "") +
          " | " +
          fl.slice(0, 3).join(",") +
          " | " +
          (r.source || "") +
          " | " +
          desc +
          " |"
      );
    }
    return lines.join("\n");
  }

  function mergeUnique(rows) {
    var seen = {};
    var out = [];
    for (var i = 0; i < rows.length; i++) {
      var r = rows[i];
      var k = (r.full_name || "").toLowerCase();
      if (!k) continue;
      if (seen.hasOwnProperty(k)) {
        var idx = seen[k];
        if (r.hn_points != null && (out[idx].hn_points || 0) < r.hn_points) {
          out[idx].hn_points = r.hn_points;
          out[idx].hn_comments = r.hn_comments;
          out[idx].hn_title = r.hn_title;
          out[idx].hn_url = r.hn_url;
          if (out[idx].source && String(out[idx].source).indexOf("hn") < 0) {
            out[idx].source = out[idx].source + "+hn";
          }
          if (r.hn_points >= 20) out[idx].score = Math.min(1, (out[idx].score || 0) + 0.08);
          if ((out[idx].flags || []).indexOf("hn_mentioned") < 0) {
            out[idx].flags = (out[idx].flags || []).concat(["hn_mentioned"]);
          }
        }
        continue;
      }
      seen[k] = out.length;
      out.push(r);
    }
    return out;
  }

  async function trending(params) {
    params = params || {};
    try {
      var since = trimStr(params.since || "daily").toLowerCase();
      if (since !== "daily" && since !== "weekly" && since !== "monthly") since = "daily";
      var language = trimStr(params.language);
      var limit = clampInt(params.limit, 10, 1, 25);
      var dropSuspicious = toBool(params.drop_suspicious, false);
      var token = trimStr(params.token) || null;

      var url = "https://github.com/trending";
      if (language) url += "/" + encodeURIComponent(language);
      url += "?since=" + encodeURIComponent(since);

      var visit = await visitPage(url);
      var items = extractTrendingFromVisit(visit, Math.max(limit, 15));

      var enriched = [];
      for (var i = 0; i < items.length && enriched.length < limit * 2; i++) {
        var it = items[i];
        var pr = parseOwnerRepo(it.full_name);
        if (!pr || isNoiseOwner(pr.owner) || isNoiseRepoName(pr.repo)) continue;
        try {
          var repo = await getRepoApi(pr.owner, pr.repo, token);
          var sum = summarizeRepo(repo, { source: "trending" });
          if (!sum.description && it.description) sum.description = it.description;
          enriched.push(sum);
        } catch (e) {}
      }

      enriched = applyDropFilter(enriched, dropSuspicious);
      sortByScore(enriched);
      enriched = enriched.slice(0, limit);

      return ok(
        {
          mode: "hot",
          since: since,
          language: language || null,
          url: url,
          drop_suspicious: dropSuspicious,
          count: enriched.length,
          items: enriched,
          table: formatTable(enriched),
          tip: "热门=Trending；要更稳用 daily_brief 或 hn_feed；深挖前 verify_repo。"
        },
        "trending: " + enriched.length + " items"
      );
    } catch (e) {
      return fail("trending failed: " + e);
    }
  }

  async function fetchHnHits(kind, hitsPerPage) {
    var url;
    if (kind === "show") {
      url = HN_API + "/search_by_date?tags=show_hn&hitsPerPage=" + hitsPerPage;
    } else {
      url =
        HN_API +
        "/search_by_date?query=" +
        encodeURIComponent("github.com") +
        "&tags=story&hitsPerPage=" +
        hitsPerPage;
    }
    var res = await httpGet(url, null);
    var obj = JSON.parse(res.text);
    return obj.hits || [];
  }

  async function hn_feed(params) {
    params = params || {};
    try {
      var limit = clampInt(params.limit, 10, 1, 25);
      var minPoints = params.min_points != null ? clampInt(params.min_points, 0, 0, 500) : 0;
      var hours = clampInt(params.hours, 72, 6, 336);
      var githubOnly = toBool(params.github_only, true);
      var enrich = toBool(params.enrich, true);
      var dropSuspicious = toBool(params.drop_suspicious, false);
      var token = trimStr(params.token) || null;
      var cutoff = Date.now() - hours * 3600 * 1000;

      var hits = [];
      try {
        hits = hits.concat(await fetchHnHits("show", 30));
      } catch (e1) {}
      try {
        hits = hits.concat(await fetchHnHits("github", 30));
      } catch (e2) {}

      var candidates = [];
      var seenStory = {};
      for (var i = 0; i < hits.length; i++) {
        var h = hits[i];
        if (!h) continue;
        var id = h.objectID || h.story_id || i;
        if (seenStory[id]) continue;
        seenStory[id] = true;

        var createdMs = (h.created_at_i ? h.created_at_i * 1000 : Date.parse(h.created_at || "")) || 0;
        if (createdMs && createdMs < cutoff) continue;
        var points = h.points != null ? h.points : 0;
        if (points < minPoints) continue;

        var pr =
          extractGithubFromText(h.url || "") ||
          extractGithubFromText(h.story_text || "") ||
          extractGithubFromText(h.title || "");
        if (githubOnly && !pr) continue;
        if (!pr) continue;
        if (isNoiseOwner(pr.owner) || isNoiseRepoName(pr.repo)) continue;

        candidates.push({
          pr: pr,
          hn_points: points,
          hn_comments: h.num_comments || 0,
          hn_title: h.title || "",
          hn_url: h.url || ("https://news.ycombinator.com/item?id=" + id),
          created_at: h.created_at
        });
      }

      var byRepo = {};
      for (var c = 0; c < candidates.length; c++) {
        var key = candidates[c].pr.owner + "/" + candidates[c].pr.repo;
        var low = key.toLowerCase();
        if (!byRepo[low] || byRepo[low].hn_points < candidates[c].hn_points) {
          byRepo[low] = candidates[c];
        }
      }
      var list = [];
      for (var rk in byRepo) {
        if (byRepo.hasOwnProperty(rk)) list.push(byRepo[rk]);
      }
      list.sort(function (a, b) {
        return b.hn_points - a.hn_points || b.hn_comments - a.hn_comments;
      });

      var out = [];
      for (var j = 0; j < list.length && out.length < limit; j++) {
        var cand = list[j];
        var extra = {
          source: "hn",
          hn_points: cand.hn_points,
          hn_comments: cand.hn_comments,
          hn_title: cand.hn_title,
          hn_url: cand.hn_url
        };
        if (enrich) {
          try {
            var repo = await getRepoApi(cand.pr.owner, cand.pr.repo, token);
            out.push(summarizeRepo(repo, extra));
            continue;
          } catch (e3) {
            if (githubOnly) continue;
          }
        }
        out.push({
          full_name: cand.pr.owner + "/" + cand.pr.repo,
          url: "https://github.com/" + cand.pr.owner + "/" + cand.pr.repo,
          description: cand.hn_title,
          stars: null,
          forks: null,
          score: Math.min(1, 0.45 + Math.min(cand.hn_points, 50) / 100),
          flags: cand.hn_points >= 20 ? ["hn_traction"] : ["hn_mentioned"],
          suspicious: false,
          source: "hn",
          hn_points: cand.hn_points,
          hn_comments: cand.hn_comments,
          hn_title: cand.hn_title,
          hn_url: cand.hn_url
        });
      }

      out = applyDropFilter(out, dropSuspicious);
      sortByScore(out);
      out = out.slice(0, limit);

      return ok(
        {
          mode: "fresh",
          hours: hours,
          min_points: minPoints,
          drop_suspicious: dropSuspicious,
          count: out.length,
          items: out,
          table: formatTable(out),
          tip: "HN=有讨论的新货；min_points 调高更稳。和 Trending 合并用 daily_brief。"
        },
        "hn_feed: " + out.length + " items"
      );
    } catch (e) {
      return fail("hn_feed failed: " + e);
    }
  }

  async function daily_brief(params) {
    params = params || {};
    try {
      var limit = clampInt(params.limit, 12, 1, 25);
      var dropSuspicious = toBool(params.drop_suspicious, true);
      var token = trimStr(params.token) || null;

      var hot = await trending({
        since: params.since || "daily",
        language: params.language,
        limit: Math.min(15, limit + 5),
        drop_suspicious: false,
        token: token
      });
      var fresh = await hn_feed({
        limit: Math.min(15, limit + 5),
        hours: params.hn_hours || 72,
        min_points: params.min_points != null ? params.min_points : 1,
        github_only: true,
        enrich: true,
        drop_suspicious: false,
        token: token
      });

      var rows = [];
      if (hot.success && hot.data && hot.data.items) rows = rows.concat(hot.data.items);
      if (fresh.success && fresh.data && fresh.data.items) rows = rows.concat(fresh.data.items);

      rows = mergeUnique(rows);
      rows = applyDropFilter(rows, dropSuspicious);
      sortByScore(rows);
      rows = rows.slice(0, limit);

      var nHot = 0;
      var nHn = 0;
      for (var i = 0; i < rows.length; i++) {
        var src = rows[i].source || "";
        if (src.indexOf("trending") >= 0) nHot++;
        if (src.indexOf("hn") >= 0) nHn++;
      }

      return ok(
        {
          mode: "daily",
          drop_suspicious: dropSuspicious,
          sources: {
            trending_ok: !!(hot && hot.success),
            hn_ok: !!(fresh && fresh.success),
            trending_in_mix: nHot,
            hn_in_mix: nHn
          },
          count: rows.length,
          items: rows,
          table: formatTable(rows),
          tip: "迷你供稿台：热榜+HN，默认已丢高嫌疑。你只需选题；深挖 verify_repo。"
        },
        "daily_brief: " + rows.length + " items"
      );
    } catch (e) {
      return fail("daily_brief failed: " + e);
    }
  }

  async function search_precise(params) {
    params = params || {};
    try {
      var query = trimStr(params.query);
      if (!query) return fail("query required");
      var minStars = params.min_stars != null ? clampInt(params.min_stars, 10, 0, 1000000) : 10;
      var maxStars = params.max_stars != null ? clampInt(params.max_stars, null, 0, 1000000) : null;
      var pushed = trimStr(params.pushed_after) || daysAgoISO(365);
      var sort = trimStr(params.sort || "stars");
      var limit = clampInt(params.limit, 8, 1, 20);
      var token = trimStr(params.token) || null;
      var dropSuspicious = toBool(params.drop_suspicious, false);

      var q = buildSearchQuery(query, {
        language: params.language,
        topic: params.topic,
        min_stars: minStars,
        max_stars: maxStars,
        pushed_after: pushed
      });

      var raw = await searchApi(q, sort, "desc", Math.min(30, limit * 2), token);
      var items = raw.items || [];
      var out = [];
      for (var i = 0; i < items.length; i++) {
        out.push(summarizeRepo(items[i], { source: "search" }));
      }
      out = applyDropFilter(out, dropSuspicious);
      sortByScore(out);
      out = out.slice(0, limit);

      return ok(
        {
          mode: "solve",
          query_built: q,
          total_count: raw.total_count,
          drop_suspicious: dropSuspicious,
          count: out.length,
          items: out,
          table: formatTable(out),
          tip: "精搜+反刷星排序；仍虚则加引号原文或 owner/repo。"
        },
        "search_precise: " + out.length + " items"
      );
    } catch (e) {
      return fail("search_precise failed: " + e);
    }
  }

  async function niche_find(params) {
    params = params || {};
    try {
      var query = trimStr(params.query);
      if (!query) return fail("query required");
      var minStars = params.min_stars != null ? clampInt(params.min_stars, 20, 0, 1000000) : 20;
      var maxStars = params.max_stars != null ? clampInt(params.max_stars, 2000, 1, 1000000) : 2000;
      var pushed = trimStr(params.pushed_after) || daysAgoISO(540);
      var limit = clampInt(params.limit, 8, 1, 20);
      var token = trimStr(params.token) || null;
      var dropSuspicious = toBool(params.drop_suspicious, true);

      var q = buildSearchQuery(query, {
        language: params.language,
        topic: params.topic,
        min_stars: minStars,
        max_stars: maxStars,
        pushed_after: pushed
      });

      var raw = await searchApi(q, "updated", "desc", Math.min(30, limit * 2), token);
      var items = raw.items || [];
      var out = [];
      for (var i = 0; i < items.length; i++) {
        var sum = summarizeRepo(items[i], { source: "niche" });
        if (sum.score >= 0.35) out.push(sum);
      }
      out = applyDropFilter(out, dropSuspicious);
      sortByScore(out);
      out = out.slice(0, limit);

      return ok(
        {
          mode: "niche",
          query_built: q,
          total_count: raw.total_count,
          drop_suspicious: dropSuspicious,
          count: out.length,
          items: out,
          table: formatTable(out),
          tip: "小众=中星+近活+默认丢高嫌疑。"
        },
        "niche_find: " + out.length + " items"
      );
    } catch (e) {
      return fail("niche_find failed: " + e);
    }
  }

  async function mainstream_find(params) {
    params = params || {};
    try {
      var query = trimStr(params.query);
      if (!query) return fail("query required");
      var minStars = params.min_stars != null ? clampInt(params.min_stars, 500, 50, 1000000) : 500;
      var pushed = trimStr(params.pushed_after) || daysAgoISO(180);
      var limit = clampInt(params.limit, 8, 1, 20);
      var token = trimStr(params.token) || null;
      var dropSuspicious = toBool(params.drop_suspicious, true);

      var q = buildSearchQuery(query, {
        language: params.language,
        topic: params.topic,
        min_stars: minStars,
        pushed_after: pushed
      });

      var raw = await searchApi(q, "stars", "desc", Math.min(30, limit * 2), token);
      var items = raw.items || [];
      var out = [];
      for (var i = 0; i < items.length; i++) {
        var sum = summarizeRepo(items[i], { source: "mainstream" });
        if (sum.score >= 0.55 && !sum.archived) out.push(sum);
      }
      out = applyDropFilter(out, dropSuspicious);
      sortByScore(out);
      out = out.slice(0, limit);

      return ok(
        {
          mode: "mainstream",
          query_built: q,
          total_count: raw.total_count,
          drop_suspicious: dropSuspicious,
          count: out.length,
          items: out,
          table: formatTable(out),
          tip: "主流=高星近活+反空壳；要新货用 fresh/daily。"
        },
        "mainstream_find: " + out.length + " items"
      );
    } catch (e) {
      return fail("mainstream_find failed: " + e);
    }
  }

  async function verify_repo(params) {
    params = params || {};
    try {
      var pr = parseOwnerRepo(params.repo || params.query);
      if (!pr) return fail("repo must be owner/name or github URL");
      var token = trimStr(params.token) || null;
      var repo = await getRepoApi(pr.owner, pr.repo, token);
      var sum = summarizeRepo(repo, { source: "verify" });

      var verdict = "maybe";
      if (sum.archived || sum.score < 0.35 || sum.suspicious) verdict = "skip";
      else if (sum.score >= 0.65 && (sum.flags || []).indexOf("stale_2y") < 0) verdict = "worth_deep_dive";

      return ok(
        {
          mode: "verify",
          verdict: verdict,
          flags: sum.flags,
          suspicious: sum.suspicious,
          item: sum,
          raw_hints: {
            default_branch: repo.default_branch,
            size_kb: repo.size,
            has_issues: repo.has_issues,
            subscribers: repo.subscribers_count,
            network: repo.network_count,
            created_at: repo.created_at
          },
          tip:
            verdict === "worth_deep_dive"
              ? "可继续读 README / 最近 Issues。"
              : verdict === "skip"
              ? sum.suspicious
                ? "刷星/空壳嫌疑偏高，优先换候选。"
                : "优先换候选，除非有硬需求。"
              : "中等质量，先看 README 再决定。"
        },
        "verify: " + sum.full_name + " => " + verdict
      );
    } catch (e) {
      return fail("verify_repo failed: " + e);
    }
  }

  async function radar(params) {
    params = params || {};
    var mode = trimStr(params.mode || "").toLowerCase();
    if (mode === "hot" || mode === "trending") return trending(params);
    if (mode === "fresh" || mode === "hn") return hn_feed(params);
    if (mode === "daily" || mode === "brief" || mode === "digest") return daily_brief(params);
    if (mode === "niche") return niche_find(params);
    if (mode === "mainstream" || mode === "main") return mainstream_find(params);
    if (mode === "solve" || mode === "precise" || mode === "search") return search_precise(params);
    if (mode === "verify") {
      if (!params.repo && params.query) params.repo = params.query;
      return verify_repo(params);
    }
    return fail("mode must be hot|fresh|daily|niche|mainstream|solve|verify");
  }

  return {
    trending: trending,
    hn_feed: hn_feed,
    daily_brief: daily_brief,
    search_precise: search_precise,
    niche_find: niche_find,
    mainstream_find: mainstream_find,
    verify_repo: verify_repo,
    radar: radar
  };
})();

exports.trending = githubRadar.trending;
exports.hn_feed = githubRadar.hn_feed;
exports.daily_brief = githubRadar.daily_brief;
exports.search_precise = githubRadar.search_precise;
exports.niche_find = githubRadar.niche_find;
exports.mainstream_find = githubRadar.mainstream_find;
exports.verify_repo = githubRadar.verify_repo;
exports.radar = githubRadar.radar;