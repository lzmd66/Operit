/*
METADATA
{
    "name": "operit_ctl",
    "description": "Operit 控制台：把实测可用的 Tools.* 桥封装成一组工具（能力自检 / 设备信息 / 系统设置 / 应用列表 / 对话读取 / 浏览器 cookie / Java 静态桥）。纯应用权限即可运行，不依赖无障碍或 Shizuku。注意：shell、terminal、UI 自动化不在本包内——它们需要无障碍或 Shizuku，未开启时必然失败。",
    "category": "System",
    "tools": [
        {
            "name": "probe",
            "description": "能力自检（无副作用，建议先跑这个）：检查 Tools.* 各桥与 Java 桥当前是否在册，并给出被权限挡住的能力清单。",
            "parameters": []
        },
        {
            "name": "device_info",
            "description": "读取设备信息：型号、厂商、系统版本、SDK、屏幕、内存、存储、电量、CPU、网络类型。",
            "parameters": []
        },
        {
            "name": "get_setting",
            "description": "读取系统设置项（如 android_id、screen_brightness）。namespace 默认 system，也可试 secure / global。",
            "parameters": [
                { "name": "key", "description": "设置项名，例如 android_id", "type": "string", "required": true },
                { "name": "namespace", "description": "system / secure / global，默认 system", "type": "string", "required": false }
            ]
        },
        {
            "name": "list_apps",
            "description": "列出已安装应用（应用名 + 包名）。",
            "parameters": [
                { "name": "include_system", "description": "是否包含系统应用，默认 false", "type": "boolean", "required": false }
            ]
        },
        {
            "name": "start_app",
            "description": "按包名启动应用。",
            "parameters": [
                { "name": "package_name", "description": "包名，例如 com.tencent.mm", "type": "string", "required": true }
            ]
        },
        {
            "name": "list_chats",
            "description": "列出 Operit 对话：总数、当前对话、简要列表（ID/标题/消息数/更新时间）。",
            "parameters": [
                { "name": "limit", "description": "返回条数，默认 20", "type": "number", "required": false }
            ]
        },
        {
            "name": "chat_messages",
            "description": "读取指定对话的消息（按 ID）。返回角色与内容摘要。",
            "parameters": [
                { "name": "chat_id", "description": "对话 ID（可由 list_chats 获取）", "type": "string", "required": true },
                { "name": "limit", "description": "返回条数，默认 20", "type": "number", "required": false }
            ]
        },
        {
            "name": "cookies",
            "description": "读取内置浏览器会话的 cookie（含域名/路径/过期）。属敏感数据，仅按需读取。",
            "parameters": []
        },
        {
            "name": "java_static",
            "description": "通过 Java 桥读取宿主静态字段或调用静态方法。受桥能力限制：不能枚举方法、拿不到非单例实例。",
            "parameters": [
                { "name": "class_name", "description": "完整类名，例如 com.ai.assistance.operit.data.model.ApiProviderType", "type": "string", "required": true },
                { "name": "field", "description": "要读取的静态字段名（与 method 二选一）", "type": "string", "required": false },
                { "name": "method", "description": "要调用的静态方法名（与 field 二选一）", "type": "string", "required": false },
                { "name": "args", "description": "方法参数，JSON 数组字符串，最多 2 个，例如 [\"a\",1]", "type": "string", "required": false }
            ]
        }
    ]
}
*/

const operit_ctlPackage = (function () {

    function typeOfMember(obj, name) {
        try {
            if (!obj) return 'no-object';
            return typeof obj[name];
        } catch (e) {
            return 'err';
        }
    }

    // ---------- 能力自检（纯静态检查，无副作用、不发起调用） ----------
    async function probe(params) {
        const t = typeOfMember;
        const caps = {
            files: { read: t(Tools.Files, 'read'), write: t(Tools.Files, 'write'), binary: t(Tools.Files, 'readBinary') },
            net: { httpGet: t(Tools.Net, 'httpGet'), httpPost: t(Tools.Net, 'httpPost'), cookies: t(Tools.Net, 'cookies'), browserEval: t(Tools.Net, 'browserEvaluate') },
            system: { getSetting: t(Tools.System, 'getSetting'), deviceInfo: t(Tools.System, 'getDeviceInfo'), listApps: t(Tools.System, 'listApps'), shell: t(Tools.System, 'shell'), broadcast: t(Tools.System, 'sendBroadcast') },
            chat: { listChats: t(Tools.Chat, 'listChats'), getMessages: t(Tools.Chat, 'getMessages'), sendMessage: t(Tools.Chat, 'sendMessage') },
            memory: { query: t(Tools.Memory, 'query'), create: t(Tools.Memory, 'create') },
            workflow: { trigger: t(Tools.Workflow, 'trigger') },
            softwareSettings: { updateModelConfig: t(Tools.SoftwareSettings, 'updateModelConfig'), listModelConfigs: t(Tools.SoftwareSettings, 'listModelConfigs') },
            ui: { tap: t(Tools.UI, 'tap'), getPageInfo: t(Tools.UI, 'getPageInfo') },
            javaBridge: (typeof Java === 'undefined') ? 'missing' : 'present'
        };
        return {
            success: true,
            capabilities: caps,
            verdict: {
                usable_without_permission: 'Files / Net / System(设置·设备·应用列表) / Chat / Memory / Workflow / SoftwareSettings / Java桥',
                blocked_by_permission: 'System.shell·terminal（需 Shizuku 或无障碍）、UI.*（需无障碍）',
                note: '本包全部工具只依赖上面这批桥，因此在未开启无障碍/Shizuku 时也能正常使用。'
            }
        };
    }

    // ---------- 设备信息 ----------
    async function device_info(params) {
        const di = await Tools.System.getDeviceInfo();
        return {
            success: true,
            model: di.model,
            manufacturer: di.manufacturer,
            android: di.androidVersion,
            sdk: di.sdkVersion,
            screen: di.screenResolution,
            density: di.screenDensity,
            memory_total: di.totalMemory,
            memory_free: di.availableMemory,
            storage_total: di.totalStorage,
            storage_free: di.availableStorage,
            battery: di.batteryLevel,
            charging: di.batteryCharging,
            cpu: di.cpuInfo,
            network: di.networkType
        };
    }

    // ---------- 系统设置读取 ----------
    async function get_setting(params) {
        params = params || {};
        if (!params.key) throw new Error('缺少 key 参数');
        let r;
        if (params.namespace) {
            try {
                r = await Tools.System.getSetting(params.key, params.namespace);
            } catch (e) {
                r = await Tools.System.getSetting(params.key);
            }
        } else {
            r = await Tools.System.getSetting(params.key);
        }
        return {
            success: true,
            namespace: r && r.namespace,
            key: (r && r.setting) || params.key,
            value: r && r.value
        };
    }

    // ---------- 应用列表 ----------
    async function list_apps(params) {
        params = params || {};
        const withSys = !!params.include_system;
        let r;
        try {
            r = await Tools.System.listApps(withSys);
        } catch (e) {
            r = await Tools.System.listApps();
        }
        const raw = (r && r.packages) ? r.packages : [];
        const apps = [];
        for (let i = 0; i < raw.length; i++) {
            const s = String(raw[i]);
            const m = s.match(/^(.*) \(([^)]+)\)\s*$/);
            if (m) {
                apps.push({ name: m[1], package: m[2] });
            } else {
                apps.push({ name: s, package: null });
            }
        }
        apps.sort(function (a, b) {
            return String(a.name).localeCompare(String(b.name));
        });
        return {
            success: true,
            include_system: withSys,
            count: apps.length,
            apps: apps
        };
    }

    // ---------- 启动应用 ----------
    async function start_app(params) {
        params = params || {};
        if (!params.package_name) throw new Error('缺少 package_name 参数');
        const r = await Tools.System.startApp(params.package_name);
        return {
            success: true,
            package: params.package_name,
            result: String(JSON.stringify(r)).substring(0, 300)
        };
    }

    // ---------- 对话列表 ----------
    async function list_chats(params) {
        params = params || {};
        const limit = params.limit || 20;
        const r = await Tools.Chat.listChats();
        const all = (r && r.chats) ? r.chats : [];
        const list = [];
        for (let i = 0; i < all.length && i < limit; i++) {
            const c = all[i];
            list.push({
                id: c.id,
                title: c.title,
                messages: c.messageCount,
                updated: c.updatedAt,
                is_current: !!c.isCurrent
            });
        }
        return {
            success: true,
            total: r && r.totalCount,
            current_chat_id: r && r.currentChatId,
            shown: list.length,
            chats: list
        };
    }

    // ---------- 对话消息 ----------
    async function chat_messages(params) {
        params = params || {};
        if (!params.chat_id) throw new Error('缺少 chat_id 参数');
        const limit = params.limit || 20;
        let r;
        try {
            r = await Tools.Chat.getMessages(params.chat_id, limit);
        } catch (e) {
            r = await Tools.Chat.getMessages(params.chat_id);
        }
        let arr = [];
        if (r && Array.isArray(r.messages)) {
            arr = r.messages;
        } else if (Array.isArray(r)) {
            arr = r;
        } else if (r && Array.isArray(r.data)) {
            arr = r.data;
        }
        if (arr.length === 0) {
            return {
                success: true,
                chat_id: params.chat_id,
                count: 0,
                note: '未解析出消息数组，返回原始结构供排查',
                raw_shape: String(JSON.stringify(r)).substring(0, 800)
            };
        }
        const out = [];
        const start = Math.max(0, arr.length - limit);
        for (let i = start; i < arr.length; i++) {
            const m = arr[i];
            out.push({
                role: m.role || m.sender || m.type || null,
                content: String(m.content || m.text || m.message || '').substring(0, 800)
            });
        }
        return {
            success: true,
            chat_id: params.chat_id,
            total_in_result: arr.length,
            count: out.length,
            messages: out
        };
    }

    // ---------- 浏览器 cookie ----------
    async function cookies(params) {
        const r = await Tools.Net.cookies.get();
        return {
            success: true,
            cookies: String(r).substring(0, 4000)
        };
    }

    // ---------- Java 静态桥 ----------
    async function java_static(params) {
        params = params || {};
        if (!params.class_name) throw new Error('缺少 class_name 参数');
        if (typeof Java === 'undefined') throw new Error('当前运行时没有 Java 桥');
        const J = Java.use(params.class_name);

        if (params.field) {
            let v;
            try {
                v = J.getStatic(params.field);
            } catch (e) {
                throw new Error('读取静态字段失败: ' + String(e).substring(0, 200));
            }
            return {
                success: true,
                class_name: params.class_name,
                field: params.field,
                value: String(v)
            };
        }

        if (params.method) {
            let args = [];
            if (params.args) {
                try {
                    args = JSON.parse(params.args);
                } catch (e2) {
                    throw new Error('args 不是合法 JSON 数组');
                }
                if (!Array.isArray(args)) throw new Error('args 必须是 JSON 数组');
            }
            let r;
            try {
                if (args.length === 0) {
                    r = J.callStatic(params.method);
                } else if (args.length === 1) {
                    r = J.callStatic(params.method, args[0]);
                } else if (args.length === 2) {
                    r = J.callStatic(params.method, args[0], args[1]);
                } else {
                    throw new Error('暂支持最多 2 个参数');
                }
            } catch (e3) {
                throw new Error('调用静态方法失败: ' + String(e3).substring(0, 200));
            }
            return {
                success: true,
                class_name: params.class_name,
                method: params.method,
                args: args,
                value: String(r)
            };
        }

        throw new Error('需要提供 field 或 method 之一');
    }

    return {
        probe: probe,
        device_info: device_info,
        get_setting: get_setting,
        list_apps: list_apps,
        start_app: start_app,
        list_chats: list_chats,
        chat_messages: chat_messages,
        cookies: cookies,
        java_static: java_static
    };
})();

exports.probe = operit_ctlPackage.probe;
exports.device_info = operit_ctlPackage.device_info;
exports.get_setting = operit_ctlPackage.get_setting;
exports.list_apps = operit_ctlPackage.list_apps;
exports.start_app = operit_ctlPackage.start_app;
exports.list_chats = operit_ctlPackage.list_chats;
exports.chat_messages = operit_ctlPackage.chat_messages;
exports.cookies = operit_ctlPackage.cookies;
exports.java_static = operit_ctlPackage.java_static;
