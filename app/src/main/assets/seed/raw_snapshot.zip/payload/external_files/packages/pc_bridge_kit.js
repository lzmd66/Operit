/*
METADATA
{
    "name": "pc_bridge_kit",
    "description": "自主 PC 桥工具包：通过局域网 HTTP 直连你电脑上的 pc_bridge 服务（自建，非官方），执行命令、读写文件、列目录、精确替换、下载/上传文件、读写你的长期记忆。安全设计：服务端 IP 白名单 + Bearer token 双重校验，任何响应都不回传 token。注意：仅当电脑上的 pc_bridge 正在运行且手机 IP 在白名单内时可用。",
    "tools": [
        {
            "name": "pc_info",
            "description": "查看 PC 桥状态：主机名、用户、系统、Node 版本、监听地址、可用局域网 IP、当前生效的 IP 白名单、记忆目录。连不上或想确认通道时先调它。",
            "parameters": []
        },
        {
            "name": "pc_exec",
            "description": "在电脑上执行命令，返回 exit_code / stdout / stderr / timed_out / output_truncated。注意：非零退出码不算失败（照常返回真实结果）。",
            "parameters": [
                { "name": "command", "description": "要执行的命令", "type": "string", "required": true },
                { "name": "shell", "description": "cmd（默认）或 powershell", "type": "string", "required": false },
                { "name": "cwd", "description": "工作目录，如 C:/Users/ASUS", "type": "string", "required": false },
                { "name": "timeout_ms", "description": "超时毫秒，默认 30000（上限由服务端 maxTimeoutMs 决定）", "type": "number", "required": false }
            ]
        },
        {
            "name": "pc_read",
            "description": "读取电脑上的文件，支持编码选择与分段读取。返回 content / size / read_bytes / truncated / detected_encoding / binary。编码 auto 时会告诉你它实际上按 UTF-8 还是 GBK 读的；二进制文件会返回 binary=true 且 content 是 base64。默认只读前 4MB。",
            "parameters": [
                { "name": "path", "description": "文件路径，如 C:/Users/ASUS/Desktop/a.txt", "type": "string", "required": true },
                { "name": "encoding", "description": "auto（默认）/ utf-8 / gbk / big5 / shift_jis / base64", "type": "string", "required": false },
                { "name": "offset", "description": "起始字节偏移，默认 0", "type": "number", "required": false },
                { "name": "length", "description": "读取字节数，默认 0 表示读到末尾（受 4MB 上限）", "type": "number", "required": false }
            ]
        },
        {
            "name": "pc_write",
            "description": "写入/追加文件（自动创建上级目录）。文本可指定 gbk 等编码写出（服务端会用系统编码器落盘）；二进制用 encoding=base64。",
            "parameters": [
                { "name": "path", "description": "目标文件路径", "type": "string", "required": true },
                { "name": "content", "description": "要写入的文本内容（或 base64 串）", "type": "string", "required": true },
                { "name": "encoding", "description": "utf-8（默认）/ gbk / big5 / shift_jis / base64", "type": "string", "required": false },
                { "name": "append", "description": "是否追加而不是覆盖，默认 false", "type": "boolean", "required": false }
            ]
        },
        {
            "name": "pc_list",
            "description": "列出目录内容（文件名/路径/类型/大小/修改时间），depth 可递归 0-5。",
            "parameters": [
                { "name": "path", "description": "目录路径，如 C:/Users/ASUS/Desktop", "type": "string", "required": true },
                { "name": "depth", "description": "递归深度 0-5，默认 0（只列当层）", "type": "number", "required": false }
            ]
        },
        {
            "name": "pc_edit",
            "description": "精确文本替换：把文件里的 old_text 换成 new_text，并校验出现次数与 expected 一致（默认 1），不一致则拒绝写入。自动识别 UTF-8/GBK 并保持原编码写回；二进制文件会被拒绝。",
            "parameters": [
                { "name": "path", "description": "目标文件路径", "type": "string", "required": true },
                { "name": "old_text", "description": "要被替换的原文本（不能为空）", "type": "string", "required": true },
                { "name": "new_text", "description": "替换成的新文本", "type": "string", "required": true },
                { "name": "expected", "description": "期望匹配次数，默认 1；不符即拒绝写入", "type": "number", "required": false },
                { "name": "encoding", "description": "auto（默认，自动识别）/ utf-8 / gbk", "type": "string", "required": false }
            ]
        },
        {
            "name": "pc_file_url",
            "description": "拿一个可以直接下载的 PC 文件直链（含 token，支持 Range 断点续传）。适合把大文件交给手机自带下载器/浏览器去拉，不走 base64。",
            "parameters": [
                { "name": "path", "description": "PC 上的文件路径", "type": "string", "required": true },
                { "name": "inline", "description": "true 表示浏览器内联预览（图片/PDF），默认 false 当附件下载", "type": "boolean", "required": false }
            ]
        },
        {
            "name": "pc_download",
            "description": "分段把 PC 文件读成 base64 返回（默认 4MB/次），你自己写到手机文件里。要传大文件优先用 pc_file_url 交给下载器。",
            "parameters": [
                { "name": "path", "description": "PC 上的文件路径", "type": "string", "required": true },
                { "name": "offset", "description": "起始字节偏移，默认 0", "type": "number", "required": false },
                { "name": "length", "description": "读取字节数，默认 4MB", "type": "number", "required": false }
            ]
        },
        {
            "name": "pc_upload",
            "description": "把 base64 内容写入 PC 上的文件（自动建目录）。小于几 MB 用这个；更大请用 pc_exec 在 PC 侧配合 /upload 或分段追加。",
            "parameters": [
                { "name": "path", "description": "PC 上的目标文件路径", "type": "string", "required": true },
                { "name": "content_base64", "description": "文件内容的 base64", "type": "string", "required": true },
                { "name": "append", "description": "是否追加，默认 false", "type": "boolean", "required": false }
            ]
        },
        {
            "name": "memory_index",
            "description": "读电脑上的长期记忆索引（MEMORY.md）：每条一行、带主题文件与一行钩子。想了解这台电脑/这个人过去干过什么，先调它。",
            "parameters": []
        },
        {
            "name": "memory_list",
            "description": "列出长期记忆目录下所有 .md 主题文件（名字/大小/修改时间）。",
            "parameters": []
        },
        {
            "name": "memory_read",
            "description": "读某个记忆主题文件的全文，例如 reference-operit-harmony-proot.md。",
            "parameters": [
                { "name": "name", "description": "记忆文件名（只要文件名，如 user-profile.md）", "type": "string", "required": true }
            ]
        },
        {
            "name": "memory_search",
            "description": "在长期记忆里全文搜索，返回 file/line/text。默认不区分大小写、按字面匹配；re=true 时按正则。",
            "parameters": [
                { "name": "q", "description": "搜索词或正则", "type": "string", "required": true },
                { "name": "limit", "description": "最多返回多少条命中，默认 60，上限 500", "type": "number", "required": false },
                { "name": "re", "description": "true 表示按正则匹配，默认 false", "type": "boolean", "required": false },
                { "name": "case", "description": "true 表示区分大小写，默认 false", "type": "boolean", "required": false }
            ]
        },
        {
            "name": "memory_write",
            "description": "把一条结论写进长期记忆（只允许 .md、只允许写在该目录内）。一个文件一个事实，文件名用 类型-主题 形式，例如 reference-xxx.md。",
            "parameters": [
                { "name": "name", "description": "文件名（必须以 .md 结尾，不能带路径）", "type": "string", "required": true },
                { "name": "content", "description": "要写入的内容（markdown）", "type": "string", "required": true },
                { "name": "append", "description": "是否追加到已有文件末尾，默认 false（覆盖）", "type": "boolean", "required": false }
            ]
        },
        {
            "name": "pc_session_start",
            "description": "在电脑上启动一个会话：传 command 则执行该命令并持续收集输出（适合耗时长的任务）；不传 command 则开一个交互式 shell，之后可用 pc_session_write 往里敲命令。返回 session_id。",
            "parameters": [
                { "name": "command", "description": "要执行的命令；留空则开交互式 shell", "type": "string", "required": false },
                { "name": "shell", "description": "cmd（默认）或 powershell", "type": "string", "required": false },
                { "name": "cwd", "description": "工作目录", "type": "string", "required": false }
            ]
        },
        {
            "name": "pc_session_read",
            "description": "读取会话输出（默认只返回上次读之后的新增部分，不重复）。返回 output / running / exit_code / next_since / pending_bytes。要重新从头读就显式传 since=0。",
            "parameters": [
                { "name": "session_id", "description": "会话 ID", "type": "string", "required": true },
                { "name": "since", "description": "从第几字节开始读；留空=从上次读到的位置继续", "type": "number", "required": false }
            ]
        },
        {
            "name": "pc_session_write",
            "description": "往会话的标准输入写数据（配合交互式 shell）。control 可附加控制键：enter / tab / esc / ctrl+c / ctrl+d / eof。",
            "parameters": [
                { "name": "session_id", "description": "会话 ID", "type": "string", "required": true },
                { "name": "data", "description": "要写入的文本", "type": "string", "required": false },
                { "name": "control", "description": "控制键：enter/tab/esc/ctrl+c/ctrl+d/eof", "type": "string", "required": false }
            ]
        },
        {
            "name": "pc_session_terminate",
            "description": "终止会话（杀掉进程）。remove=true 时同时从会话列表移除。",
            "parameters": [
                { "name": "session_id", "description": "会话 ID", "type": "string", "required": true },
                { "name": "remove", "description": "是否从列表移除，默认 false", "type": "boolean", "required": false }
            ]
        },
        {
            "name": "pc_session_list",
            "description": "列出所有会话及其状态（运行中/退出码/缓冲字节/已读位置/空闲时长/启动时间）。",
            "parameters": []
        }
    ]
}
*/

// ===================== 配置 =====================
// 电脑上 pc_bridge 的地址与口令。改了 PC 的 bridge.config.json 后，这里要同步。
const PC_BRIDGE_BASE = "http://192.168.50.80:58322";
const PC_BRIDGE_TOKEN = "pcb_5uQ8nK2vXm7Rt3Zc9Fb4Hd6";
const CONNECT_TIMEOUT_MS = 8000;
const DEFAULT_READ_TIMEOUT_MS = 120000;

// ===================== 基础 =====================
function str(v) { return v == null ? "" : String(v); }
function msgOf(e) { return e && e.message ? e.message : String(e); }
function enc(v) { return encodeURIComponent(str(v)); }

function ok(data, message) {
  const payload = { success: true, message: message || "ok", data: data };
  if (typeof complete === "function") complete(payload);
  return payload;
}

function fail(message, extra) {
  const payload = Object.assign({ success: false, message: str(message) || "error" }, extra || {});
  if (typeof complete === "function") complete(payload);
  return payload;
}

// 兼容各种响应形态，尽量拿到 body 文本与状态码
function normalize(resp) {
  if (resp == null) return { text: "", status: null };
  const saved =
    resp.content_saved_to ||
    (resp.data && resp.data.content_saved_to) ||
    resp.output_saved_to || "";
  let text = "";
  if (saved && Tools.Files && typeof Tools.Files.read === "function") {
    try {
      let r;
      try { r = Tools.Files.read(saved); } catch (e1) { r = Tools.Files.read({ path: saved, environment: "android" }); }
      if (typeof r === "string") text = r;
      else if (r && typeof r.content === "string") text = r.content;
      else if (r && r.data && typeof r.data.content === "string") text = r.data.content;
    } catch (e) {}
  }
  if (!text) {
    if (typeof resp.content === "string") text = resp.content;
    else if (typeof resp.body === "string") text = resp.body;
    else if (typeof resp.text === "string") text = resp.text;
    else if (typeof resp === "string") text = resp;
    else if (resp.data && typeof resp.data.content === "string") text = resp.data.content;
  }
  const status =
    (resp.statusCode != null ? resp.statusCode : null) ||
    (resp.status != null ? resp.status : null) ||
    (resp.code != null ? resp.code : null) ||
    (resp.data && resp.data.status != null ? resp.data.status : null) ||
    null;
  return { text: str(text), status: status };
}

function tryParseJson(text) {
  if (!text) return null;
  try { return JSON.parse(text); } catch (e) {}
  const m = String(text).match(/\{[\s\S]*\}|\[[\s\S]*\]/);
  if (m) { try { return JSON.parse(m[0]); } catch (e2) {} }
  return null;
}

async function call(method, path, body, timeoutMs) {
  const started = Date.now();
  const headers = { "Authorization": "Bearer " + PC_BRIDGE_TOKEN };
  const opts = {
    url: PC_BRIDGE_BASE + path,
    method: method,
    headers: headers,
    follow_redirects: true,
    connect_timeout: CONNECT_TIMEOUT_MS,
    read_timeout: timeoutMs || DEFAULT_READ_TIMEOUT_MS,
    validateStatus: false
  };
  if (body !== undefined && body !== null) {
    headers["Content-Type"] = "application/json";
    opts.body = JSON.stringify(body);
  }

  let resp;
  try {
    resp = await Tools.Net.http(opts);
  } catch (e) {
    return fail("连不上 PC 桥（" + PC_BRIDGE_BASE + "）：" + msgOf(e) +
      "。检查：电脑上 pc_bridge 是否在跑、手机 IP 是否在 allowIps 里、是否同一局域网。");
  }

  const n = normalize(resp);
  const parsed = tryParseJson(n.text);
  const data = parsed === null ? { raw: n.text } : parsed;
  const status = n.status || 0;

  if (status === 401) {
    return fail("401 鉴权失败：token 与电脑端 bridge.config.json 不一致。");
  }
  if (status === 429) {
    return fail("429 被临时封禁：认证失败次数过多，等 5 分钟或重启电脑端服务。");
  }
  if (status >= 400 || data.ok === false) {
    return fail("PC 桥返回错误（HTTP " + status + "）：" + (data.error || n.text.substring(0, 300)));
  }

  data._http_status = status;
  data._ms = Date.now() - started;
  return ok(data);
}

// ===================== 工具 =====================
async function pc_info(params) {
  return call("GET", "/info");
}

async function pc_exec(params) {
  params = params || {};
  const command = str(params.command).trim();
  if (!command) return fail("command 不能为空");
  const timeoutMs = params.timeout_ms ? Number(params.timeout_ms) : 30000;
  const body = {
    command: command,
    shell: str(params.shell || "cmd").toLowerCase(),
    timeout_ms: timeoutMs
  };
  if (params.cwd) body.cwd = str(params.cwd);
  return call("POST", "/exec", body, timeoutMs + 20000);
}

async function pc_read(params) {
  params = params || {};
  const p = str(params.path).trim();
  if (!p) return fail("path 不能为空");
  return call("POST", "/read", {
    path: p,
    encoding: str(params.encoding || "auto"),
    offset: params.offset ? Number(params.offset) : 0,
    length: params.length ? Number(params.length) : 0
  }, 90000);
}

async function pc_write(params) {
  params = params || {};
  const p = str(params.path).trim();
  if (!p) return fail("path 不能为空");
  return call("POST", "/write", {
    path: p,
    content: params.content === undefined ? "" : String(params.content),
    encoding: str(params.encoding || "utf-8"),
    append: !!params.append
  }, 120000);
}

async function pc_list(params) {
  params = params || {};
  const p = str(params.path).trim();
  if (!p) return fail("path 不能为空");
  return call("POST", "/list", {
    path: p,
    depth: params.depth ? Number(params.depth) : 0
  }, 90000);
}

async function pc_edit(params) {
  params = params || {};
  const p = str(params.path).trim();
  if (!p) return fail("path 不能为空");
  if (params.old_text === undefined || params.old_text === "") return fail("old_text 不能为空");
  return call("POST", "/edit", {
    path: p,
    old_text: String(params.old_text),
    new_text: params.new_text === undefined ? "" : String(params.new_text),
    expected: params.expected === undefined ? 1 : Number(params.expected),
    encoding: str(params.encoding || "auto")
  }, 90000);
}

async function pc_file_url(params) {
  params = params || {};
  const p = str(params.path).trim();
  if (!p) return fail("path 不能为空");
  const url = PC_BRIDGE_BASE + "/download?path=" + enc(p) + "&token=" + enc(PC_BRIDGE_TOKEN)
    + (params.inline ? "&inline=1" : "");
  return ok({
    url: url,
    path: p,
    supports_range: true,
    note: "把这个 URL 交给手机浏览器/下载器即可下载（支持断点续传）。URL 里含 token，不要外发。"
  });
}

async function pc_download(params) {
  params = params || {};
  const p = str(params.path).trim();
  if (!p) return fail("path 不能为空");
  const r = await call("POST", "/read", {
    path: p,
    encoding: "base64",
    offset: params.offset ? Number(params.offset) : 0,
    length: params.length ? Number(params.length) : 4 * 1024 * 1024
  }, 180000);
  return r;
}

async function pc_upload(params) {
  params = params || {};
  const p = str(params.path).trim();
  if (!p) return fail("path 不能为空");
  if (params.content_base64 === undefined) return fail("content_base64 不能为空");
  return call("POST", "/write", {
    path: p,
    content: String(params.content_base64),
    encoding: "base64",
    append: !!params.append
  }, 180000);
}

// ===================== 长期记忆 =====================
async function memory_index(params) {
  return call("GET", "/memory", undefined, 60000);
}

async function memory_list(params) {
  return call("GET", "/memory/list", undefined, 60000);
}

async function memory_read(params) {
  params = params || {};
  const n = str(params.name).trim();
  if (!n) return fail("name 不能为空");
  return call("GET", "/memory/read?name=" + enc(n), undefined, 60000);
}

async function memory_search(params) {
  params = params || {};
  const query = str(params.q).trim();
  if (!query) return fail("q 不能为空");
  const parts = ["q=" + enc(query)];
  if (params.limit) parts.push("limit=" + Number(params.limit));
  if (params.re) parts.push("re=1");
  if (params.case) parts.push("case=1");
  return call("GET", "/memory/search?" + parts.join("&"), undefined, 90000);
}

async function memory_write(params) {
  params = params || {};
  const n = str(params.name).trim();
  if (!n) return fail("name 不能为空");
  if (params.content === undefined) return fail("content 不能为空");
  return call("POST", "/memory/write", {
    name: n,
    content: String(params.content),
    append: !!params.append
  }, 60000);
}

// ===================== 会话（交互式长任务） =====================
async function pc_session_start(params) {
  params = params || {};
  const body = { shell: str(params.shell || "cmd").toLowerCase() };
  if (params.command) body.command = String(params.command);
  if (params.cwd) body.cwd = String(params.cwd);
  return call("POST", "/session/start", body, 30000);
}

async function pc_session_read(params) {
  params = params || {};
  const id = str(params.session_id).trim();
  if (!id) return fail("session_id 不能为空");
  const body = { session_id: id };
  if (params.since !== undefined && params.since !== null && params.since !== "") {
    body.since = Number(params.since);
  }
  return call("POST", "/session/read", body, 60000);
}

async function pc_session_write(params) {
  params = params || {};
  const id = str(params.session_id).trim();
  if (!id) return fail("session_id 不能为空");
  const body = { session_id: id };
  if (params.data !== undefined) body.data = String(params.data);
  if (params.control) body.control = String(params.control);
  return call("POST", "/session/write", body, 30000);
}

async function pc_session_terminate(params) {
  params = params || {};
  const id = str(params.session_id).trim();
  if (!id) return fail("session_id 不能为空");
  return call("POST", "/session/terminate", { session_id: id, remove: !!params.remove }, 30000);
}

async function pc_session_list(params) {
  return call("POST", "/session/list", {}, 30000);
}

// ===================== 导出 =====================
exports.pc_info = pc_info;
exports.pc_exec = pc_exec;
exports.pc_read = pc_read;
exports.pc_write = pc_write;
exports.pc_list = pc_list;
exports.pc_edit = pc_edit;
exports.pc_file_url = pc_file_url;
exports.pc_download = pc_download;
exports.pc_upload = pc_upload;
exports.memory_index = memory_index;
exports.memory_list = memory_list;
exports.memory_read = memory_read;
exports.memory_search = memory_search;
exports.memory_write = memory_write;
exports.pc_session_start = pc_session_start;
exports.pc_session_read = pc_session_read;
exports.pc_session_write = pc_session_write;
exports.pc_session_terminate = pc_session_terminate;
exports.pc_session_list = pc_session_list;