/* METADATA
{
  "name": "qwen_image_pro",
  "display_name": {
    "zh": "Qwen 绘图旗舰版",
    "en": "Qwen Draw Pro"
  },
  "description": {
    "zh": "使用阿里云百炼/DashScope 千问图像【同步】接口生成图片，支持旗舰模型 qwen-image-3.0-pro（官方内置 qwen_draw 包走的是旧异步接口，不支持 3.0 系列）。图片保存到 /sdcard/Download/Operit/plugins/draw/qwen_image_pro/draws/ ，并返回 Markdown 图片提示。",
    "en": "Generate images via DashScope Qwen-Image synchronous API, supporting qwen-image-3.0-pro. Saves to local draws dir and returns a Markdown reference."
  },
  "env": [
    {
      "name": "DASHSCOPE_API_KEY",
      "description": {
        "zh": "DashScope API Key（必填，与内置 qwen_draw 包共用）",
        "en": "DashScope API key (required)"
      },
      "required": true
    },
    {
      "name": "QWEN_IMAGE_PRO_MODEL",
      "description": {
        "zh": "默认模型（可选，默认 qwen-image-3.0-pro；也可用 qwen-image-3.0 省钱）",
        "en": "Default model (optional; default qwen-image-3.0-pro)"
      },
      "required": false
    }
  ],
  "category": "Draw",
  "tools": [
    {
      "name": "draw_image",
      "description": {
        "zh": "用千问图像旗舰模型生成图片（同步接口，无需轮询），保存到本地并返回 Markdown 图片提示。",
        "en": "Generate an image with the Qwen-Image flagship model (sync API), save locally, return Markdown."
      },
      "parameters": [
        { "name": "prompt", "description": { "zh": "绘图提示词（中文或英文）", "en": "Prompt" }, "type": "string", "required": true },
        { "name": "model", "description": { "zh": "模型名（可选，不传则用环境变量 QWEN_IMAGE_PRO_MODEL 或默认 qwen-image-3.0-pro）", "en": "Model name (optional)" }, "type": "string", "required": false },
        { "name": "size", "description": { "zh": "分辨率，如 '2528*1696'（可选，不传由模型自适应）", "en": "Size, e.g. '2528*1696'" }, "type": "string", "required": false },
        { "name": "n", "description": { "zh": "生成张数（可选，默认 1）", "en": "Number of images" }, "type": "number", "required": false },
        { "name": "negative_prompt", "description": { "zh": "负面提示词（可选）", "en": "Negative prompt" }, "type": "string", "required": false },
        { "name": "prompt_extend", "description": { "zh": "是否开启提示词智能改写（可选，默认 true）", "en": "Enable prompt extension" }, "type": "boolean", "required": false },
        { "name": "watermark", "description": { "zh": "是否加水印（可选，默认 false）", "en": "Watermark" }, "type": "boolean", "required": false },
        { "name": "file_name", "description": { "zh": "自定义文件名（不含路径与扩展名）", "en": "Custom file name" }, "type": "string", "required": false },
        { "name": "api_base_url", "description": { "zh": "DashScope Base URL（可选）", "en": "DashScope base URL" }, "type": "string", "required": false }
      ]
    }
  ]
}*/

const qwenImagePro = (function () {
    const TIMEOUT_MS = 300000;
    const client = OkHttp.newBuilder()
        .connectTimeout(TIMEOUT_MS)
        .readTimeout(TIMEOUT_MS)
        .writeTimeout(TIMEOUT_MS)
        .build();
    const DEFAULT_API_BASE_URL = "https://dashscope.aliyuncs.com";
    const DEFAULT_MODEL = "qwen-image-3.0-pro";
    const DRAW_ROOT_DIR = getPluginConfigDir("draw");
    const STORAGE_DIR = DRAW_ROOT_DIR + "/qwen_image_pro";
    const DRAWS_DIR = STORAGE_DIR + "/draws";

    function isRecord(v) { return typeof v === "object" && v !== null; }
    function errMsg(e) { return (e instanceof Error) ? e.message : String(e); }
    function errStack(e) { return (e instanceof Error) ? e.stack : undefined; }
    function joinUrl(base, path) {
        const b = base.endsWith("/") ? base : base + "/";
        const p = path.charAt(0) === "/" ? path.slice(1) : path;
        return b + p;
    }
    function getApiKey() {
        const k = getEnv("DASHSCOPE_API_KEY");
        if (!k) throw new Error("DASHSCOPE_API_KEY 未配置，请在环境变量中设置。");
        return k;
    }
    function getApiBaseUrl(custom) {
        const f = (custom || "").trim();
        if (f) return f;
        const e = (getEnv("DASHSCOPE_API_BASE_URL") || "").trim();
        if (e) return e;
        return DEFAULT_API_BASE_URL;
    }
    function sanitizeFileName(name) {
        return String(name || "").replace(/[\\/:*?"<>|]/g, "_").trim();
    }
    function buildFileName(prompt, custom) {
        const c = sanitizeFileName(custom);
        if (c) return c;
        const head = String(prompt || "").trim().slice(0, 12).replace(/\s+/g, "_");
        return (head || "image") + "_" + Date.now();
    }
    function guessExt(url) {
        const bare = String(url || "").split("?")[0];
        const m = bare.match(/\.([a-zA-Z0-9]+)$/);
        if (m) {
            const e = m[1].toLowerCase();
            if (e === "png" || e === "jpg" || e === "jpeg" || e === "webp") return e;
        }
        return "png";
    }
    function normalizeSize(size) {
        const s = String(size || "").trim().replace(/[xX]/g, "*");
        if (!/^[0-9]+\*[0-9]+$/.test(s)) return "";
        return s;
    }
    async function ensureDirs() {
        const dirs = [DRAW_ROOT_DIR, STORAGE_DIR, DRAWS_DIR];
        for (let i = 0; i < dirs.length; i++) {
            try { await Tools.Files.mkdir(dirs[i]); } catch (e) { console.warn("mkdir " + dirs[i] + " -> " + errMsg(e)); }
        }
    }
    async function generate(opt) {
        const apiKey = getApiKey();
        const baseUrl = getApiBaseUrl(opt.api_base_url);
        const endpoint = joinUrl(baseUrl, "api/v1/services/aigc/multimodal-generation/generation");
        const mParam = String(opt.model || "").trim();
        const mEnv = String(getEnv("QWEN_IMAGE_PRO_MODEL") || "").trim();
        const model = mParam || mEnv || DEFAULT_MODEL;
        const n = (typeof opt.n === "number" && Number.isFinite(opt.n) && opt.n > 0) ? Math.floor(opt.n) : 1;

        const parameters = { n: n };
        const size = normalizeSize(opt.size);
        if (size) parameters["size"] = size;
        if (opt.prompt_extend !== undefined) parameters["prompt_extend"] = !!opt.prompt_extend;
        if (opt.watermark !== undefined) parameters["watermark"] = !!opt.watermark;
        const neg = String(opt.negative_prompt || "").trim();
        if (neg) parameters["negative_prompt"] = neg;

        const body = {
            model: model,
            input: { messages: [ { role: "user", content: [ { text: opt.prompt } ] } ] },
            parameters: parameters
        };
        const headers = {
            "accept": "application/json",
            "content-type": "application/json",
            "Authorization": "Bearer " + apiKey
        };
        const request = client.newRequest().url(endpoint).method("POST").headers(headers).body(JSON.stringify(body), "json");
        const response = await request.build().execute();
        if (!response.isSuccessful()) {
            throw new Error("千问图像生成失败: " + response.statusCode + " - " + response.content);
        }
        let parsed;
        try { parsed = JSON.parse(response.content); }
        catch (e) { throw new Error("解析响应失败: " + errMsg(e)); }
        const output = (isRecord(parsed) && isRecord(parsed["output"])) ? parsed["output"] : null;
        if (!output) throw new Error("响应中缺少 output: " + response.content);
        const choices = Array.isArray(output["choices"]) ? output["choices"] : [];
        const urls = [];
        for (let i = 0; i < choices.length; i++) {
            const msg = choices[i] ? choices[i]["message"] : null;
            const content = (msg && Array.isArray(msg["content"])) ? msg["content"] : [];
            for (let j = 0; j < content.length; j++) {
                const item = content[j];
                if (item && typeof item["image"] === "string" && item["image"]) urls.push(item["image"]);
            }
        }
        if (urls.length === 0) throw new Error("响应中未找到图片 URL: " + response.content);
        return { urls: urls, model: model, usage: parsed["usage"] || null };
    }

    async function draw_image(params) {
        if (!params || !params.prompt || String(params.prompt).trim().length === 0) {
            throw new Error("参数 prompt 不能为空。");
        }
        const prompt = String(params.prompt).trim();
        await ensureDirs();
        const opt = {
            prompt: prompt,
            model: params.model,
            size: params.size,
            n: params.n,
            negative_prompt: params.negative_prompt,
            prompt_extend: params.prompt_extend,
            watermark: params.watermark,
            api_base_url: params.api_base_url
        };
        const gen = await generate(opt);
        const baseName = buildFileName(prompt, params.file_name);
        const saved = [];
        for (let i = 0; i < gen.urls.length; i++) {
            const url = gen.urls[i];
            const ext = guessExt(url);
            const name = gen.urls.length > 1 ? (baseName + "_" + (i + 1)) : baseName;
            const filePath = DRAWS_DIR + "/" + name + "." + ext;
            const dl = await Tools.Files.download(url, filePath);
            if (!dl.successful) throw new Error("下载图片失败: " + dl.details);
            saved.push({ file_path: filePath, file_uri: "file://" + filePath, markdown: "![AI生成的图片](file://" + filePath + ")" });
        }
        const first = saved[0];
        const hintLines = [
            "图片已生成并保存到本地 " + DRAWS_DIR + "。",
            "本地路径: " + first.file_path,
            "",
            "在后续回答中，请直接输出下面这一行 Markdown 来展示这张图片：",
            "",
            first.markdown
        ];
        return {
            files: saved,
            file_path: first.file_path,
            file_uri: first.file_uri,
            markdown: first.markdown,
            prompt: prompt,
            model: gen.model,
            image_url: gen.urls[0],
            usage: gen.usage,
            hint: hintLines.join("\n")
        };
    }

    async function draw_image_wrapper(params) {
        try {
            const result = await draw_image(params);
            complete({
                success: true,
                message: "图片生成成功（" + result.model + "），已保存到 " + DRAWS_DIR + "。",
                data: result
            });
        } catch (error) {
            console.error("draw_image 执行失败:", error);
            complete({
                success: false,
                message: "图片生成失败: " + errMsg(error),
                error_stack: errStack(error)
            });
        }
    }

    return { draw_image: draw_image_wrapper };
})();

exports.draw_image = qwenImagePro.draw_image;
