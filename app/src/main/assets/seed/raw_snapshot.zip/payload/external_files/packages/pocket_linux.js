/* METADATA
{
  "name": "pocket_linux",
  "description": "口袋 Linux：绕开 Operit proot seccomp bug (#1128) 的自愈工具箱。内置 busybox 36 件套 + jq + dulwich(python版git)。生存法则已内建：python 一律 -P、目录只用 python 建、探测不存在的文件会 ENOSYS、chdir/getcwd 全局硬锁。母本与固件缓存在 /sdcard/Download/Operit/pocket_linux/（挂载点可能是 /sdcard 或 /storage/emulated/0，已自动探测）。重建口令：pocket_rebuild。",
  "enabledByDefault": true,
  "tools": [
    {
      "name": "pocket_exec",
      "description": "在口袋 Linux 环境里执行一条命令（自动注入 PATH/LD_LIBRARY_PATH/HOME）。用 /tmp/pocket/bin 下的 applet（ls/sed/awk/tar/jq 在 /tmp/pocket/usr/bin）或直接用绝对路径。python 建议写进脚本文件后用 pocket_python 跑。",
      "parameters": [
        { "name": "command", "description": "shell 命令", "type": "string", "required": true },
        { "name": "timeout_ms", "description": "超时毫秒，默认 60000", "type": "number", "required": false }
      ]
    },
    {
      "name": "pocket_python",
      "description": "跑一段 python 脚本（自动加 -P 防止 import 撞坏 cwd）。脚本可访问全部生存法则补丁。",
      "parameters": [
        { "name": "script", "description": "Python 代码字符串", "type": "string", "required": true },
        { "name": "timeout_ms", "description": "超时毫秒，默认 120000", "type": "number", "required": false }
      ]
    },
    {
      "name": "pocket_status",
      "description": "检查口袋 Linux 健康度：busybox、applets、jq、dulwich 是否就绪",
      "parameters": []
    },
    {
      "name": "pocket_rebuild",
      "description": "一键从 /sdcard 保险柜重建整个口袋 Linux（约 10 秒）。任何组件坏了/丢了/手机重启后先跑这个。",
      "parameters": [
        { "name": "timeout_ms", "description": "超时毫秒，默认 180000", "type": "number", "required": false }
      ]
    }
  ]
}
*/

const pocketLinux = (function () {
  var EXEC_KEY = "pocket_linux_executor";

  function findBase(cmdPrefix) {
    // 探测保险柜挂载点（不同会话可能是 /sdcard 或 /storage/emulated/0）
    return cmdPrefix +
      "if [ -f /sdcard/Download/Operit/pocket_linux/pocket_setup.py ]; then BASE=/sdcard; " +
      "elif [ -f /storage/emulated/0/Download/Operit/pocket_linux/pocket_setup.py ]; then BASE=/storage/emulated/0; " +
      "else BASE=UNKNOWN; fi; ";
  }

  function envPrefix() {
    return "export HOME=/tmp GIT_CONFIG_NOSYSTEM=1 " +
      "PATH=/tmp/pocket/bin:/tmp/pocket/usr/bin:$PATH " +
      "LD_LIBRARY_PATH=/tmp/pocket/usr/lib/aarch64-linux-gnu:$LD_LIBRARY_PATH; ";
  }

  async function sh(command, timeoutMs) {
    var options = { executorKey: EXEC_KEY };
    if (timeoutMs !== undefined) options.timeoutMs = timeoutMs;
    var r = await Tools.System.terminal.hiddenExec(command, options);
    return r;
  }

  function esc(s) {
    return String(s).replace(/'/g, "'\\''");
  }

  async function pocket_exec(params) {
    var cmd = params.command;
    if (!cmd || !String(cmd).trim()) throw new Error("请提供 command");
    var t = params.timeout_ms || 60000;
    var full = findBase("") + envPrefix() + String(cmd);
    var r = await sh(full, t);
    return {
      exitCode: r.exitCode,
      output: (r.output || "") + (r.output ? "" : "")
    };
  }

  async function pocket_python(params) {
    var script = params.script;
    if (!script || !String(script).trim()) throw new Error("请提供 script");
    var t = params.timeout_ms || 120000;
    var b64 = (typeof Buffer !== "undefined")
      ? Buffer.from(script, "utf8").toString("base64")
      : null;
    var path = "/tmp/pocket_script.py";
    var writeCmd;
    if (b64) {
      writeCmd = "echo '" + b64 + "' | base64 -d > " + path;
    } else {
      writeCmd = "cat > " + path + " <<'PK_EOF'\n" + script + "\nPK_EOF";
    }
    await sh(writeCmd, 30000);
    var runCmd = findBase("") + envPrefix() + "python3 -P " + path + "; ec=$?; rm -f " + path + "; exit $ec";
    var r = await sh(runCmd, t);
    if (r.exitCode !== 0 && r.exitCode !== undefined && r.exitCode !== null) {
      throw new Error("pocket python 失败 (exit " + r.exitCode + "):\n" + (r.output || ""));
    }
    return (r.output || "").trim() || "(no output)";
  }

  async function pocket_status() {
    var probe = envPrefix() + findBase("") +
      "echo BASE=$BASE; " +
      "if [ -x /tmp/busybox ]; then echo BUSYBOX=yes; else echo BUSYBOX=no; fi; " +
      "if [ -d /tmp/pocket/bin ]; then echo APPLETS=$(ls /tmp/pocket/bin | wc -l); else echo APPLETS=0; fi; " +
      "/tmp/pocket/usr/bin/jq --version 2>&1 | head -1; " +
      "python3 -P -c 'import dulwich; print(\"dulwich\", dulwich.__version__)' 2>&1 | head -1; ";
    var r = await sh(probe, 60000);
    var out = r.output || "";
    var ready = (out.indexOf("BUSYBOX=yes") >= 0) && (out.indexOf("jq-") >= 0 || out.indexOf("jq 1") >= 0) && (out.indexOf("dulwich") >= 0 && out.indexOf("No module") < 0);
    return {
      ready: ready,
      detail: out.trim(),
      hint: ready ? "就绪" : "未就绪——请调用 pocket_rebuild"
    };
  }

  async function pocket_rebuild(params) {
    var t = params.timeout_ms || 180000;
    var setup = "";
    var probe = findBase("");
    var r0 = await sh(probe + "echo $BASE", 15000);
    var base = ((r0.output || "").match(/BASE=(\S+)/) || [])[1];
    if (!base || base === "UNKNOWN") {
      throw new Error("保险柜未找到（/sdcard 与 /storage/emulated/0 都探测失败）");
    }
    setup = base + "/Download/Operit/pocket_linux/pocket_setup.py";
    var r = await sh("python3 -P '" + esc(setup) + "' 2>&1 | tail -6", t);
    var out = r.output || "";
    var ok = out.indexOf("POCKET_READY") >= 0;
    return {
      rebuilt: ok,
      output: out.trim(),
      hint: ok ? "重建完成" : "未完全就绪——若显示 POCKET_PARTIAL，直接再跑一次 pocket_rebuild（随机拦截重试通常可过）"
    };
  }

  async function main() {
    var s = await pocket_status();
    return "pocket_linux smoke: ready=" + s.ready + " | " + s.detail.replace(/\n/g, " | ");
  }

  return {
    main: main,
    pocket_exec: pocket_exec,
    pocket_python: pocket_python,
    pocket_status: pocket_status,
    pocket_rebuild: pocket_rebuild
  };
})();

exports.main = pocketLinux.main;
exports.pocket_exec = pocketLinux.pocket_exec;
exports.pocket_python = pocketLinux.pocket_python;
exports.pocket_status = pocketLinux.pocket_status;
exports.pocket_rebuild = pocketLinux.pocket_rebuild;