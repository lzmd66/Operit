/* METADATA
{
  "name": "metaso_search",
  "display_name": {
    "zh": "秘塔搜索",
    "en": "Metaso Search"
  },
      "description": {
        "zh": "秘塔（Metaso）搜索 API：中文媒体召回强（含 B站/抖音转写/什么值得买），适合中文选购/口碑场景兜底；带 reader 网页正文读取（markdown 全文，号称支持公众号）。约 0.03 元/次（3 credits），每日免费 100 积分。",
        "en": "Metaso API: strong Chinese media recall (Bilibili/Douyin transcripts/smzdm) + reader for full-page markdown. ~0.03 CNY per call (3 credits), 100 free credits daily."
      },
  "author": "浮生一梦",
  "env": [
    {
      "name": "METASO_API_KEY",
      "description": {
        "zh": "秘塔搜索 API Key，metaso.cn/search-api/api-keys 获取（mk-开头）",
        "en": "Metaso API key from metaso.cn search-api console (starts with mk-)"
      },
      "required": false
    }
  ],
  "category": "Search",
  "tools": [
    {
      "name": "search",
      "description": {
        "zh": "使用秘塔搜索 API 搜索。中文科技媒体/选购口碑召回强，能返回 B站专栏、抖音视频转写等中文生态内容。每次消耗 credits（实测最低配置 3 credits）。",
        "en": "Search via Metaso API. Strong for Chinese tech media and purchase reviews, returns Bilibili/Douyin transcript content. Costs credits (3 observed for basic call)."
      },
      "parameters": [
        { "name": "query", "description": { "zh": "搜索关键词", "en": "Search query" }, "type": "string", "required": true },
        { "name": "size", "description": { "zh": "结果数量，默认 5（省 credits 就调小）", "en": "Result count, default 5" }, "type": "number", "required": false },
        { "name": "page", "description": { "zh": "页码，默认 1", "en": "Page number" }, "type": "number", "required": false },
        { "name": "scope", "description": { "zh": "搜索范围，默认 webpage（已验证）。其他取值未验证，可参考官方 playground", "en": "Search scope, default webpage (verified)" }, "type": "string", "required": false },
        { "name": "include_summary", "description": { "zh": "通过摘要信息进行召回增强（消耗更多 credits，默认关）", "en": "Summary-recall boost, costs more credits" }, "type": "boolean", "required": false },
        { "name": "concise_snippet", "description": { "zh": "返回精简的原文匹配信息（默认关）", "en": "Concise snippet mode" }, "type": "boolean", "required": false },
        { "name": "api_key", "description": { "zh": "API Key（可选，不传则读取环境变量）", "en": "API key override" }, "type": "string", "required": false }
      ]
    },
    {
      "name": "reader",
      "description": {
        "zh": "读取网页正文，返回 markdown 全文（含表格）。号称支持公众号文章（未实测）。每次消耗约 3 credits。",
        "en": "Read a webpage, return full markdown content incl. tables. Claims WeChat article support (unverified). ~3 credits per call."
      },
      "parameters": [
        { "name": "url", "description": { "zh": "要读取的网页 URL", "en": "URL to read" }, "type": "string", "required": true },
        { "name": "api_key", "description": { "zh": "API Key（可选，不传则读取环境变量）", "en": "API key override" }, "type": "string", "required": false }
      ]
    },
    {
      "name": "test",
      "description": {
        "zh": "测试 API 连通（消耗 credits，用最小 size=1）",
        "en": "Test API connectivity (costs credits, size=1)"
      },
      "parameters": []
    }
  ]
}*/
/// <reference path="./types/index.d.ts" />
const metasoSearch = (function () {
    const API_URL = "https://metaso.cn/api/v1/search";
    const READER_URL = "https://metaso.cn/api/v1/reader";
    const TIMEOUT = 30000;
    const client = OkHttp.newBuilder()
        .connectTimeout(TIMEOUT)
        .readTimeout(TIMEOUT)
        .writeTimeout(TIMEOUT)
        .build();
    function getApiKey(providedKey) {
        if (providedKey)
            return providedKey;
        const key = getEnv("METASO_API_KEY");
        return key || "";
    }
    async function httpPost(url, body, apiKey) {
        const key = getApiKey(apiKey || undefined);
        if (!key) {
            throw new Error("未设置 API Key，请配置 METASO_API_KEY 环境变量或在调用时传入 api_key 参数");
        }
        const request = client
            .newRequest()
            .url(url)
            .method("POST")
            .header("Authorization", "Bearer " + key)
            .header("Content-Type", "application/json")
            .body(JSON.stringify(body), "json");
        const response = await request.build().execute();
        const content = response.content;
        if (!response.isSuccessful()) {
            throw new Error("HTTP " + response.statusCode + ": " + content);
        }
        return JSON.parse(content);
    }
    function assertNoBusinessError(result) {
        if (result && result.errCode && result.errCode !== 0) {
            throw new Error("API 业务错误 errCode=" + result.errCode + ": " + (result.errMsg || "未知错误"));
        }
        return result;
    }
    function mapWebpages(webpages) {
        if (!webpages || !Array.isArray(webpages))
            return [];
        return webpages.map(function (item) {
            return {
                title: item.title,
                link: item.link,
                snippet: item.snippet,
                score: item.score,
                date: item.date || null,
                authors: item.authors || null,
                position: item.position || null
            };
        });
    }
    async function search(params) {
        const body = {
            q: params.query,
            scope: params.scope || "webpage",
            size: Math.max(1, Math.min(20, params.size || 5))
        };
        if (params.page && params.page > 1) {
            body.page = params.page;
        }
        if (params.include_summary) {
            body.includeSummary = true;
        }
        if (params.concise_snippet) {
            body.conciseSnippet = true;
        }
        const result = await httpPost(API_URL, body, params.api_key);
        const results = mapWebpages(result.webpages);
        return {
            success: true,
            query: params.query,
            results: results,
            count: results.length,
            total_available: result.total || null,
            credits_used: result.credits || 0
        };
    }
    async function readPage(params) {
        if (!params.url) {
            throw new Error("缺少 url 参数");
        }
        const body = { url: params.url };
        const result = assertNoBusinessError(await httpPost(READER_URL, body, params.api_key));
        if (!result.markdown && !result.content) {
            throw new Error("API 返回了空内容（该页面可能不被支持，或字段名与预期不符）");
        }
        return {
            success: true,
            url: result.url || params.url,
            title: result.title || null,
            date: result.date || null,
            author: result.author || null,
            markdown: result.markdown || result.content || null,
            credits_used: result.credits || 0
        };
    }
    async function test() {
        const body = {
            q: "hello",
            scope: "webpage",
            size: 1
        };
        const start = Date.now();
        const result = await httpPost(API_URL, body, null);
        const latency = Date.now() - start;
        return {
            success: true,
            latency: latency,
            credits_used: result.credits || 0
        };
    }
    async function searchWrapper(params) {
        try {
            const result = await search(params);
            complete({
                success: true,
                message: "搜索完成，找到 " + result.count + " 条结果（消耗 " + result.credits_used + " credits）",
                data: result
            });
        }
        catch (error) {
            complete({
                success: false,
                message: "搜索失败：" + error.message,
                error_stack: error.stack
            });
        }
    }
    async function readerWrapper(params) {
        try {
            const result = await readPage(params);
            complete({
                success: true,
                message: "读取完成（消耗 " + result.credits_used + " credits）",
                data: result
            });
        }
        catch (error) {
            complete({
                success: false,
                message: "读取失败：" + error.message,
                error_stack: error.stack
            });
        }
    }
    async function testWrapper() {
        try {
            const result = await test();
            complete({
                success: true,
                message: "连接成功，延迟 " + result.latency + "ms（消耗 " + result.credits_used + " credits）",
                data: result
            });
        }
        catch (error) {
            complete({
                success: false,
                message: "测试失败：" + error.message,
                error_stack: error.stack
            });
        }
    }
    return {
        search: searchWrapper,
        reader: readerWrapper,
        test: testWrapper
    };
})();
exports.search = metasoSearch.search;
exports.reader = metasoSearch.reader;
exports.test = metasoSearch.test;