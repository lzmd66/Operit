/*
METADATA
{
    "name": "csp_bridge",
    "display_name": {
        "zh": "CSP浏览器桥（Termux）",
        "en": "CSP Bridge (Termux)"
    },
    "description": {
        "zh": "通过 Termux 里的 headless Chromium（CDP 调试通道）操作严格 CSP 站点（Bing/Google 类）：打开网页、执行任意 JS、读文本、截图。为 Operit 内浏览器无法处理的 CSP 站点提供高上限通道。依赖 Termux 侧服务（打开 Termux 会自动拉起；断线后重新打开 Termux 即恢复）。",
        "en": "Operate strict-CSP sites via headless Chromium (CDP) running inside Termux."
    },
    "category": "Automatic",
    "tools": [
        {
            "name": "csp_status",
            "description": {
                "zh": "检查 CSP 桥接通道状态（Termux 服务与 CDP 是否在线）。",
                "en": "Check bridge and CDP status."
            },
            "parameters": []
        },
        {
            "name": "csp_open",
            "description": {
                "zh": "通过 Termux 通道打开一个网址（支持严格 CSP 站点），返回标题与 URL。",
                "en": "Open a URL via the Termux channel."
            },
            "parameters": [
                { "name": "url", "description": { "zh": "目标网址。", "en": "Target URL." }, "type": "string", "required": true }
            ]
        },
        {
            "name": "csp_eval",
            "description": {
                "zh": "在指定页面（按 URL 子串匹配）执行任意 JavaScript 表达式并返回结果。CSP 站点上也能执行（调试通道不受页面 CSP 限制）。用于点击、填表、抓取、操作页面。",
                "en": "Evaluate any JS expression on a matching page via CDP."
            },
            "parameters": [
                { "name": "url_sub", "description": { "zh": "URL 子串（用于找到目标标签页），留空则用第一个页面。", "en": "URL substring to find the target page." }, "type": "string", "required": false },
                { "name": "expr", "description": { "zh": "要执行的 JS 表达式。", "en": "JS expression to evaluate." }, "type": "string", "required": true }
            ]
        },
        {
            "name": "csp_read",
            "description": {
                "zh": "读取指定页面的正文文本（按 URL 子串匹配）。",
                "en": "Read page text via the bridge."
            },
            "parameters": [
                { "name": "url_sub", "description": { "zh": "URL 子串。", "en": "URL substring." }, "type": "string", "required": false },
                { "name": "max_chars", "description": { "zh": "可选，最大字数，默认 3000。", "en": "Optional max chars, default 3000." }, "type": "number", "required": false }
            ]
        },
        {
            "name": "csp_shot",
            "description": {
                "zh": "对指定页面截图（JPEG），返回文件路径（默认存到 /storage/emulated/0/Download/Operit/tmp/csp_shot.jpg）。",
                "en": "Screenshot the page, returns file path."
            },
            "parameters": [
                { "name": "url_sub", "description": { "zh": "URL 子串。", "en": "URL substring." }, "type": "string", "required": false },
                { "name": "out", "description": { "zh": "可选，输出文件绝对路径。", "en": "Optional output path." }, "type": "string", "required": false }
            ]
        }
    ]
}
*/

const BASE = "http://127.0.0.1:9777";
const T_GEN = 30000;
const T_OPEN = 60000;

function msgOf(e) { return e && e.message ? e.message : String(e); }

async function callApi(path, params, timeoutMs) {
    const qs = Object.keys(params || {}).map(function (k) {
        return encodeURIComponent(k) + "=" + encodeURIComponent(String(params[k] == null ? "" : params[k]));
    }).join("&");
    const url = BASE + path + (qs ? ("?" + qs) : "");
    let resp = null;
    try {
        resp = await Tools.Net.http({
            url: url,
            method: "GET",
            connect_timeout: 5000,
            read_timeout: timeoutMs || T_GEN,
            responseType: "text",
            validateStatus: false
        });
    } catch (e) {
        throw new Error("CSP 桥接通道不可达（连接失败）。处理：打开一次 Termux 会自动拉起服务；或检查 ~/csp_browser/server.log。原始错误: " + msgOf(e));
    }
    const text = typeof resp === "string"
        ? resp
        : (resp && resp.content !== undefined ? String(resp.content) : String(resp));
    let data = null;
    try {
        data = JSON.parse(text);
    } catch (e2) {
        throw new Error("CSP 桥接返回非 JSON: " + text.slice(0, 300));
    }
    return data;
}

async function csp_status() {
    const d = await callApi("/status", {}, 10000);
    return "CSP 桥接: " + ((d && d.ok) ? "服务在线" : "服务异常") + "；CDP: " + ((d && d.cdp) ? "在线" : "离线（调用时会自动拉起）");
}

async function csp_open(params) {
    const url = params && params.url ? String(params.url).trim() : "";
    if (!url) { throw new Error("url 不能为空"); }
    const d = await callApi("/open", { url: url }, T_OPEN);
    if (!d || d.ok !== true) { throw new Error("打开失败: " + ((d && d.error) || "unknown")); }
    return "已打开（Termux 通道）: " + String(d.title || "") + "\nURL: " + String(d.url || "");
}

async function csp_eval(params) {
    const urlSub = params && params.url_sub ? String(params.url_sub).trim() : "";
    const expr = params && params.expr ? String(params.expr) : "";
    if (!expr) { throw new Error("expr 不能为空"); }
    const d = await callApi("/eval", { url_sub: urlSub, expr: expr }, T_GEN);
    if (!d || d.ok !== true) { throw new Error("执行失败: " + ((d && d.error) || "unknown")); }
    return "执行结果: " + (typeof d.result === "string" ? d.result : JSON.stringify(d.result));
}

async function csp_read(params) {
    const urlSub = params && params.url_sub ? String(params.url_sub).trim() : "";
    const max = params && params.max_chars !== undefined ? Number(params.max_chars) : 3000;
    const d = await callApi("/read", { url_sub: urlSub, max: max }, T_GEN);
    if (!d || d.ok !== true) { throw new Error("读取失败: " + ((d && d.error) || "unknown")); }
    return String(d.result || "");
}

async function csp_shot(params) {
    const urlSub = params && params.url_sub ? String(params.url_sub).trim() : "";
    const out = params && params.out ? String(params.out) : "";
    const d = await callApi("/shot", { url_sub: urlSub, out: out }, T_GEN);
    if (!d || d.ok !== true) { throw new Error("截图失败: " + ((d && d.error) || "unknown")); }
    return "截图完成: " + String(d.path || "") + "（" + String(d.bytes || 0) + " 字节）";
}

exports.csp_status = csp_status;
exports.csp_open = csp_open;
exports.csp_eval = csp_eval;
exports.csp_read = csp_read;
exports.csp_shot = csp_shot;

exports.main = function () {
    return "csp_bridge ready: csp_status / csp_open / csp_eval / csp_read / csp_shot";
};