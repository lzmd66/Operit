/*
METADATA
{
    "name": "py_tools_plus",
    "description": "Python 工具独立注册版（方案B 静态代理）：每个 Python 工具注册为独立工具，直接调用。由 gen_bridge.py 自动生成，请勿手改。",
    "enabledByDefault": true,
    "tools": [
        {
            "name": "calc",
            "description": "Python 计算器：支持加减乘除、幂、取余",
            "parameters": [
                {
                    "name": "a",
                    "description": "第一个数",
                    "type": "number",
                    "required": true
                },
                {
                    "name": "b",
                    "description": "第二个数",
                    "type": "number",
                    "required": true
                },
                {
                    "name": "op",
                    "description": "运算: add/sub/mul/div/pow/mod",
                    "type": "string",
                    "required": true
                }
            ]
        },
        {
            "name": "hello",
            "description": "Python 示例工具：问候并回显",
            "parameters": [
                {
                    "name": "name",
                    "description": "你的名字",
                    "type": "string",
                    "required": false
                }
            ]
        },
        {
            "name": "rename_files",
            "description": "批量重命名文件（正则替换文件名）。默认 dry_run 预览模式，确认无误后再实际执行。",
            "parameters": [
                {
                    "name": "directory",
                    "description": "目标目录",
                    "type": "string",
                    "required": true
                },
                {
                    "name": "pattern",
                    "description": "匹配文件名的正则表达式",
                    "type": "string",
                    "required": true
                },
                {
                    "name": "replacement",
                    "description": "替换字符串（支持 \\1 反向引用）",
                    "type": "string",
                    "required": false
                },
                {
                    "name": "dry_run",
                    "description": "预览模式，默认 true（只显示将如何改名，不实际执行）",
                    "type": "boolean",
                    "required": false
                },
                {
                    "name": "recursive",
                    "description": "是否递归子目录，默认 false",
                    "type": "boolean",
                    "required": false
                }
            ]
        }
    ]
}
*/

const pyToolsPlus = (function () {

  const TOOLS_DIR = "/sdcard/Download/Operit/py_tools";
  const PARAMS_FILE = TOOLS_DIR + "/.params_plus.json";

  function extractText(r) {
    if (r == null) return "";
    if (typeof r === "string") return r;
    if (typeof r.content === "string") return r.content;
    if (typeof r.text === "string") return r.text;
    if (typeof r.output === "string") return r.output;
    if (typeof r.data === "string") return r.data;
    if (r.data && typeof r.data.content === "string") return r.data.content;
    if (r.data && typeof r.data.output === "string") return r.data.output;
    try { return JSON.stringify(r); } catch (e) { return String(r); }
  }

  async function exec(command, timeoutMs) {
    var t = timeoutMs || 90000;
    // 1) hiddenExec（新 executorKey 避开历史坏会话；实测可用）
    try {
      if (Tools && Tools.System && Tools.System.terminal &&
          typeof Tools.System.terminal.hiddenExec === "function") {
        var r0 = await Tools.System.terminal.hiddenExec(
          "cd /tmp 2>/dev/null; " + command,
          { executorKey: "py_tools_exec", timeoutMs: t }
        );
        var out0 = extractText(r0);
        if (out0 && out0.length > 0) {
          return { output: out0, exitCode: 0, via: "hiddenExec" };
        }
      }
    } catch (e0) {}
    // 2) toolCall super_admin:terminal（备用）
    try {
      if (typeof toolCall === "function") {
        var r = await toolCall("super_admin", "terminal", { command: command, timeoutMs: t });
        return { output: extractText(r), exitCode: 0, via: "toolCall" };
      }
    } catch (e) {
      return { output: String(e && e.message ? e.message : e), exitCode: -1, via: "toolCallThrew" };
    }
    return { output: "no exec backend", exitCode: -1, via: "none" };
  }

  async function writeText(path, text) {
    try { await Tools.Files.write(path, String(text), false, "android"); return true; }
    catch (e) {
      try { await Tools.Files.write(path, String(text), false); return true; }
      catch (e2) { return false; }
    }
  }

  async function callPy(toolName, params) {
    var payload = JSON.stringify(params || {});
    var ok = await writeText(PARAMS_FILE, payload);
    if (!ok) return { success: false, error: "无法写入参数文件" };
    var cmd = "cd /tmp 2>/dev/null; python3 '" + TOOLS_DIR + "/" + toolName + ".py' " +
      toolName + " < '" + PARAMS_FILE + "' 2>&1";
    var r = await exec(cmd, 90000);
    var out = (r.output || "").trim();
    if (r.via === "failed" || r.via === "toolCallThrew" || r.via === "hiddenExecThrew" || r.via === "none") {
      return { success: false, error: "终端后端不可用(" + r.via + "): " + out };
    }
    try {
      var parsed = JSON.parse(out);
      if (parsed && typeof parsed === "object" && parsed.command !== undefined &&
          typeof parsed.output === "string") {
        out = String(parsed.output).trim();
        try { parsed = JSON.parse(out); }
        catch (e2) { return { success: true, raw_output: out || "(no output)" }; }
      }
      if (parsed.ok === false) {
        return { success: false, error: parsed.error || "python 工具执行失败" };
      }
      return { success: true, result: parsed.result !== undefined ? parsed.result : null };
    } catch (e) {
      return { success: true, raw_output: out || "(no output)" };
    }
  }

  async function calc(params) { return await callPy("calc", params); }
  async function hello(params) { return await callPy("hello", params); }
  async function rename_files(params) { return await callPy("rename_files", params); }
  return {
    calc: calc,
    hello: hello,
    rename_files: rename_files
  };
})();

exports.calc = pyToolsPlus.calc;
exports.hello = pyToolsPlus.hello;
exports.rename_files = pyToolsPlus.rename_files;
