/* METADATA
{
  "name": "tavily_search",
  "display_name": {
    "zh": "Tavily 搜索",
    "en": "Tavily Search"
  },
  "description": {
    "zh": "Tavily 搜索 API（海外，免费层每月1000次）。英文/国际信息检索与新闻实时搜索，作为免费引擎之外的 API 级备份。",
    "en": "Tavily Search API (overseas, 1000 free credits/month). English/global web & news search, API-level backup beyond free engines."
  },
  "author": "浮生一梦",
  "env": [
    {
      "name": "TAVILY_API_KEY",
      "description": {
        "zh": "Tavily API Key，在 tavily.com 注册获取（tvly-开头）",
        "en": "Tavily API Key from tavily.com (starts with tvly-)"
      },
      "required": false
    }
  ],
  "category": "Search",
  "tools": [
    {
      "name": "search",
      "description": {
        "zh": "使用 Tavily Search API 搜索。basic/fast/ultra-fast 深度每次消耗1积分，advanced 消耗2积分。topic=news 可搜实时新闻。",
        "en": "Search via Tavily API. basic/fast/ultra-fast cost 1 credit each, advanced costs 2. topic=news for real-time news."
      },
      "parameters": [
        { "name": "query", "description": { "zh": "搜索关键词", "en": "Search query" }, "type": "string", "required": true },
        { "name": "search_depth", "description": { "zh": "搜索深度：basic(默认,1积分)/advanced(2积分)/fast/ultra-fast", "en": "Search depth" }, "type": "string", "required": false },
        { "name": "topic", "description": { "zh": "类别：general(默认)/news(实时新闻)/finance", "en": "Topic category" }, "type": "string", "required": false },
        { "name": "max_results", "description": { "zh": "返回结果数 (1-20)，默认 5", "en": "Max results (1-20)" }, "type": "number", "required": false },
        { "name": "time_range", "description": { "zh": "时间范围：day/week/month/year", "en": "Time range" }, "type": "string", "required": false },
        { "name": "country", "description": { "zh": "国家偏向（如 china/united states），仅 topic=general 时有效", "en": "Country boost" }, "type": "string", "required": false },
        { "name": "include_domains", "description": { "zh": "仅搜索这些域名，逗号分隔", "en": "Comma-separated domains to include" }, "type": "string", "required": false },
        { "name": "exclude_domains", "description": { "zh": "排除这些域名，逗号分隔", "en": "Comma-separated domains to exclude" }, "type": "string", "required": false },
        { "name": "api_key", "description": { "zh": "Tavily API Key（可选，不传则读取环境变量）", "en": "Tavily API Key (optional override)" }, "type": "string", "required": false }
      ]
    },
    {
      "name": "test",
      "description": {
        "zh": "测试 API 连接与剩余积分情况",
        "en": "Test API connection"
      },
      "parameters": []
    }
  ]
}*/
/// <reference path="./types/index.d.ts" />
const tavilySearch = (function () {
    const API_URL = "https://api.tavily.com/search";
    const TIMEOUT = 30000;
    const client = OkHttp.newBuilder()
        .connectTimeout(TIMEOUT)
        .readTimeout(TIMEOUT)
        .writeTimeout(TIMEOUT)
        .build();
    function getApiKey(providedKey) {
        if (providedKey)
            return providedKey;
        let key = getEnv("TAVILY_API_KEY");
        return key || "";
    }
    function parseDomains(csv) {
        if (!csv)
            return null;
        const list = String(csv)
            .split(",")
            .map(function (s) { return s.trim(); })
            .filter(function (s) { return s.length > 0; });
        return list.length > 0 ? list : null;
    }
    async function httpPost(body, apiKey) {
        const key = getApiKey(apiKey || undefined);
        if (!key) {
            throw new Error("未设置 API Key，请配置 TAVILY_API_KEY 环境变量或在调用时传入 api_key 参数");
        }
        const request = client
            .newRequest()
            .url(API_URL)
            .method("POST")
            .header("Authorization", "Bearer " + key)
            .header("Content-Type", "application/json")
            .body(JSON.stringify(body), "json");
        const response = await request.build().execute();
        const content = response.content;
        if (!response.isSuccessful()) {
            throw new Error("HTTP " + response.statusCode + ": " + content);
        }
        return JSON.parse(content);
    }
    async function search(params) {
        const body = {
            query: params.query,
            search_depth: params.search_depth || "basic",
            topic: params.topic || "general",
            max_results: Math.max(1, Math.min(20, params.max_results || 5)),
            include_answer: false,
            include_raw_content: false
        };
        if (params.time_range) {
            body.time_range = params.time_range;
        }
        if (params.country && (params.topic || "general") === "general") {
            body.country = params.country;
        }
        const includeDomains = parseDomains(params.include_domains);
        if (includeDomains)
            body.include_domains = includeDomains;
        const excludeDomains = parseDomains(params.exclude_domains);
        if (excludeDomains)
            body.exclude_domains = excludeDomains;
        const result = await httpPost(body, params.api_key);
        let results = [];
        if (result.results && Array.isArray(result.results)) {
            results = result.results.map(function (item) {
                return {
                    title: item.title,
                    url: item.url,
                    content: item.content,
                    score: item.score,
                    published_date: item.published_date || null
                };
            });
        }
        return {
            success: true,
            query: params.query,
            results: results,
            count: results.length,
            credits_used: result.usage && result.usage.credits ? result.usage.credits : 1,
            response_time: result.response_time || null
        };
    }
    async function test() {
        const body = {
            query: "hello",
            search_depth: "basic",
            topic: "general",
            max_results: 1,
            include_answer: false
        };
        const start = Date.now();
        const result = await httpPost(body, null);
        const latency = Date.now() - start;
        return {
            success: true,
            latency: latency,
            credits_used: result.usage && result.usage.credits ? result.usage.credits : 1
        };
    }
    async function searchWrapper(params) {
        try {
            const result = await search(params);
            complete({
                success: true,
                message: "搜索完成，找到 " + result.count + " 条结果（本次消耗 " + result.credits_used + " 积分）",
                data: result
            });
        }
        catch (error) {
            complete({
                success: false,
                message: "搜索失败：" + error.message,
                error_stack: error.stack
            });
        }
    }
    async function testWrapper() {
        try {
            const result = await test();
            complete({
                success: true,
                message: "连接成功，延迟 " + result.latency + "ms（消耗 " + result.credits_used + " 积分）",
                data: result
            });
        }
        catch (error) {
            complete({
                success: false,
                message: "测试失败：" + error.message,
                error_stack: error.stack
            });
        }
    }
    return {
        search: searchWrapper,
        test: testWrapper
    };
})();
exports.search = tavilySearch.search;
exports.test = tavilySearch.test;