/* METADATA
{
  "name": "deepseek_search",
  "display_name": { "zh": "DeepSeek 搜索", "en": "DeepSeek Search" },
  "description": {
    "zh": "DeepSeek 官方搜索/抓取 API（2026-10 新上线）：search 网页搜索 $0.75/1000 次成功请求（≈¥0.005/次，支持 site:/lang:/after:/before: 等操作符）；fetch 网页转 Markdown（同价）；test 零成本查余额。按成功且有结果计费，空结果/失败不计费。账号级 QPS 5。境内直连 api.deepseek.com。Key 读 DEEPSEEK_API_KEY 环境变量（或 /sdcard/Download/Operit/deepseek/config.json 的 api_key 字段）。",
    "en": "DeepSeek official Search & Fetch API: search ($0.75 per 1000 successful requests, query operators supported) and fetch URL to Markdown; free balance self-test. Billed only on successful non-empty results. Account-level QPS 5."
  },
  "author": "浮生一梦",
  "env": [
    {
      "name": "DEEPSEEK_API_KEY",
      "description": {
        "zh": "DeepSeek 开放平台 API Key（sk-开头，platform.deepseek.com 创建）。可选：不设置则读 config.json",
        "en": "DeepSeek Open Platform API key (sk-...). Optional; falls back to config.json"
      },
      "required": false
    }
  ],
  "category": "Search",
  "tools": [
    {
      "name": "search",
      "description": {
        "zh": "DeepSeek 网页搜索：返回标题/链接/摘要/长摘要/日期/权威等级/相关性分。支持查询操作符：site: / -site: / - / \"\" / lang: / after: / before:（时效题务必带 after:）。¥0.005/次，空结果或失败不计费。",
        "en": "DeepSeek web search: title/url/snippet/summary/date/authority/rerank score. Query operators supported. $0.00075 per successful non-empty call."
      },
      "parameters": [
        { "name": "query", "description": { "zh": "搜索词（1-128字符，支持 site:/lang:/after:/before: 等操作符）", "en": "Search query with optional operators" }, "type": "string", "required": true },
        { "name": "count", "description": { "zh": "结果数 1-50，默认10（不影响计费）", "en": "Result count 1-50, default 10" }, "type": "number", "required": false },
        { "name": "need_content", "description": { "zh": "true 时每条结果附带网页正文（content 字段），可能很长", "en": "Include page content per result" }, "type": "boolean", "required": false },
        { "name": "ori_question", "description": { "zh": "触发搜索的原始用户问题（1-128字符），用于提升意图理解", "en": "Original user question to improve intent understanding" }, "type": "string", "required": false },
        { "name": "localization", "description": { "zh": "可选 IP 地址，用于本地化搜索结果", "en": "Optional IP to localize results" }, "type": "string", "required": false },
        { "name": "api_key", "description": { "zh": "API Key（可选覆盖）", "en": "API key override" }, "type": "string", "required": false }
      ]
    },
    {
      "name": "fetch",
      "description": {
        "zh": "抓取单个网页，返回标题与 Markdown 正文（含表格）。¥0.005/次，失败或取不到内容不计费。",
        "en": "Fetch one web page as Markdown. $0.00075 per successful call."
      },
      "parameters": [
        { "name": "url", "description": { "zh": "要抓取的网页 URL（http/https，≤8192字符）", "en": "URL to fetch" }, "type": "string", "required": true },
        { "name": "max_chars", "description": { "zh": "正文截断长度，默认30000，范围1000-200000", "en": "Max chars, default 30000" }, "type": "number", "required": false },
        { "name": "api_key", "description": { "zh": "API Key（可选覆盖）", "en": "API key override" }, "type": "string", "required": false }
      ]
    },
    {
      "name": "test",
      "description": {
        "zh": "零成本自检：验证 Key 有效性并查询账户余额（不计费）",
        "en": "Free self-test: validate key and show balance"
      },
      "parameters": []
    }
  ]
}*/
/// <reference path="./types/index.d.ts" />
const deepseekSearch = (function () {
    const SEARCH_URL = "https://api.deepseek.com/v1/tools/search";
    const FETCH_URL = "https://api.deepseek.com/v1/tools/fetch";
    const BALANCE_URL = "https://api.deepseek.com/user/balance";
    const CONFIG_PATH = "/sdcard/Download/Operit/deepseek/config.json";
    const NET_GUARD_MS = 60000;
    const BALANCE_GUARD_MS = 30000;
    const client = OkHttp.newBuilder()
        .connectTimeout(20000)
        .readTimeout(60000)
        .writeTimeout(20000)
        .build();
    function msgOf(e) {
        return e && e.message ? e.message : String(e);
    }
    function raceGuard(promise, ms, label) {
        return new Promise(function (resolve, reject) {
            let done = false;
            const timer = setTimeout(function () {
                if (!done) {
                    done = true;
                    reject(new Error("guard-timeout " + ms + "ms" + (label ? "（" + label + "）" : "")));
                }
            }, ms);
            promise.then(function (v) {
                if (!done) { done = true; clearTimeout(timer); resolve(v); }
            }, function (e) {
                if (!done) { done = true; clearTimeout(timer); reject(e); }
            });
        });
    }
    async function readText(path) {
        try {
            let r = await Tools.Files.read({ path: path, environment: "android" });
            if (typeof r === "string") return r;
            if (r && typeof r.content === "string") return r.content;
            if (r && r.data && typeof r.data.content === "string") return r.data.content;
        } catch (e1) {
            try {
                let r2 = await Tools.Files.read(path);
                if (typeof r2 === "string") return r2;
                if (r2 && typeof r2.content === "string") return r2.content;
                if (r2 && r2.data && typeof r2.data.content === "string") return r2.data.content;
            } catch (e2) { }
        }
        return "";
    }
    async function getApiKey(providedKey) {
        if (providedKey) return providedKey;
        try {
            const envKey = getEnv("DEEPSEEK_API_KEY");
            if (envKey) return envKey;
        } catch (e) { }
        try {
            const text = await readText(CONFIG_PATH);
            if (text) {
                const cfg = JSON.parse(text);
                if (cfg && typeof cfg.api_key === "string" && cfg.api_key) return cfg.api_key;
            }
        } catch (e2) { }
        return "";
    }
    function keyMissingError() {
        return new Error("未配置 DeepSeek API Key：请设置 DEEPSEEK_API_KEY 环境变量，或检查 " + CONFIG_PATH + " 的 api_key 字段，或在调用时传 api_key 参数");
    }
    function buildHttpError(status, content) {
        let detail = "";
        try {
            const j = JSON.parse(content);
            if (j && j.error && j.error.message) detail = j.error.message;
            else if (j && j.error) detail = JSON.stringify(j.error);
        } catch (e) {
            detail = content || "";
        }
        const tail = detail ? " —— " + detail : "";
        if (status === 400) return new Error("HTTP400：请求头或请求体非法" + tail);
        if (status === 401) return new Error("HTTP401：API Key 无效（先检查是否漏了 sk- 前缀）" + tail);
        if (status === 402) return new Error("HTTP402：账户余额不足，请先充值" + tail);
        if (status === 403) return new Error("HTTP403：Fetch 请求被安全策略拒绝" + tail);
        if (status === 404) return new Error("HTTP404：Fetch 取不到可用内容（URL 不可达/被站方拦/内容类型不支持）" + tail);
        if (status === 408) return new Error("HTTP408：读请求体超时，稍后重试" + tail);
        if (status === 413) return new Error("HTTP413：请求体过大" + tail);
        if (status === 429) return new Error("HTTP429：超过账号级 QPS 限制（Search/Fetch 各 5 QPS），稍后重试" + tail);
        if (status === 500) return new Error("HTTP500：服务端内部错误，稍后重试" + tail);
        if (status === 504) return new Error("HTTP504：下游请求超时，稍后重试" + tail);
        return new Error("HTTP " + status + "：" + (detail || "请求失败"));
    }
    async function viaToolsNet(url, method, headers, bodyText, guardMs) {
        const resp = await raceGuard(Tools.Net.http({
            url: url,
            method: method,
            headers: headers,
            body: bodyText,
            follow_redirects: true,
            connect_timeout: 15000,
            read_timeout: 60000,
            validateStatus: false
        }), guardMs, "Tools.Net");
        let text = "";
        const saved = resp ? (resp.content_saved_to || (resp.data && resp.data.content_saved_to) || resp.output_saved_to) : null;
        if (saved) {
            try { text = await readText(saved); } catch (e) { }
        }
        if (!text && resp) {
            if (typeof resp.content === "string") text = resp.content;
            else if (typeof resp.body === "string") text = resp.body;
            else if (typeof resp.text === "string") text = resp.text;
            else if (resp.data && typeof resp.data.content === "string") text = resp.data.content;
        }
        let status = null;
        if (resp) {
            if (resp.statusCode != null) status = resp.statusCode;
            else if (resp.status != null) status = resp.status;
            else if (resp.code != null) status = resp.code;
            else if (resp.data && resp.data.status != null) status = resp.data.status;
        }
        return { status: status, text: text, tier: "Tools.Net" };
    }
    async function request(method, url, headers, bodyObj, guardMs) {
        try {
            let req = client.newRequest().url(url).method(method).headers(headers);
            if (bodyObj != null) {
                req = req.body(JSON.stringify(bodyObj), "json");
            }
            const response = await raceGuard(req.build().execute(), guardMs, "OkHttp");
            let status = null;
            if (response) {
                if (response.statusCode != null) status = response.statusCode;
                else if (response.code != null) status = response.code;
            }
            const text = response && response.content != null ? String(response.content) : "";
            return { status: status, text: text, tier: "OkHttp" };
        } catch (okErr) {
            try {
                return await viaToolsNet(url, method, headers, bodyObj == null ? undefined : JSON.stringify(bodyObj), guardMs);
            } catch (netErr) {
                throw new Error("网络请求失败（OkHttp：" + msgOf(okErr) + "；Tools.Net：" + msgOf(netErr) + "）");
            }
        }
    }
    async function callJson(method, url, bodyObj, apiKey, guardMs) {
        const key = await getApiKey(apiKey || undefined);
        if (!key) throw keyMissingError();
        const r = await request(method, url, { "Authorization": "Bearer " + key, "Content-Type": "application/json" }, bodyObj, guardMs);
        if (r.status !== 200) throw buildHttpError(r.status, r.text);
        if (!r.text) throw new Error("HTTP " + r.status + " 但响应为空（tier=" + r.tier + "）");
        return JSON.parse(r.text);
    }
    function pickStr(v) {
        return typeof v === "string" ? v : "";
    }
    function normCount(v) {
        const n = typeof v === "number" ? v : parseInt(v, 10);
        if (!n || n < 1) return 10;
        return Math.min(50, n);
    }
    function normMaxChars(v) {
        const n = typeof v === "number" ? v : parseInt(v, 10);
        if (!n || n < 1000) return 30000;
        return Math.min(200000, n);
    }
    function mapResults(items) {
        if (!items || !Array.isArray(items)) return [];
        return items.map(function (item) {
            const r = {
                title: pickStr(item.title),
                url: pickStr(item.url),
                site_name: pickStr(item.site_name),
                date: item.date == null ? null : pickStr(item.date),
                authority: typeof item.authority === "number" ? item.authority : null,
                rerank_score: typeof item.rerank_score === "number" ? item.rerank_score : null,
                snippet: pickStr(item.snippet),
                summary: pickStr(item.summary)
            };
            if (typeof item.content === "string" && item.content) r.content = item.content;
            return r;
        });
    }
    async function doSearch(params) {
        if (!params.query) throw new Error("缺少 query 参数");
        const body = { query: params.query, count: normCount(params.count) };
        if (params.need_content === true) body.need_content = true;
        if (params.ori_question) body.ori_question = String(params.ori_question);
        if (params.localization) body.localization = String(params.localization);
        const result = await callJson("POST", SEARCH_URL, body, params.api_key, NET_GUARD_MS);
        const list = mapResults(result.results);
        return {
            success: true,
            query: params.query,
            count: list.length,
            charged: list.length > 0,
            results: list
        };
    }
    async function doFetch(params) {
        if (!params.url) throw new Error("缺少 url 参数");
        const result = await callJson("POST", FETCH_URL, { url: params.url }, params.api_key, NET_GUARD_MS);
        const md = pickStr(result.content);
        if (!md) throw new Error("未取到正文（页面不可访问或无可提取内容；此情况官方不计费）");
        const maxChars = normMaxChars(params.max_chars);
        let content = md;
        let truncated = false;
        if (content.length > maxChars) {
            content = content.slice(0, maxChars);
            truncated = true;
        }
        return {
            success: true,
            url: params.url,
            title: pickStr(result.title),
            length: md.length,
            truncated: truncated,
            markdown: content
        };
    }
    async function doBalanceCheck() {
        const key = await getApiKey(null);
        if (!key) throw keyMissingError();
        const r = await request("GET", BALANCE_URL, { "Authorization": "Bearer " + key }, null, BALANCE_GUARD_MS);
        if (r.status !== 200) throw buildHttpError(r.status, r.text);
        if (!r.text) throw new Error("余额接口空响应");
        const j = JSON.parse(r.text);
        const infos = j && Array.isArray(j.balance_infos) ? j.balance_infos : [];
        const first = infos.length > 0 ? infos[0] : {};
        return {
            success: true,
            is_available: j && j.is_available != null ? j.is_available : null,
            currency: pickStr(first.currency),
            total_balance: first.total_balance != null ? String(first.total_balance) : null,
            granted_balance: first.granted_balance != null ? String(first.granted_balance) : null,
            topped_up_balance: first.topped_up_balance != null ? String(first.topped_up_balance) : null,
            all_balances: infos
        };
    }
    async function searchWrapper(params) {
        try {
            const r = await doSearch(params || {});
            complete({
                success: true,
                message: "DeepSeek搜索完成：" + r.count + "条结果" + (r.count > 0 ? "（本次计费约 $0.00075）" : "（空结果不计费）"),
                data: r
            });
        } catch (error) {
            complete({ success: false, message: "搜索失败：" + msgOf(error), error_stack: error && error.stack ? error.stack : null });
        }
    }
    async function fetchWrapper(params) {
        try {
            const r = await doFetch(params || {});
            complete({
                success: true,
                message: "抓取完成：" + (r.title || r.url) + "（正文 " + r.length + " 字符" + (r.truncated ? "，已截断" : "") + "，计费约 $0.00075）",
                data: r
            });
        } catch (error) {
            complete({ success: false, message: "抓取失败：" + msgOf(error), error_stack: error && error.stack ? error.stack : null });
        }
    }
    async function testWrapper() {
        try {
            const r = await doBalanceCheck();
            complete({
                success: true,
                message: "连接正常。可用余额 " + (r.total_balance != null ? r.total_balance + " " + r.currency : "未知") + "（赠金 " + (r.granted_balance != null ? r.granted_balance : "?") + "，充值 " + (r.topped_up_balance != null ? r.topped_up_balance : "?") + "）",
                data: r
            });
        } catch (error) {
            complete({ success: false, message: "自检失败：" + msgOf(error), error_stack: error && error.stack ? error.stack : null });
        }
    }
    return {
        search: searchWrapper,
        fetch: fetchWrapper,
        test: testWrapper
    };
})();
exports.search = deepseekSearch.search;
exports.fetch = deepseekSearch.fetch;
exports.test = deepseekSearch.test;
