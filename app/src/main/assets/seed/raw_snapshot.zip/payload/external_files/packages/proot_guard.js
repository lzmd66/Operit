/* METADATA
{
  "name": "proot_guard",
  "description": "固定鸿蒙 proot 半好补丁：检测/重打 PROOT_NO_SECCOMP 到 setup_fake_sysdata.sh。用 Android shell，不依赖 Ubuntu 已启动。",
  "enabledByDefault": true,
  "tools": [
    {
      "name": "ensure_patch",
      "description": "若补丁丢失则重打；返回 already/repatched/error",
      "parameters": []
    },
    {
      "name": "status",
      "description": "查看补丁与关键环境变量状态",
      "parameters": []
    }
  ]
}
*/

const prootGuard = (function () {
  const FILES = "/data/user/0/com.ai.assistance.operit/files";
  const TARGET = FILES + "/setup_fake_sysdata.sh";
  const REPATCH = "/sdcard/Download/Operit/dev_package/proot_guard/repatch.sh";
  const MARKER = "operit_proot_env_begin";

  function extractOutput(r) {
    if (!r) return "";
    if (typeof r === "string") return r;
    if (r.output != null) return String(r.output);
    if (r.data != null) {
      if (typeof r.data === "string") return r.data;
      if (r.data.output != null) return String(r.data.output);
    }
    try {
      return JSON.stringify(r);
    } catch (e) {
      return String(r);
    }
  }

  // Prefer Android shell (works even when proot is dead). Fallbacks vary by host.
  async function androidShell(command) {
    // 1) Some hosts expose Tools.System.shell / exec
    try {
      if (Tools && Tools.System && typeof Tools.System.shell === "function") {
        const r = await Tools.System.shell(command);
        return { ok: true, output: extractOutput(r), via: "Tools.System.shell" };
      }
    } catch (e1) {}
    try {
      if (Tools && Tools.System && typeof Tools.System.exec === "function") {
        const r = await Tools.System.exec(command);
        return { ok: true, output: extractOutput(r), via: "Tools.System.exec" };
      }
    } catch (e2) {}
    // 2) toolCall into super_admin if available in runtime
    try {
      if (typeof toolCall === "function") {
        const r = await toolCall("super_admin", "shell", { command: command });
        return { ok: true, output: extractOutput(r), via: "toolCall super_admin:shell" };
      }
    } catch (e3) {}
    // 3) Last resort: Ubuntu hiddenExec (needs proot already healthy)
    try {
      if (Tools && Tools.System && Tools.System.terminal && typeof Tools.System.terminal.hiddenExec === "function") {
        const r = await Tools.System.terminal.hiddenExec(
          "cat " + REPATCH + " >/dev/null 2>&1; sh " + REPATCH,
          { executorKey: "proot_guard_executor", timeoutMs: 30000 }
        );
        return { ok: true, output: extractOutput(r), via: "hiddenExec" };
      }
    } catch (e4) {
      return { ok: false, output: String(e4 && e4.message ? e4.message : e4), via: "failed" };
    }
    return { ok: false, output: "no shell backend available", via: "none" };
  }

  async function ensure_patch() {
    const cmd = "sh " + REPATCH;
    const r = await androidShell(cmd);
    const out = (r.output || "").trim();
    return {
      success: r.ok && /ALREADY_PATCHED|REPATCHED/.test(out),
      via: r.via,
      result: out || r.output,
      hint: "若失败，请用 super_admin:shell 执行: sh " + REPATCH
    };
  }

  async function status() {
    const cmd =
      "echo MARKER=$(grep -c " +
      MARKER +
      " " +
      TARGET +
      " 2>/dev/null || echo 0); " +
      "echo HEAD; head -8 " +
      TARGET +
      " 2>/dev/null; " +
      "echo ENV_FILE_OK; ls -la " +
      TARGET +
      " 2>/dev/null";
    const r = await androidShell(cmd);
    return {
      via: r.via,
      output: r.output,
      target: TARGET,
      repatch_script: REPATCH
    };
  }

  async function main() {
    return await ensure_patch();
  }

  return {
    main: main,
    ensure_patch: ensure_patch,
    status: status
  };
})();

exports.main = prootGuard.main;
exports.ensure_patch = prootGuard.ensure_patch;
exports.status = prootGuard.status;