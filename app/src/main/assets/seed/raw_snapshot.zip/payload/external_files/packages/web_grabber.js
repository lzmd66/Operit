/*
METADATA
{
  "name": "web_grabber",
  "display_name": { "zh": "Web Grabber 日常抓取", "en": "Web Grabber" },
  "category": "Search",
  "description": {
    "zh": "日常抓取流水线。clean_search：Bing+DuckDuckGo 双引擎交叉搜索，带查询词相关性过滤（过滤词典/导航等垃圾结果）、去重与可信域加分。grab_page：抓取指定 URL，返回标题/描述/正文文本，并将页面表格提取为行数组（比纯文本更保结构）。内置 10 分钟 URL 缓存。",
    "en": "Daily scraping pipeline: cross-engine search with relevance filtering, and structured page extraction including tables."
  },
  "enabledByDefault": true,
  "tools": [
    {
      "name": "clean_search",
      "description": "双引擎交叉搜索（Bing + DuckDuckGo）。对结果做查询词相关性过滤，能挡住 Bing 偶发的词典/无关站点垃圾结果；两引擎都命中同一结果的排名加分。任一引擎失败不影响另一个。无 VPN 时 DDG 可能不可用，由 Bing 单独兜底。",
      "parameters": [
        { "name": "query", "description": "搜索关键词，尽量具体。", "type": "string", "required": true },
        { "name": "max_results", "description": "返回结果数，默认 8，范围 1~15。", "type": "number", "required": false }
      ]
    },
    {
      "name": "grab_page",
      "description": "抓取单个网页并做结构化提取：标题、meta 描述、正文纯文本（自动剔除 script/style/导航/页脚），表格提取为二维行数组。适合文档站、价格页、百科等表格型内容。默认 10 分钟缓存，force_refresh 可跳过。",
      "parameters": [
        { "name": "url", "description": "目标网页 URL，必须以 http:// 或 https:// 开头。", "type": "string", "required": true },
        { "name": "max_chars", "description": "正文文本最大返回字符数，默认 12000。", "type": "number", "required": false },
        { "name": "include_links", "description": "是否额外提取页面链接列表，默认 false。", "type": "boolean", "required": false },
        { "name": "include_tables", "description": "是否提取表格，默认 true。", "type": "boolean", "required": false },
        { "name": "force_refresh", "description": "跳过缓存强制刷新，默认 false。", "type": "boolean", "required": false }
      ]
    }
  ]
}
*/

const web_grabber = (function () {
  const UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";
  const HEADERS = {
    "User-Agent": UA,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8"
  };
  const FETCH_TIMEOUT_MS = 10000;
  const CACHE_TTL_MS = 10 * 60 * 1000;
  const cache = {};

  function asText(value) {
    return value === null || value === undefined ? "" : String(value);
  }

  function withTimeout(promise, timeoutMs, label) {
    return new Promise(function (resolve, reject) {
      const timer = setTimeout(function () {
        reject(new Error((label || "请求") + " 超时（" + timeoutMs + "ms）"));
      }, timeoutMs);
      Promise.resolve(promise).then(function (value) {
        clearTimeout(timer);
        resolve(value);
      }, function (error) {
        clearTimeout(timer);
        reject(error);
      });
    });
  }

  function createClient() {
    try {
      return OkHttp.newBuilder()
        .connectTimeout(5000)
        .readTimeout(FETCH_TIMEOUT_MS)
        .writeTimeout(5000)
        .followRedirects(true)
        .build();
    } catch (_) {
      return OkHttp.newClient();
    }
  }

  const http = createClient();

  async function fetchHtml(url, method, body) {
    let request = http.newRequest().url(url).method(method || "GET").headers(HEADERS);
    if (body) request = request.body(body, "form");
    const response = await withTimeout(request.build().execute(), FETCH_TIMEOUT_MS + 2000, url);
    const status = Number(response && response.statusCode) || 0;
    const content = asText(response && response.content);
    if (status && (status < 200 || status >= 400)) throw new Error("HTTP " + status);
    if (content.length < 100) throw new Error("响应内容过短");
    return content;
  }

  function decodeEntities(text) {
    return asText(text)
      .replace(/&amp;/gi, "&")
      .replace(/&lt;/gi, "<")
      .replace(/&gt;/gi, ">")
      .replace(new RegExp(String.fromCharCode(38) + "quot;", "gi"), '"')
      .replace(/&#39;|&#x27;/gi, "'")
      .replace(/&nbsp;/gi, " ")
      .replace(/&#(\d+);/g, function (_, code) {
        const number = Number(code);
        return number >= 32 && number <= 65535 ? String.fromCharCode(number) : " ";
      });
  }

  function stripTags(text) {
    return decodeEntities(asText(text).replace(/<[^>]+>/g, " "));
  }

  function squeeze(text) {
    return asText(text).replace(/[ \t\r\f]+/g, " ").trim();
  }

  function extractTables(html) {
    const tables = [];
    const tableRegex = /<table[\s\S]*?<\/table>/gi;
    let tableMatch;
    while ((tableMatch = tableRegex.exec(html)) !== null && tables.length < 15) {
      const rows = [];
      const rowRegex = /<tr[\s\S]*?<\/tr>/gi;
      let rowMatch;
      while ((rowMatch = rowRegex.exec(tableMatch[0])) !== null && rows.length < 120) {
        const cells = [];
        const cellRegex = /<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi;
        let cellMatch;
        while ((cellMatch = cellRegex.exec(rowMatch[0])) !== null && cells.length < 40) {
          const cell = squeeze(stripTags(cellMatch[1]));
          if (cell) cells.push(cell);
        }
        if (cells.length) rows.push(cells);
      }
      if (rows.length >= 2) tables.push(rows);
    }
    // 嵌套表格会被正则切成多块，去重：前3行相同的只保留第一个
    const seen = {};
    return tables.filter(function (rows) {
      const key = JSON.stringify(rows.slice(0, 3));
      if (seen[key]) return false;
      seen[key] = true;
      return true;
    });
  }

  function htmlToText(html) {
    let cleaned = asText(html)
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, " ")
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, " ")
      .replace(/<noscript[^>]*>[\s\S]*?<\/noscript>/gi, " ")
      .replace(/<svg[^>]*>[\s\S]*?<\/svg>/gi, " ")
      .replace(/<(nav|header|footer|aside|form)[^>]*>[\s\S]*?<\/\1>/gi, " ")
      .replace(/<!--[\s\S]*?-->/g, " ")
      .replace(/<br[^>]*>/gi, "\n")
      .replace(/<\/(p|div|li|tr|h[1-6]|section|article|td|th)>/gi, "\n")
      .replace(/<[^>]+>/g, " ");
    cleaned = decodeEntities(cleaned);
    const lines = cleaned.split(/\n+/).map(function (line) { return squeeze(line); }).filter(Boolean);
    return lines.join("\n");
  }

  function extractMeta(html) {
    const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
    const descMatch =
      html.match(/<meta[^>]+name=["']description["'][^>]*content=["']([^"']*)["']/i) ||
      html.match(/<meta[^>]+content=["']([^"']*)["'][^>]*name=["']description["']/i);
    return {
      title: squeeze(stripTags(titleMatch ? titleMatch[1] : "")),
      description: squeeze(stripTags(descMatch ? descMatch[1] : ""))
    };
  }

  function extractLinks(html, max) {
    const links = [];
    const seen = {};
    const regex = /<a[^>]+href=["']([^"'#]+)["'][^>]*>([\s\S]*?)<\/a>/gi;
    let match;
    while ((match = regex.exec(html)) !== null && links.length < max) {
      const href = decodeEntities(match[1]).trim();
      if (!/^https?:\/\//i.test(href)) continue;
      if (seen[href]) continue;
      seen[href] = true;
      links.push({ url: href, text: squeeze(stripTags(match[2])).slice(0, 150) });
    }
    return links;
  }

  async function grabPage(params) {
    const url = asText(params && params.url).trim();
    if (!/^https?:\/\//i.test(url)) {
      return { success: false, message: "URL 必须以 http:// 或 https:// 开头" };
    }
    const maxChars = Math.max(2000, Math.min(60000, Number(params && params.max_chars) || 12000));
    const includeLinks = !!(params && params.include_links);
    const includeTables = !(params && params.include_tables === false);
    const forceRefresh = !!(params && params.force_refresh);

    const cached = cache[url];
    if (!forceRefresh && cached && Date.now() - cached.t < CACHE_TTL_MS) {
      const hit = JSON.parse(JSON.stringify(cached.data));
      hit.from_cache = true;
      return hit;
    }

    try {
      let html = "";
      let fetchError = "";
      try {
        html = await fetchHtml(url);
      } catch (directError) {
        fetchError = asText(directError && directError.message ? directError.message : directError);
      }

      let meta = { title: "", description: "" };
      let tables = [];
      let text = "";
      let via = "http";
      if (html) {
        meta = extractMeta(html);
        let textSource = html;
        if (includeTables) {
          tables = extractTables(html);
          textSource = html.replace(/<table[\s\S]*?<\/table>/gi, " ");
        }
        text = htmlToText(textSource);
      }

      // 空壳检测：正文过短且无表格 → 疑似 JS 渲染页，走 Jina Reader 云端渲染兜底
      let jinaError = "";
      if (!html || (text.length < 400 && tables.length === 0)) {
        try {
          const markdown = await fetchHtml("https://r.jina.ai/" + url);
          if (markdown && markdown.length > text.length) {
            text = markdown;
            if (!meta.title) {
              const heading = markdown.match(/^#\s+(.+)$/m);
              meta.title = heading ? heading[1].trim() : url;
            }
            tables = [];
            via = "http+jina";
          }
        } catch (jinaCatch) {
          jinaError = asText(jinaCatch && jinaCatch.message ? jinaCatch.message : jinaCatch);
        }
      }

      if (!html && !text) {
        return { success: false, url: url, message: "HTTP 直接抓取失败（" + fetchError + "），Jina 兜底也不可用" };
      }

      const result = {
        success: true,
        url: url,
        via: via,
        title: meta.title,
        description: meta.description,
        table_count: tables.length,
        tables: tables,
        text_length: text.length,
        text: text.slice(0, maxChars)
      };
      if (includeLinks && html) result.links = extractLinks(html, 40);
      if (jinaError && via === "http") result.jina_error = jinaError;
      cache[url] = { t: Date.now(), data: JSON.parse(JSON.stringify(result)) };
      return result;
    } catch (error) {
      return { success: false, url: url, message: asText(error && error.message ? error.message : error) };
    }
  }

  // ---------- clean_search ----------

  function makeTokens(query) {
    const normalized = asText(query).toLowerCase().replace(/\s+/g, " ").trim();
    const tokens = [];
    normalized.split(/[^a-z0-9\u4e00-\u9fff]+/).forEach(function (part) {
      if (!part) return;
      if (/[\u4e00-\u9fff]/.test(part)) {
        if (part.length === 1) {
          tokens.push(part);
        } else {
          for (let i = 0; i + 2 <= part.length; i++) tokens.push(part.slice(i, i + 2));
        }
      } else if (part.length >= 2) {
        tokens.push(part);
      }
    });
    return tokens.filter(function (token, index) { return tokens.indexOf(token) === index; });
  }

  function relevanceHits(item, tokens) {
    const haystack = (item.title + " " + item.snippet).toLowerCase();
    let hits = 0;
    tokens.forEach(function (token) {
      if (haystack.indexOf(token) >= 0) hits++;
    });
    return hits;
  }

  function urlKey(url) {
    return asText(url)
      .replace(/^https?:\/\/(www\.)?/i, "")
      .replace(/[?#].*$/, "")
      .replace(/\/+$/, "")
      .toLowerCase();
  }

  function unwrapDdgRedirect(url) {
    const uddg = asText(url).match(/[?&]uddg=([^&]+)/i);
    if (uddg) {
      try { return decodeURIComponent(uddg[1]); } catch (_) {}
    }
    return url;
  }

  function pushResult(items, title, url, snippet, engine) {
    const finalUrl = unwrapDdgRedirect(decodeEntities(asText(url)).trim());
    const finalTitle = squeeze(stripTags(title));
    const finalSnippet = squeeze(stripTags(snippet || ""));
    if (!/^https?:\/\//i.test(finalUrl)) return;
    const host = (finalUrl.match(/^https?:\/\/([^\/?#:]+)/i) || [])[1];
    if (!host) return;
    const lowerHost = host.toLowerCase().replace(/^www\./, "");
    if (/(^|\.)bing\.com$/.test(lowerHost) || /(^|\.)duckduckgo\.com$/.test(lowerHost)) return;
    if (!finalTitle || finalTitle.length < 3) return;
    items.push({
      title: finalTitle.slice(0, 300),
      url: finalUrl,
      snippet: finalSnippet.slice(0, 400),
      engines: [engine],
      agreeBonus: false
    });
  }

  function parseBing(html) {
    const items = [];
    const blockRegex = /<li[^>]*class=["'][^"']*b_algo[^"']*["'][^>]*>([\s\S]*?)<\/li>/gi;
    let block;
    while ((block = blockRegex.exec(html)) !== null && items.length < 20) {
      const anchor = block[1].match(/<a[^>]+href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/i);
      if (!anchor) continue;
      const snippet = block[1].match(/<p[^>]*>([\s\S]*?)<\/p>/i);
      pushResult(items, anchor[2], anchor[1], snippet ? snippet[1] : "", "bing");
    }
    if (!items.length) {
      const looseRegex = /<h2[^>]*><a[^>]+href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a><\/h2>/gi;
      let loose;
      while ((loose = looseRegex.exec(html)) !== null && items.length < 15) {
        pushResult(items, loose[2], loose[1], "", "bing");
      }
    }
    return items;
  }

  function parseDdg(html) {
    const items = [];
    const regex = /<a[^>]*class=["'][^"']*result__a[^"']*["'][^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
    let match;
    while ((match = regex.exec(html)) !== null && items.length < 20) {
      const tail = html.slice(regex.lastIndex, regex.lastIndex + 1500);
      const snippet = tail.match(/class=["'][^"']*result__snippet[^"']*["'][^>]*>([\s\S]*?)<\/a>/i);
      pushResult(items, match[2], match[1], snippet ? snippet[1] : "", "duckduckgo");
    }
    return items;
  }

  function parseRss(xml) {
    const items = [];
    const itemRegex = /<item>([\s\S]*?)<\/item>/gi;
    let block;
    while ((block = itemRegex.exec(xml)) !== null && items.length < 20) {
      const value = block[1];
      const title = (value.match(/<title>([\s\S]*?)<\/title>/i) || [])[1] || "";
      const link = (value.match(/<link>([\s\S]*?)<\/link>/i) || [])[1] || "";
      const description = (value.match(/<description>([\s\S]*?)<\/description>/i) || [])[1] || "";
      pushResult(items, title, link, description, "bing_rss");
    }
    return items;
  }

  const TRUSTED = [
    "gov.cn", "edu.cn", "github.com", "arxiv.org", "wikipedia.org",
    "aliyun.com", "deepseek.com", "bigmodel.cn", "openai.com",
    "developer.mozilla.org", "docs.python.org", "learn.microsoft.com"
  ];

  function hostOf(url) {
    const match = asText(url).match(/^https?:\/\/([^\/?#:]+)/i);
    return match ? match[1].toLowerCase().replace(/^www\./, "") : "";
  }

  function isTrusted(url) {
    const host = hostOf(url);
    return TRUSTED.some(function (domain) {
      return host === domain || host.slice(-(domain.length + 1)) === "." + domain;
    });
  }

  function dedupeAndRank(raw, query, maxResults) {
    const tokens = makeTokens(query);
    const seen = {};
    const scored = [];
    raw.forEach(function (item) {
      const key = urlKey(item.url);
      if (seen[key]) {
        seen[key].agreeBonus = true;
        if (seen[key].engines.indexOf(item.engines[0]) < 0) seen[key].engines.push(item.engines[0]);
        return;
      }
      seen[key] = item;
      item.relevance = relevanceHits(item, tokens);
      item.trusted = isTrusted(item.url);
      scored.push(item);
    });

    const minHits = tokens.length >= 4
      ? Math.max(2, Math.ceil(tokens.length * 0.4))
      : (tokens.length >= 2 ? 2 : 1);
    const filtered = scored.filter(function (item) { return item.relevance >= minHits; });
    // 过滤后为空：单token查询保留原始结果，多token查询如实返回空，不回退塞垃圾
    const kept = filtered.length ? filtered : (tokens.length < 2 ? scored : []);
    kept.sort(function (left, right) {
      const ls = left.relevance * 10 + (left.trusted ? 6 : 0) + (left.agreeBonus ? 8 : 0);
      const rs = right.relevance * 10 + (right.trusted ? 6 : 0) + (right.agreeBonus ? 8 : 0);
      return rs - ls;
    });
    return kept.slice(0, maxResults);
  }

  function formatSearch(query, items, enginesUsed, failures) {
    const lines = ["clean_search：" + query];
    lines.push("引擎：" + (enginesUsed.length ? enginesUsed.join(" + ") : "无") +
      (failures.length ? " ｜ 失败：" + failures.join("；") : ""));
    lines.push("");
    if (!items.length) {
      lines.push("没有可用结果（或全部被相关性过滤）。可换更具体关键词，或用 various_search 交叉。");
      return lines.join("\n");
    }
    items.forEach(function (item, index) {
      lines.push("[" + (index + 1) + "] " + item.title);
      lines.push("URL: " + item.url);
      if (item.snippet) lines.push("摘要: " + item.snippet);
      lines.push("引擎: " + item.engines.join("+") + " | 相关词命中: " + item.relevance + (item.trusted ? " | 可信域" : ""));
      lines.push("");
    });
    return lines.join("\n");
  }

  async function cleanSearch(params) {
    const query = asText(params && params.query).trim();
    if (!query) return { platform: "clean_search", content: "搜索失败：关键词不能为空。" };
    const maxResults = Math.max(1, Math.min(15, Number(params && params.max_results) || 8));

    const results = await Promise.all([
      (async function () {
        try {
          const html = await fetchHtml("https://www.bing.com/search?q=" + encodeURIComponent(query) + "&setmkt=zh-CN");
          return { engine: "bing", items: parseBing(html), error: "" };
        } catch (error) {
          return { engine: "bing", items: [], error: asText(error && error.message ? error.message : error) };
        }
      })(),
      (async function () {
        try {
          const html = await fetchHtml("https://html.duckduckgo.com/html/", "POST", { q: query, b: "", kl: "cn-zh" });
          return { engine: "duckduckgo", items: parseDdg(html), error: "" };
        } catch (error) {
          return { engine: "duckduckgo", items: [], error: asText(error && error.message ? error.message : error) };
        }
      })()
    ]);

    const raw = [];
    const used = [];
    const failures = [];
    results.forEach(function (result) {
      if (result.items.length) {
        used.push(result.engine);
        Array.prototype.push.apply(raw, result.items);
      } else {
        failures.push(result.engine + (result.error ? "：" + result.error : "：无结果"));
      }
    });

    const ranked = dedupeAndRank(raw, query, maxResults);
    let finalEngines = used.slice(0);

    // Bing HTML 端点对非浏览器客户端会摘除有机结果，过滤后为空时补试 RSS 端点
    let finalRanked = ranked;
    if (!finalRanked.length) {
      try {
        const xml = await fetchHtml("https://www.bing.com/search?q=" + encodeURIComponent(query) + "&format=rss");
        const rssItems = parseRss(xml);
        if (rssItems.length) {
          const rssRanked = dedupeAndRank(rssItems, query, maxResults);
          if (rssRanked.length) {
            finalRanked = rssRanked;
            finalEngines.push("bing_rss");
          }
        }
      } catch (_) {}
    }

    return { platform: "clean_search", content: formatSearch(query, finalRanked, finalEngines, failures) };
  }

  return {
    grabPage: grabPage,
    cleanSearch: cleanSearch
  };
})();

exports.grab_page = function (params) {
  return web_grabber.grabPage(params);
};

exports.clean_search = function (params) {
  return web_grabber.cleanSearch(params);
};