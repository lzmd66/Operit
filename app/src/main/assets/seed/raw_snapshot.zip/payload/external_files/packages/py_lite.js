/* METADATA
{
  "name": "py_lite",
  "description": "鸿蒙半好方案：用系统 python3 跑脚本（不建 venv）。依赖 Operit Ubuntu 终端 + PROOT_NO_SECCOMP。",
  "enabledByDefault": true,
  "tools": [
    {
      "name": "run_python",
      "description": "用系统 python3 运行脚本字符串",
      "parameters": [
        { "name": "script", "description": "Python 代码", "type": "string", "required": true }
      ]
    },
    {
      "name": "run_python_file",
      "description": "用系统 python3 运行文件",
      "parameters": [
        { "name": "file_path", "description": "Python 文件路径", "type": "string", "required": true }
      ]
    },
    {
      "name": "run_cmd",
      "description": "在 Ubuntu 终端执行一条命令",
      "parameters": [
        { "name": "command", "description": "shell 命令", "type": "string", "required": true }
      ]
    }
  ]
}
*/

const pyLite = (function () {
  const EXEC_KEY = "py_lite_hidden_executor";

  async function sh(command, timeoutMs) {
    const options = { executorKey: EXEC_KEY };
    if (timeoutMs !== undefined) options.timeoutMs = timeoutMs;
    return await Tools.System.terminal.hiddenExec(command, options);
  }

  function esc(s) {
    return String(s).replace(/'/g, "'\\''");
  }

  async function run_python(params) {
    const script = params.script;
    if (!script || !String(script).trim()) {
      throw new Error("请提供 script");
    }
    const path = "/tmp/py_lite_script.py";
    // write then run; avoid complex heredoc edge cases
    const b64 = (typeof Buffer !== "undefined")
      ? Buffer.from(script, "utf8").toString("base64")
      : null;

    let writeCmd;
    if (b64) {
      writeCmd = "echo '" + b64 + "' | base64 -d > " + path;
    } else {
      // ES5 sandbox: manual base64-ish fallback via python itself is circular; use cat heredoc
      writeCmd = "cat > " + path + " <<'PY_LITE_EOF'\n" + script + "\nPY_LITE_EOF";
    }

    const w = await sh(writeCmd, 60000);
    if (w.exitCode !== 0 && w.exitCode !== undefined) {
      // still try run; some environments report exit oddly
    }
    const r = await sh("python3 " + path + "; ec=$?; rm -f " + path + "; exit $ec", 120000);
    if (r.exitCode !== 0 && r.exitCode !== undefined) {
      throw new Error("python 失败:\n" + (r.output || ""));
    }
    return (r.output || "").trim() || "(no output)";
  }

  async function run_python_file(params) {
    const filePath = params.file_path;
    if (!filePath || !String(filePath).trim()) {
      throw new Error("请提供 file_path");
    }
    const r = await sh("python3 '" + esc(filePath) + "'", 120000);
    if (r.exitCode !== 0 && r.exitCode !== undefined) {
      throw new Error("python 文件失败:\n" + (r.output || ""));
    }
    return (r.output || "").trim() || "(no output)";
  }

  async function run_cmd(params) {
    const command = params.command;
    if (!command || !String(command).trim()) {
      throw new Error("请提供 command");
    }
    const r = await sh(command, 120000);
    return {
      exitCode: r.exitCode,
      output: r.output || ""
    };
  }

  async function main() {
    const r = await run_python({ script: "print('py_lite_ok', 1+2)" });
    return "py_lite smoke: " + r;
  }

  return {
    main: main,
    run_python: run_python,
    run_python_file: run_python_file,
    run_cmd: run_cmd
  };
})();

exports.main = pyLite.main;
exports.run_python = pyLite.run_python;
exports.run_python_file = pyLite.run_python_file;
exports.run_cmd = pyLite.run_cmd;