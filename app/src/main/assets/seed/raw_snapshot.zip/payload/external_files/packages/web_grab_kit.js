/*
METADATA
{
    "name": "web_grab_kit",
    "description": "通用抓取工具包（应用进程内，不依赖 Ubuntu/proot）：http GET/POST（文本/JSON 自动解析）、可带自定义 headers/UA、HTML 转正文文本、页面抓取一站式。内置三层网络降级：Tools.Net.http → OkHttp → DoH 解析真 IP + IP 直连（绕 DNS 污染 / TLS 阻断），被墙或解析异常的域名自动兜底，返回带 tier 字段标明实际走通哪一层。反爬重活请配合 browser 工具链。",
    "tools": [
        {
            "name": "http_get",
            "description": "GET 请求，返回 status/body/tier；body 自动尝试 JSON 解析，as_json=false 强制文本。常规栈失败时自动降级 OkHttp，再降级 DoH+IP 直连。",
            "parameters": [
                { "name": "url", "description": "目标 URL", "type": "string", "required": true },
                { "name": "headers", "description": "自定义请求头，JSON 对象字符串或对象，键如 User-Agent，值如 Mozilla/5.0", "type": "string", "required": false },
                { "name": "as_json", "description": "是否尝试把 body 解析为 JSON，默认 true；失败则原样返回文本", "type": "boolean", "required": false },
                { "name": "timeout", "description": "读取超时毫秒，默认 45000", "type": "number", "required": false },
                { "name": "bypass", "description": "是否允许 DoH+IP 直连兜底，默认 true；设 false 可只走常规网络栈做对照", "type": "boolean", "required": false }
            ]
        },
        {
            "name": "http_post",
            "description": "POST 请求，body 支持 JSON 或表单/原文；返回结构同 http_get，同样带三层降级。",
            "parameters": [
                { "name": "url", "description": "目标 URL", "type": "string", "required": true },
                { "name": "body", "description": "请求体（字符串或对象，对象自动 JSON 序列化）", "type": "string", "required": false },
                { "name": "headers", "description": "自定义请求头", "type": "string", "required": false },
                { "name": "as_json", "description": "是否尝试解析响应 JSON，默认 true", "type": "boolean", "required": false },
                { "name": "timeout", "description": "读取超时毫秒，默认 45000", "type": "number", "required": false },
                { "name": "bypass", "description": "是否允许 DoH+IP 直连兜底，默认 true", "type": "boolean", "required": false }
            ]
        },
        {
            "name": "grab_page",
            "description": "抓网页并转成可读正文（去 script/style/标签），可选传 headers 绕 UA 拦截；同样带三层降级。",
            "parameters": [
                { "name": "url", "description": "目标 URL", "type": "string", "required": true },
                { "name": "headers", "description": "自定义请求头（建议带浏览器 UA）", "type": "string", "required": false },
                { "name": "max_chars", "description": "正文截断长度，默认 8000，最大 50000", "type": "number", "required": false },
                { "name": "bypass", "description": "是否允许 DoH+IP 直连兜底，默认 true", "type": "boolean", "required": false }
            ]
        },
        {
            "name": "extract_text",
            "description": "HTML 转正文（离线处理，不发请求）：去 script/style/注释/标签，压缩空白。",
            "parameters": [
                { "name": "html", "description": "HTML 原文", "type": "string", "required": true },
                { "name": "max_chars", "description": "截断长度，默认 8000，最大 100000", "type": "number", "required": false }
            ]
        },
        {
            "name": "doh_lookup",
            "description": "只用 DoH（加密 DNS）解析域名的真 IP，绕系统 DNS 污染。三源并行查询（阿里/腾讯/Google，各自独立守卫超时，绝不挂起），返回每源耗时与解析结果。排查「连不上」时的第一步。",
            "parameters": [
                { "name": "host", "description": "域名，如 store.steampowered.com", "type": "string", "required": true }
            ]
        },
        {
            "name": "net_diag",
            "description": "网络诊断：对同一 URL 依次实测三层（Tools.Net.http / OkHttp / DoH+IP 直连），返回每层的耗时、状态码、响应长度与片段，并对 https 域名附 DoH 解析结果。用来判定「到底哪一层能通、病在哪」。每层带自守卫超时，绝不无限挂起。",
            "parameters": [
                { "name": "url", "description": "要诊断的 URL，默认 https://store.steampowered.com/", "type": "string", "required": false },
                { "name": "timeout", "description": "每层读取超时毫秒，默认 10000", "type": "number", "required": false },
                { "name": "tiers", "description": "只测指定层，逗号分隔：doh / net / direct；默认全测。tiers 填 doh 时只解析 IP 不发起实测请求", "type": "string", "required": false }
            ]
        }
    ]
}
*/

// ===================== 常量 =====================
const PKG = "web_grab_kit";
const DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";

// DoH 端点：阿里 → 腾讯 → Google。三源并行查询，每源独立自守卫超时。
// Google 在无 VPN 时必然挂起（实测 >8s 无响应），由守卫切断，绝不阻塞整体；有 VPN 时正常贡献。
const DOH_ENDPOINTS = [
  { name: "alidns", url: "https://dns.alidns.com/resolve?name={host}&type=A" },
  { name: "tencent", url: "https://doh.pub/dns-query?name={host}&type=A" },
  { name: "google", url: "https://dns.google/resolve?name={host}&type=A" }
];
// 单源自守卫超时；拿到首个结果后再等 DOH_GRACE_MS 收集其余快源（阿里/腾讯实测约 0.2s）
const DOH_TIMEOUT_MS = 4000;
const DOH_GRACE_MS = 500;
// DoH+IP 直连时每个候选 IP 的自守卫超时
const IP_TRY_TIMEOUT_MS = 8000;
// 实测候选 IP 过多会把整体耗时拖到几分钟（同 bypass.py 的教训），只取前 N 个
const MAX_DOH_IPS = 3;

const CONNECT_TIMEOUT_MS = 6000; // 连接阶段快速失败封顶（6s）；读取阶段慢无妨，由 timeout 参数决定
const DEFAULT_TIMEOUT_MS = 45000;

// ===================== 基础 =====================
function ok(data, message) {
  const payload = { success: true, message: message || "ok", data: data };
  if (typeof complete === "function") complete(payload);
  return payload;
}

function fail(message, extra) {
  const payload = Object.assign({ success: false, message: String(message || "error") }, extra || {});
  if (typeof complete === "function") complete(payload);
  return payload;
}

function str(v) { return v == null ? "" : String(v); }

function msgOf(e) { return e && e.message ? e.message : String(e); }

function clamp(n, a, b) {
  n = Number(n);
  if (!isFinite(n)) return a;
  return Math.max(a, Math.min(b, n));
}

// 解析 headers 参数：接受对象或 JSON 字符串
function parseHeaders(h) {
  if (!h) return null;
  if (typeof h === "object") return h;
  try {
    const o = JSON.parse(str(h));
    return (o && typeof o === "object") ? o : null;
  } catch (e) {
    throw new Error("headers param must be a valid JSON object string");
  }
}

function mergeHeaders(a, b) {
  const out = {};
  const src = [a || {}, b || {}];
  for (let i = 0; i < src.length; i++) {
    for (const k in src[i]) {
      if (Object.prototype.hasOwnProperty.call(src[i], k)) out[k] = src[i][k];
    }
  }
  return out;
}

// 兼容各种响应形态，尽量拿到 body 文本与状态码
function normalizeResponse(resp, url) {
  if (resp == null) throw new Error("empty response from " + url);
  const saved =
    resp.content_saved_to ||
    (resp.data && resp.data.content_saved_to) ||
    resp.output_saved_to || "";
  let text = "";
  if (saved && Tools.Files && typeof Tools.Files.read === "function") {
    try {
      let r;
      try { r = Tools.Files.read(saved); } catch (e1) {
        r = Tools.Files.read({ path: saved, environment: "android" });
      }
      if (typeof r === "string") text = r;
      else if (r && typeof r.content === "string") text = r.content;
      else if (r && r.data && typeof r.data.content === "string") text = r.data.content;
    } catch (e) {}
  }
  if (!text) {
    if (typeof resp.content === "string") text = resp.content;
    else if (typeof resp.body === "string") text = resp.body;
    else if (typeof resp.text === "string") text = resp.text;
    else if (typeof resp === "string") text = resp;
    else if (resp.data && typeof resp.data.content === "string") text = resp.data.content;
  }
  const status =
    (resp.statusCode != null ? resp.statusCode : null) ||
    (resp.status != null ? resp.status : null) ||
    (resp.code != null ? resp.code : null) ||
    (resp.data && resp.data.status != null ? resp.data.status : null) ||
    null;
  return { text: str(text), status: status, saved: saved || null };
}

function tryParseJsonText(text) {
  if (!text) return null;
  try { return JSON.parse(text); } catch (e) {}
  const m = String(text).match(/\{[\s\S]*\}|\[[\s\S]*\]/);
  if (m) { try { return JSON.parse(m[0]); } catch (e2) {} }
  return null;
}

// ===================== 第 3 层：DoH + IP 直连 =====================
/** 给任意 Promise 加自守卫超时：到点即以 Error 拒绝，防止宿主层 timeout 参数不生效导致无限挂起。 */
function raceGuard(promise, ms, label) {
  return new Promise(function (resolve, reject) {
    let done = false;
    const timer = setTimeout(function () {
      if (!done) { done = true; reject(new Error("guard-timeout " + ms + "ms" + (label ? "（" + label + "）" : ""))); }
    }, ms);
    promise.then(function (v) {
      if (!done) { done = true; clearTimeout(timer); resolve(v); }
    }, function (e) {
      if (!done) { done = true; clearTimeout(timer); reject(e); }
    });
  });
}

/**
 * 查询单个 DoH 源（带自守卫超时，绝不无限挂起）。
 * 返回 { name, ok, ms, status?, ips?, err? }。
 */
function queryDohSource(source, host, timeoutMs) {
  const started = Date.now();
  const url = source.url.replace("{host}", encodeURIComponent(host));
  return raceGuard(Tools.Net.http({
    url: url,
    method: "GET",
    headers: { "User-Agent": DEFAULT_UA, "Accept": "application/dns-json, application/json, */*" },
    connect_timeout: timeoutMs,
    read_timeout: timeoutMs,
    responseType: "text",
    validateStatus: false
  }), timeoutMs + 300, source.name).then(function (resp) {
    const ms = Date.now() - started;
    const text = resp && resp.content !== undefined ? resp.content : (resp ? resp.body : null);
    if (!text) return { name: source.name, ok: false, ms: ms, err: "空响应" };
    let data;
    try { data = JSON.parse(String(text)); } catch (e2) {
      return { name: source.name, ok: false, ms: ms, err: "非 JSON 响应" };
    }
    const answers = (data && data.Answer) || [];
    const ips = [];
    for (let j = 0; j < answers.length; j++) {
      const a = answers[j];
      if (a && a.type === 1 && a.data) ips.push(String(a.data));
    }
    const status = resp && (resp.statusCode !== undefined ? resp.statusCode : resp.status);
    return { name: source.name, ok: true, ms: ms, status: status == null ? null : status, ips: ips };
  }, function (e) {
    return { name: source.name, ok: false, ms: Date.now() - started, err: msgOf(e) };
  });
}

/**
 * 用 DoH（加密 DNS）并行解析域名的真 IP，绕过系统 DNS 污染。
 * 三源并行（阿里 / 腾讯 / Google），每源独立自守卫超时；
 * 拿到首个结果后再等 DOH_GRACE_MS 收集其余快源，立即返回，绝不等慢源 / 死源。
 * 返回 { ips: [...], sources: [...], ms }。
 */
async function dohResolve(host, opts) {
  opts = opts || {};
  const timeoutMs = clamp(opts.timeout || DOH_TIMEOUT_MS, 800, 15000);
  const sources = DOH_ENDPOINTS;
  const started = Date.now();
  const details = [];
  for (let i = 0; i < sources.length; i++) details.push({ name: sources[i].name, status: "pending" });

  let gotAny = false;
  let overall = null;
  const collected = await new Promise(function (resolve) {
    let pending = sources.length;
    let graceTimer = null;
    let finished = false;
    function finish(why) {
      if (finished) return;
      finished = true;
      if (graceTimer) clearTimeout(graceTimer);
      if (overall) clearTimeout(overall);
      const snap = [];
      for (let k = 0; k < details.length; k++) {
        const d = details[k];
        if (d.status === "pending") snap.push(Object.assign({}, d, { status: "skipped(" + why + ")" }));
        else snap.push(Object.assign({}, d));
      }
      resolve(snap);
    }
    overall = setTimeout(function () { finish("overall-cap"); }, timeoutMs + 800);
    sources.forEach(function (source, idx) {
      queryDohSource(source, host, timeoutMs).then(function (r) {
        if (finished) return;
        details[idx] = Object.assign({}, r, { status: "done" });
        if (r.ok && r.ips && r.ips.length > 0) gotAny = true;
        pending--;
        if (gotAny && !graceTimer) {
          graceTimer = setTimeout(function () { finish("first+grace"); }, DOH_GRACE_MS);
        }
        if (pending === 0) {
          clearTimeout(overall);
          finish("all-settled");
        }
      });
    });
  });

  const ips = [];
  const seen = {};
  for (let i = 0; i < collected.length; i++) {
    const srcIps = (collected[i] && collected[i].ips) || [];
    for (let j = 0; j < srcIps.length; j++) {
      if (!seen[srcIps[j]]) { seen[srcIps[j]] = 1; ips.push(srcIps[j]); }
    }
  }
  return { ips: ips, sources: collected, ms: Date.now() - started };
}

/** 只支持 https 的单层 URL 拆解（DoH+IP 直连只对 https 有意义） */
function splitHttpsUrl(rawUrl) {
  const m = String(rawUrl).match(/^https:[/]{2}([^/?#]+)([/?#].*)?$/);
  if (!m) return null;
  const rest = m[2] ? m[2].replace(/^[/]/, "") : "";
  return { host: m[1], path: rest ? "/" + rest : "/" };
}

/** 粗略判断 body 类型，供内置 http_request 的 body_type 用 */
function guessBodyType(body) {
  const s = str(body).replace(/^\s+/, "");
  if (s.charAt(0) === "{" || s.charAt(0) === "[") return "json";
  return "text";
}

/**
 * 第 3 层兜底：DoH 拿真 IP → 经内置 http_request 直连该 IP（ignore_ssl + Host 头写域名）。
 * 多 IP 逐个尝试，任一成功即返回；每个 IP 带自守卫超时（防黑洞 IP 无响应挂死）。
 * preIps：可选的已解析 IP 列表（net_diag 复用，避免重复 DoH）。
 *
 * 注意：POST 走这条链路是本次新增、尚未实测的分支，失败会自动回到前两层。
 */
async function requestViaDoh(url, method, headers, body, preIps) {
  if (typeof toolCall !== "function") {
    throw new Error("当前沙盒不支持 toolCall，无法使用 DoH 直连兜底");
  }
  const parts = splitHttpsUrl(url);
  if (!parts) throw new Error("DoH 兜底仅支持 https URL");

  let ips = Array.isArray(preIps) ? preIps : null;
  if (!ips || !ips.length) {
    const rr = await dohResolve(parts.host);
    ips = rr.ips;
  }
  if (!ips.length) throw new Error("DoH 解析 " + parts.host + " 未获得可用 IP");

  const tryList = ips.slice(0, MAX_DOH_IPS);
  const hdrs = mergeHeaders(headers, { "Host": parts.host });
  const useMethod = str(method || "GET").toUpperCase();
  let lastMsg = "";

  for (let i = 0; i < tryList.length; i++) {
    const ip = tryList[i];
    try {
      const toolParams = {
        url: "https://" + ip + parts.path,
        method: useMethod,
        headers: JSON.stringify(hdrs),
        ignore_ssl: true
      };
      if (useMethod !== "GET" && body != null && body !== "") {
        toolParams.body = str(body);
        toolParams.body_type = guessBodyType(body);
      }
      const resp = await raceGuard(toolCall({ name: "http_request", params: toolParams }), IP_TRY_TIMEOUT_MS, "IP " + ip);
      const status = resp && (resp.statusCode !== undefined ? resp.statusCode : resp.status);
      const text = resp && (resp.content !== undefined ? resp.content : resp.body);
      if (status === null || status === undefined) {
        lastMsg = "IP " + ip + " 未返回状态码";
        continue;
      }
      console.log("[" + PKG + "] DoH 直连成功（IP " + ip + "，HTTP " + status + "）");
      return { status: status, text: text == null ? "" : String(text), saved: null, ip: ip };
    } catch (e) {
      lastMsg = "IP " + ip + " 失败: " + msgOf(e);
      console.log("[" + PKG + "] " + lastMsg);
    }
  }
  throw new Error("DoH 直连全部失败：" + lastMsg);
}

// ===================== 第 1 层：Tools.Net.http =====================
async function requestViaToolsHttp(url, method, headers, body, timeout) {
  const resp = await Tools.Net.http({
    url: url,
    method: method,
    headers: headers,
    body: body,
    follow_redirects: true,
    connect_timeout: CONNECT_TIMEOUT_MS,
    read_timeout: timeout,
    validateStatus: false
  });
  const n = normalizeResponse(resp, url);
  return { status: n.status, text: n.text, saved: n.saved };
}

// ===================== 第 2 层：OkHttp =====================
async function requestViaOkHttp(url, method, headers, body, timeout) {
  const client = OkHttp.newBuilder()
    .connectTimeout(CONNECT_TIMEOUT_MS)
    .readTimeout(timeout)
    .writeTimeout(timeout)
    .retryOnConnectionFailure(true)
    .build();
  const useMethod = str(method || "GET").toUpperCase();
  const req = client.newRequest().url(url).method(useMethod).headers(headers);
  if (useMethod !== "GET" && body != null && body !== "") {
    req.body(str(body), guessBodyType(body) === "json" ? "json" : "text");
  }
  const response = await req.build().execute();
  const status = response ? response.statusCode : null;
  const text = response && response.content !== undefined ? response.content : "";
  return { status: status, text: text == null ? "" : String(text), saved: null };
}

// ===================== 三层调度 =====================
function buildTiers(url, method, headers, body, timeout, bypass) {
  const tiers = [];
  tiers.push({
    name: "Tools.Net.http",
    run: function () { return requestViaToolsHttp(url, method, headers, body, timeout); }
  });
  tiers.push({
    name: "OkHttp",
    run: function () { return requestViaOkHttp(url, method, headers, body, timeout); }
  });
  if (bypass !== false) {
    tiers.push({
      name: "DoH+IP直连",
      run: function () { return requestViaDoh(url, method, headers, body, timeout); }
    });
  }
  return tiers;
}

/**
 * 依次尝试各层。任何一层拿到非空响应即返回。
 * 若某层返回空 body，视为可疑（CDN 边缘静默空返回），继续试下一层；
 * 全部为空时返回第一个结果。
 */
async function requestRaw(url, method, headers, body, timeout, bypass) {
  const tiers = buildTiers(url, method, headers, body, timeout, bypass);
  const tried = [];
  let first = null;

  for (let i = 0; i < tiers.length; i++) {
    try {
      const guardMs = (i === 0) ? Math.min(timeout + 3000, 8000) : (timeout + 3000);
      const r = await raceGuard(tiers[i].run(), guardMs, tiers[i].name);
      tried.push(tiers[i].name + ": HTTP " + r.status + " / " + r.text.length + "b");
      if (first == null) first = r;
      if (r.text && r.text.length > 0) {
        r.tier = tiers[i].name;
        r.tried = tried;
        return r;
      }
      console.log("[" + PKG + "] " + tiers[i].name + " 返回空响应，尝试下一层");
    } catch (e) {
      tried.push(tiers[i].name + ": " + msgOf(e));
      console.log("[" + PKG + "] " + tiers[i].name + " 失败: " + msgOf(e));
    }
  }

  if (first) {
    first.tier = "（各层均返回空响应）";
    first.tried = tried;
    return first;
  }
  const err = new Error("三层网络栈均失败：" + tried.join(" ｜ "));
  err.tried = tried;
  throw err;
}

// ===================== HTML -> 正文 =====================
function htmlToText(html) {
  let s = str(html);
  s = s.replace(/<script[\s\S]*?<\/script>/gi, " ")
       .replace(/<style[\s\S]*?<\/style>/gi, " ")
       .replace(/<!--[\s\S]*?-->/g, " ")
       .replace(/<noscript[\s\S]*?<\/noscript>/gi, " ")
       .replace(/<br\s*\/?>/gi, "\n")
       .replace(/<\/(p|div|li|h[1-6]|tr)>/gi, "\n")
       .replace(/<[^>]+>/g, " ");
  const ents = { "&nbsp;": " ", "&amp;": "&", "&lt;": "<", "&gt;": ">", ["&quot;"]: String.fromCharCode(34), "&#39;": String.fromCharCode(39), "&yen;": String.fromCharCode(165) };
  s = s.replace(/&[a-z#0-9]+;/gi, function (m) { return ents[m] || m; });
  s = s.replace(/[ \t\u00a0]+/g, " ").replace(/\n\s*\n+/g, "\n").trim();
  return s;
}

// ===================== 请求包装 =====================
async function doRequest(url, method, headers, body, asJson, timeout, bypass) {
  const hdrs = parseHeaders(headers) || {
    "User-Agent": DEFAULT_UA,
    "Accept": "text/html,application/json,text/plain,*/*",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8"
  };
  if (!hdrs["User-Agent"]) hdrs["User-Agent"] = DEFAULT_UA;
  const t = clamp(timeout || DEFAULT_TIMEOUT_MS, 3000, 120000);
  const r = await requestRaw(url, method, hdrs, body, t, bypass);
  const out = {
    url: url,
    status: r.status,
    body_length: r.text.length,
    body: r.text,
    tier: r.tier,
    tried: r.tried
  };
  if (r.saved) out.saved_to = r.saved;
  if (r.ip) out.via_ip = r.ip;
  if (asJson !== false) {
    const j = tryParseJsonText(r.text);
    if (j !== null) {
      out.json = j;
      out.body_preview = str(r.text).substring(0, 300);
      delete out.body; // JSON 模式不重复携带大文本
    }
  }
  return out;
}

// ===================== 工具 =====================
async function http_get(params) {
  try {
    const url = str(params && params.url).trim();
    if (!url) return fail("url 不能为空");
    const data = await doRequest(url, "GET", params && params.headers, undefined, params && params.as_json, params && params.timeout, params && params.bypass);
    return ok(data, "GET 完成" + (data.tier ? "（" + data.tier + "）" : ""));
  } catch (e) {
    return fail(msgOf(e));
  }
}

async function http_post(params) {
  try {
    const url = str(params && params.url).trim();
    if (!url) return fail("url 不能为空");
    let body = params && params.body;
    let headers = params && params.headers;
    if (body && typeof body !== "string") {
      body = JSON.stringify(body);
      const h = parseHeaders(headers) || {};
      if (!h["Content-Type"]) {
        h["Content-Type"] = "application/json";
        headers = JSON.stringify(h);
      }
    }
    const data = await doRequest(url, "POST", headers, body, params && params.as_json, params && params.timeout, params && params.bypass);
    return ok(data, "POST 完成" + (data.tier ? "（" + data.tier + "）" : ""));
  } catch (e) {
    return fail(msgOf(e));
  }
}

async function grab_page(params) {
  try {
    const url = str(params && params.url).trim();
    if (!url) return fail("url 不能为空");
    const maxChars = clamp((params && params.max_chars) || 8000, 200, 50000);
    const r = await doRequest(url, "GET", params && params.headers, undefined, false, params && params.timeout, params && params.bypass);
    const text = htmlToText(r.body);
    return ok({
      url: url,
      status: r.status,
      tier: r.tier,
      tried: r.tried,
      html_length: r.body_length,
      text_length: text.length,
      text: text.substring(0, maxChars)
    }, "页面抓取完成" + (r.tier ? "（" + r.tier + "）" : ""));
  } catch (e) {
    return fail(msgOf(e));
  }
}

async function extract_text(params) {
  try {
    const html = str(params && params.html);
    if (!html) return fail("html 不能为空");
    const maxChars = clamp((params && params.max_chars) || 8000, 100, 100000);
    const text = htmlToText(html);
    return ok({ text_length: text.length, text: text.substring(0, maxChars) }, "提取完成");
  } catch (e) {
    return fail(msgOf(e));
  }
}

async function doh_lookup(params) {
  try {
    const host = str(params && params.host).trim();
    if (!host) return fail("host 不能为空");
    const rr = await dohResolve(host);
    const brief = [];
    for (let i = 0; i < rr.sources.length; i++) {
      const s2 = rr.sources[i];
      brief.push(s2.name + "=" + (s2.ok ? ((s2.ips ? s2.ips.length : 0) + "个IP/" + s2.ms + "ms") : ("失败:" + (s2.err || s2.status))));
    }
    return ok({
      host: host,
      ms: rr.ms,
      ip_count: rr.ips.length,
      ips: rr.ips,
      sources: rr.sources,
      detail: brief.join("；"),
      conclusion: rr.ips.length > 0 ? "DoH 解析成功" : "DoH 解析失败（全部端点均无结果，检查网络或换域名）"
    }, rr.ips.length > 0 ? "DoH 解析完成" : "DoH 解析失败");
  } catch (e) {
    return fail(msgOf(e));
  }
}

async function net_diag(params) {
  try {
    const url = str(params && params.url).trim() || "https://store.steampowered.com/";
    const t = clamp((params && params.timeout) || 10000, 3000, 30000);
    const pick = str(params && params.tiers).trim().toLowerCase();
    const wantDoh = !pick || pick.indexOf("doh") >= 0;
    const wantNet = !pick || pick.indexOf("net") >= 0;
    const wantDirect = !pick || pick.indexOf("direct") >= 0 || pick.indexOf("ip") >= 0;
    const headers = { "User-Agent": DEFAULT_UA, "Accept": "*/*", "Accept-Language": "zh-CN,zh;q=0.9" };
    const result = { url: url, tiers: pick || "all", steps: [] };
    let preIps = [];

    const parts = splitHttpsUrl(url);
    if (wantDoh && parts) {
      try {
        const t0 = Date.now();
        const rr = await dohResolve(parts.host);
        preIps = rr.ips;
        result.steps.push({
          step: "DoH 解析（" + parts.host + "）",
          ok: rr.ips.length > 0,
          ms: Date.now() - t0,
          ip_count: rr.ips.length,
          ips: rr.ips,
          sources: rr.sources
        });
      } catch (e) {
        result.steps.push({ step: "DoH 解析（" + parts.host + "）", ok: false, error: msgOf(e) });
      }
    }

    const tiers = [];
    if (wantNet) {
      tiers.push({ name: "Tools.Net.http", run: function () { return raceGuard(requestViaToolsHttp(url, "GET", headers, undefined, t), t + 3000, "Tools.Net.http"); } });
      tiers.push({ name: "OkHttp", run: function () { return raceGuard(requestViaOkHttp(url, "GET", headers, undefined, t), t + 3000, "OkHttp"); } });
    }
    if (wantDirect) {
      tiers.push({ name: "DoH+IP直连", run: function () { return requestViaDoh(url, "GET", headers, undefined, preIps); } });
    }

    for (let i = 0; i < tiers.length; i++) {
      const started = Date.now();
      try {
        const r = await tiers[i].run();
        result.steps.push({
          step: tiers[i].name,
          ok: r.status !== null && r.status !== undefined && r.text.length > 0,
          ms: Date.now() - started,
          status: r.status,
          bytes: r.text.length,
          via_ip: r.ip || null,
          preview: r.text ? r.text.slice(0, 150) : null
        });
      } catch (e) {
        result.steps.push({
          step: tiers[i].name,
          ok: false,
          ms: Date.now() - started,
          error: msgOf(e)
        });
      }
    }

    const okTiers = [];
    for (let i = 0; i < result.steps.length; i++) {
      if (result.steps[i].ok) okTiers.push(result.steps[i].step);
    }
    result.conclusion = okTiers.length > 0
      ? "可用层：" + okTiers.join(" / ")
      : "本次诊断步骤全部失败，可能网络中断或域名被整体阻断";
    return ok(result, "网络诊断完成");
  } catch (e) {
    return fail(msgOf(e));
  }
}

// ===================== 导出 =====================
exports.http_get = http_get;
exports.http_post = http_post;
exports.grab_page = grab_page;
exports.extract_text = extract_text;
exports.doh_lookup = doh_lookup;
exports.net_diag = net_diag;