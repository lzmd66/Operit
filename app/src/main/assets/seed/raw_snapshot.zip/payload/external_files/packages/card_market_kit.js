/*
METADATA
{
    "name": "card_market_kit",
    "display_name": {
        "zh": "卡带行情",
        "en": "Card Market"
    },
    "description": {
        "zh": "查实体游戏卡带/光盘的行情（回收价 / 二手成交区间 / 新卡好价 三档 + 涨跌方向）。数据来自什么值得买(smzdm) 的行情文章，其内容聚合自小红书/B站/微博的实时交易帖。基于应用内浏览器渲染，单次约 10-15 秒。",
        "en": "Query physical game cartridge/disc market prices from smzdm market articles."
    },
    "category": "Game",
    "tools": [
        {
            "name": "card_market",
            "description": {
                "zh": "查询实体卡带/光盘行情文章列表（标题 + 摘要 + 链接）。返回内容含回收价、二手成交区间、新卡好价与涨跌分析。默认关键词「switch卡带行情」，可自定义（如「ps5光盘行情」「卡带回收价」）。",
                "en": "Search smzdm articles about physical game market prices."
            },
            "parameters": [
                {
                    "name": "keyword",
                    "description": { "zh": "关键词，默认「switch卡带行情」。", "en": "Keyword, default 'switch卡带行情'." },
                    "type": "string",
                    "required": false
                },
                {
                    "name": "limit",
                    "description": { "zh": "返回条数，默认 10，最多 15。", "en": "Max items, default 10." },
                    "type": "number",
                    "required": false
                }
            ]
        }
    ]
}*/

const card_market_kit = (function () {

    // smzdm 搜索页有 WAF（probe.js 挑战），必须用应用内浏览器渲染
    function extractResult(raw) {
        const text = String(raw);
        const marker = "### Result";
        const idx = text.lastIndexOf(marker);
        if (idx < 0) {
            throw new Error("浏览器返回中未找到 ### Result 段（页面可能未渲染完成）。");
        }
        let body = text.slice(idx + marker.length).trim();
        const nl = body.indexOf("\n### ");
        if (nl >= 0) {
            body = body.slice(0, nl).trim();
        }
        try {
            return JSON.parse(body);
        }
        catch (e) {
            throw new Error("浏览器返回的结果不是合法 JSON。片段: " + body.slice(0, 200));
        }
    }

    const EXTRACT = "() => { const seen = new Set(); const items = []; document.querySelectorAll('a[href*=\"post.smzdm.com/p/\"]').forEach(a => { const t = (a.innerText || '').replace(/\\s+/g, ' ').trim(); if (!t || t.length < 8 || t.length > 90) return; let href = a.getAttribute('href') || ''; if (href.indexOf('//') === 0) href = 'https:' + href; href = href.split('?')[0]; if (seen.has(href)) return; seen.add(href); let summary = ''; let p = a.parentElement; for (let i = 0; i < 4 && p; i++) { const txt = (p.innerText || '').replace(/\\s+/g, ' ').trim(); if (txt.length > t.length + 40) { summary = txt.replace(t, '').trim().slice(0, 220); break; } p = p.parentElement; } items.push({ title: t, url: href, summary: summary }); }); return JSON.stringify({ count: items.length, items: items.slice(0, 20) }); }";

    async function card_market(params) {
        const keyword = params && params.keyword ? String(params.keyword).trim() : "switch卡带行情";
        let limit = params && params.limit ? parseInt(String(params.limit), 10) : 10;
        if (!limit || limit < 1) {
            limit = 10;
        }
        if (limit > 15) {
            limit = 15;
        }
        const url = "https://search.smzdm.com/?c=home&s=" + encodeURIComponent(keyword) + "&v=b";
        await Tools.Net.browserNavigate(url);
        await Tools.Net.browserWaitFor({ time: 6 });
        let data = extractResult(await Tools.Net.browserEvaluate({ function: EXTRACT }));
        if (!data || !data.count) {
            // WAF 挑战或渲染未完成：再等 5 秒重试一次
            await Tools.Net.browserWaitFor({ time: 5 });
            const retry = extractResult(await Tools.Net.browserEvaluate({ function: EXTRACT }));
            if (retry && retry.count) {
                data = retry;
            }
        }
        const items = (data.items || []).slice(0, limit);
        return {
            source: "什么值得买（smzdm）行情文章；数据源自小红书/B站/微博交易帖",
            keyword: keyword,
            count: items.length,
            note: "回收价=商家收购价（卖卡底价）；二手成交=玩家间成交；好价=电商券后价",
            items: items
        };
    }

    async function wrap(label, func, params) {
        try {
            console.log("[card_market_kit] 开始: " + label);
            const r = await func(params || {});
            complete({ success: true, message: label + " 完成", data: r });
        }
        catch (error) {
            const msg = error && error.message ? error.message : String(error);
            complete({ success: false, message: label + " 失败: " + msg });
        }
    }

    return {
        card_market: function (params) { return wrap("卡带行情查询", card_market, params); }
    };
})();

exports.card_market = card_market_kit.card_market;