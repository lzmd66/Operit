/*
METADATA
{
    "name": "js_tools",
    "description": "纯 JS 技能包（零虚拟机依赖）：文件批量重命名等实用工具，全部基于 Operit 内置 Tools API 进程内运行，稳定可靠。",
    "enabledByDefault": true,
    "tools": [
        {
            "name": "rename_files",
            "description": "批量重命名文件（正则替换文件名）。默认 dry_run 预览模式，确认无误后再实际执行。纯 JS 实现，不依赖终端。",
            "parameters": [
                { "name": "directory", "description": "目标目录", "type": "string", "required": true },
                { "name": "pattern", "description": "匹配文件名的正则表达式", "type": "string", "required": true },
                { "name": "replacement", "description": "替换字符串（JS 风格，用 $1 反向引用）", "type": "string", "required": false },
                { "name": "dry_run", "description": "预览模式，默认 true（只显示将如何改名，不实际执行）", "type": "boolean", "required": false },
                { "name": "recursive", "description": "是否递归子目录，默认 false", "type": "boolean", "required": false }
            ]
        }
    ]
}
*/

const jsTools = (function () {
  function entryName(item) {
    if (!item) return "";
    if (typeof item === "string") return item;
    return item.name || item.fileName || item.filename || item.path || "";
  }

  function entryIsDir(item) {
    if (!item || typeof item === "string") return false;
    if (typeof item.isDirectory === "boolean") return item.isDirectory;
    if (typeof item.isDir === "boolean") return item.isDir;
    if (item.type === "directory" || item.type === "dir") return true;
    return false;
  }

  async function listDir(path) {
    try {
      var r = await Tools.Files.list(path, "android");
      if (Array.isArray(r)) return r;
      if (r && Array.isArray(r.entries)) return r.entries;
      if (r && Array.isArray(r.files)) return r.files;
      if (r && r.data && Array.isArray(r.data.entries)) return r.data.entries;
      if (r && r.data && Array.isArray(r.data.files)) return r.data.files;
    } catch (e) {}
    try {
      var r2 = await Tools.Files.list(path);
      if (Array.isArray(r2)) return r2;
      if (r2 && Array.isArray(r2.entries)) return r2.entries;
      if (r2 && Array.isArray(r2.files)) return r2.files;
    } catch (e2) {}
    return [];
  }

  // move 多签名兼容
  async function safeMove(from, to) {
    var attempts = [
      function () { return Tools.Files.move(from, to, "android"); },
      function () { return Tools.Files.move(from, to); },
      function () { return Tools.Files.move({ from: from, to: to }, "android"); },
      function () { return Tools.Files.move({ from: from, to: to }); },
      function () { return Tools.Files.move({ path: from, newPath: to }, "android"); },
      function () { return Tools.Files.move({ path: from, newPath: to }); }
    ];
    for (var i = 0; i < attempts.length; i++) {
      try {
        var r = await attempts[i]();
        if (r == null) return { ok: true };
        if (typeof r === "boolean") return { ok: r, err: r ? null : "move returned false" };
        if (typeof r === "object") {
          if (r.success === true) return { ok: true };
          if (r.success === false) return { ok: false, err: String(r.message || r.error || "move failed") };
          if (r.ok === true) return { ok: true };
          if (r.ok === false) return { ok: false, err: String(r.error || r.message || "move failed") };
          return { ok: true };
        }
        return { ok: true };
      } catch (e) {
        // try next signature
      }
    }
    return { ok: false, err: "所有 move 调用方式都失败" };
  }

  async function rename_files(params) {
    params = params || {};
    var directory = params.directory;
    if (!directory) return { success: false, error: "directory 必填" };
    var pattern = params.pattern;
    if (!pattern) return { success: false, error: "pattern 必填" };
    var replacement = params.replacement == null ? "" : String(params.replacement);
    var dryRun = params.dry_run !== false; // 默认 true
    var recursive = params.recursive === true;

    var regex = null;
    try {
      regex = new RegExp(pattern);
    } catch (e) {
      return { success: false, error: "正则表达式无效: " + String(e && e.message ? e.message : e) };
    }

    var matched = [];
    var renamed = [];
    var skipped = [];

    async function walk(base) {
      var entries = await listDir(base);
      for (var i = 0; i < entries.length; i++) {
        var name = entryName(entries[i]);
        if (!name || name.charAt(0) === ".") continue;
        var path = base + (base.charAt(base.length - 1) === "/" ? "" : "/") + name;
        if (entryIsDir(entries[i])) {
          if (recursive) await walk(path);
          continue;
        }
        if (!regex.test(name)) continue;
        var newName = name.replace(regex, replacement);
        if (newName === name) continue;
        var newPath = base + (base.charAt(base.length - 1) === "/" ? "" : "/") + newName;
        var conflict = false;
        try {
          var er = await Tools.Files.exists(newPath, "android");
          conflict = !!(er && (er.exists === true || er === true));
        } catch (e2) {
          try {
            var er2 = await Tools.Files.exists(newPath);
            conflict = !!(er2 && (er2.exists === true || er2 === true));
          } catch (e3) { conflict = false; }
        }
        if (conflict) {
          skipped.push(name + " -> 冲突(已存在): " + newName);
          continue;
        }
        if (dryRun) {
          matched.push({ from: name, to: newName });
        } else {
          var mr = await safeMove(path, newPath);
          if (mr.ok) {
            renamed.push({ from: name, to: newName });
          } else {
            skipped.push(name + " -> 失败: " + mr.err);
          }
        }
      }
    }

    try {
      var dirExists = await Tools.Files.exists(directory, "android");
      if (!dirExists) return { success: false, error: "目录不存在: " + directory };
    } catch (e) {
      return { success: false, error: "无法检查目录: " + directory + " (" + String(e && e.message ? e.message : e) + ")" };
    }

    await walk(directory);
    return {
      success: true,
      directory: directory,
      pattern: pattern,
      dry_run: dryRun,
      engine: "js-sandbox",
      matched: matched.length + renamed.length,
      preview: matched,
      renamed: renamed,
      skipped: skipped
    };
  }

  return {
    rename_files: rename_files
  };
})();

exports.rename_files = jsTools.rename_files;