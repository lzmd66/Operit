/*
METADATA
{
    "name": "py_tools",
    "description": "Python 工具桥接包：像 JS 包一样使用 Python 工具。工具定义在 /sdcard/Download/Operit/py_tools/*.py，头部 # METADATA 注释声明。",
    "enabledByDefault": true,
    "tools": [
        {
            "name": "list_py_tools",
            "description": "扫描 py_tools 目录，列出所有可用的 Python 工具及其参数定义",
            "parameters": []
        },
        {
            "name": "call_py_tool",
            "description": "调用一个 Python 工具（如 hello、calc）。参数以 JSON 传入，工具返回 JSON。",
            "parameters": [
                { "name": "name", "description": "Python 工具名", "type": "string", "required": true },
                { "name": "params", "description": "工具参数对象", "type": "object", "required": false }
            ]
        },
        {
            "name": "run_python",
            "description": "直接在 python3 中运行一段脚本字符串",
            "parameters": [
                { "name": "script", "description": "Python 代码", "type": "string", "required": true }
            ]
        }
    ]
}
*/

const pyTools = (function () {
  const TOOLS_DIR = "/sdcard/Download/Operit/py_tools";
  const PARAMS_FILE = TOOLS_DIR + "/.params.json";

  function extractText(r) {
    if (r == null) return "";
    if (typeof r === "string") return r;
    if (typeof r.content === "string") return r.content;
    if (typeof r.text === "string") return r.text;
    if (typeof r.output === "string") return r.output;
    if (typeof r.data === "string") return r.data;
    if (r.data && typeof r.data.content === "string") return r.data.content;
    if (r.data && typeof r.data.output === "string") return r.data.output;
    try {
      return JSON.stringify(r);
    } catch (e) {
      return String(r);
    }
  }

  function safeName(name) {
    return typeof name === "string" && /^[a-zA-Z_][a-zA-Z0-9_]*$/.test(name);
  }

  // 执行终端命令：优先 hiddenExec（新 executorKey 创建健康实例），fallback toolCall
  async function exec(command, timeoutMs) {
    var t = timeoutMs || 60000;
    // 1) hiddenExec（新 executorKey 避开历史坏会话；实测可用）
    try {
      if (Tools && Tools.System && Tools.System.terminal &&
          typeof Tools.System.terminal.hiddenExec === "function") {
        var r0 = await Tools.System.terminal.hiddenExec(
          "cd /tmp 2>/dev/null; " + command,
          { executorKey: "py_tools_exec", timeoutMs: t }
        );
        var out0 = extractText(r0);
        if (out0 && out0.length > 0) {
          return { output: out0, exitCode: 0, via: "hiddenExec" };
        }
      }
    } catch (e0) {
      // fallthrough
    }
    // 2) toolCall super_admin:terminal（备用）
    try {
      if (typeof toolCall === "function") {
        var r = await toolCall("super_admin", "terminal", {
          command: command,
          timeoutMs: t
        });
        var out = extractText(r);
        return { output: out, exitCode: 0, via: "toolCall", detail: r };
      }
    } catch (e) {
      return { output: String(e && e.message ? e.message : e), exitCode: -1, via: "toolCallThrew" };
    }
    return { output: "no exec backend", exitCode: -1, via: "none" };
  }

  // 读取文件文本
  async function readText(path) {
    try {
      var r = await Tools.Files.read({ path: path, environment: "android" });
      return extractText(r);
    } catch (e) {
      return null;
    }
  }

  // 写入文件
  async function writeText(path, text) {
    try {
      await Tools.Files.write(path, String(text), false, "android");
      return true;
    } catch (e) {
      try {
        await Tools.Files.write(path, String(text), false);
        return true;
      } catch (e2) {
        return false;
      }
    }
  }

  // 列出目录
  async function listDir(path) {
    try {
      var r = await Tools.Files.list(path, "android");
      if (Array.isArray(r)) return r;
      if (r && Array.isArray(r.entries)) return r.entries;
      if (r && Array.isArray(r.files)) return r.files;
      if (r && r.data && Array.isArray(r.data.entries)) return r.data.entries;
    } catch (e) {}
    return [];
  }

  function entryName(item) {
    if (!item) return "";
    if (typeof item === "string") return item;
    return item.name || item.fileName || item.filename || item.path || "";
  }

  // 解析 .py 文件头部的 # METADATA 注释
  function parseMetadata(content) {
    if (!content) return null;
    var lines = content.split(/\r?\n/);
    var buf = [];
    var inMeta = false;
    for (var i = 0; i < lines.length && i < 30; i++) {
      var line = lines[i];
      var m = line.match(/^#\s*METADATA\s*$/);
      if (m) { inMeta = true; continue; }
      if (inMeta) {
        var jm = line.match(/^#\s*(.+)$/);
        if (jm) { buf.push(jm[1]); continue; }
        break;
      }
    }
    if (buf.length === 0) return null;
    try {
      return JSON.parse(buf.join("\n"));
    } catch (e) {
      return null;
    }
  }

  async function list_py_tools() {
    var entries = await listDir(TOOLS_DIR);
    var tools = [];
    for (var i = 0; i < entries.length; i++) {
      var name = entryName(entries[i]);
      if (!name || name.charAt(0) === "." || name.indexOf(".py") !== name.length - 3) continue;
      var content = await readText(TOOLS_DIR + "/" + name);
      var meta = parseMetadata(content);
      if (meta && meta.name) {
        tools.push({
          file: name,
          name: meta.name,
          description: meta.description || "",
          parameters: meta.parameters || []
        });
      }
    }
    return {
      success: true,
      tools_dir: TOOLS_DIR,
      count: tools.length,
      tools: tools,
      hint: "调用方式: call_py_tool({ name: '<工具名>', params: {...} })"
    };
  }

  async function call_py_tool(params) {
    try {
      return await callPyInner(params);
    } catch (e) {
      return { success: false, error: "内部错误: " + String(e && e.message ? e.message : e) };
    }
  }

  async function callPyInner(params) {
    var toolName = params.name;
    if (!safeName(toolName)) {
      return { success: false, error: "工具名非法，仅允许字母/数字/下划线" };
    }
    // 找到对应 .py 文件
    var entries = await listDir(TOOLS_DIR);
    var pyFile = null;
    for (var i = 0; i < entries.length; i++) {
      var en = entryName(entries[i]);
      if (en === toolName + ".py") { pyFile = en; break; }
    }
    if (!pyFile) {
      // 重新列出可用工具
      var listing = await list_py_tools();
      return {
        success: false,
        error: "未找到 Python 工具: " + toolName,
        available: listing.tools.map(function (t) { return t.name; })
      };
    }

    // 参数写入临时文件
    var payload = JSON.stringify(params.params || {});
    var ok = await writeText(PARAMS_FILE, payload);
    if (!ok) {
      return { success: false, error: "无法写入参数文件 " + PARAMS_FILE };
    }

    // 终端执行：python3 工具文件 工具名 < 参数文件
    var cmd = "cd /tmp 2>/dev/null; python3 '" + TOOLS_DIR + "/" + pyFile + "' " +
      toolName + " < '" + PARAMS_FILE + "' 2>&1";
    var r = await exec(cmd, 90000);
    var out = (r.output || "").trim();
    if (r.via === "failed" || r.via === "toolCallThrew" || r.via === "hiddenExecThrew" || r.via === "none") {
      return { success: false, error: "终端后端不可用(" + r.via + "): " + out };
    }
    // 尝试解析 JSON
    try {
      var parsed = JSON.parse(out);
      // 兼容终端包装结构：{command, output, exitCode, ...}，取 output 再解析
      if (parsed && typeof parsed === "object" && parsed.command !== undefined &&
          typeof parsed.output === "string") {
        out = String(parsed.output).trim();
        try {
          parsed = JSON.parse(out);
        } catch (e2) {
          return {
            success: true,
            tool: toolName,
            raw_output: out || "(no output)",
            via: r.via
          };
        }
      }
      return {
        success: parsed.ok !== false,
        tool: toolName,
        result: parsed.result !== undefined ? parsed.result : null,
        error: parsed.error || null,
        via: r.via
      };
    } catch (e) {
      // 不是 JSON：返回原始输出
      return {
        success: true,
        tool: toolName,
        raw_output: out || "(no output)",
        via: r.via
      };
    }
  }

  async function run_python(params) {
    var script = params.script;
    if (!script || !String(script).trim()) {
      return { success: false, error: "请提供 script" };
    }
    var scriptFile = TOOLS_DIR + "/.run_script.py";
    var ok = await writeText(scriptFile, String(script));
    if (!ok) {
      return { success: false, error: "无法写入脚本文件" };
    }
    var cmd = "cd /tmp 2>/dev/null; python3 '" + scriptFile + "' 2>&1";
    var r = await exec(cmd, 120000);
    var out = (r.output || "").trim();
    if (r.via === "failed") {
      return { success: false, error: "终端后端不可用: " + out };
    }
    return {
      success: true,
      output: out || "(no output)",
      via: r.via
    };
  }

  async function main() {
    var r = await run_python({ script: "print('py_tools_ok', 1+2)" });
    return "py_tools smoke: " + (r.output || r.error);
  }

  return {
    main: main,
    list_py_tools: list_py_tools,
    call_py_tool: call_py_tool,
    run_python: run_python
  };
})();

exports.main = pyTools.main;
exports.list_py_tools = pyTools.list_py_tools;
exports.call_py_tool = pyTools.call_py_tool;
exports.run_python = pyTools.run_python;
