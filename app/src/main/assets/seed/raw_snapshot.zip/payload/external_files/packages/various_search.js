/*
METADATA
{
  "name": "various_search",
  "display_name": { "zh": "可靠网页搜索", "en": "Reliable Web Search" },
  "category": "Search",
  "description": {
    "zh": "轻量、可靠的多引擎网页搜索。默认只请求搜索结果页，不自动逐条打开网页。路由定稿（2026-10-02 复核）：默认 Bing → 免费兜底 DuckDuckGo（DDG 无 VPN 不可用）；Google 链路已弃用（解析层故障，VPN 也无法解决）。⚠️Bing 对中文专有名词/游戏长尾召回极差（实测返回字典释义），中文查询请优先 metaso_search / zhipu_search，英文优先 tavily_search，本包只在上面几个都不可用时用。博查额度已用尽（停用）。结果会去重、过滤低质量站点并按相关性和来源可信度排序。",
    "en": "Lightweight and reliable multi-engine web search. It only requests result pages by default, never opens result pages automatically, and ranks deduplicated results by relevance and source quality."
  },
  "enabledByDefault": true,
  "env": [
    {
      "name": "ANYSEARCH_API_KEY",
      "description": {
        "zh": "AnySearch 免费档 API Key（可选；配置后 AnySearch 显式引擎走注册档 rate_limit 20/窗口 + 无总量限制，未配置自动回退匿名档）",
        "en": "AnySearch free-tier API key (optional; enables the registered rate limit with no total quota, falls back to anonymous access when unset)"
      },
      "required": false
    }
  ],
  "tools": [
    {
      "name": "search_web",
      "description": "默认网页搜索。优先 Bing（2026-09-05 定稿），必要时回退 DuckDuckGo（注意：DDG 无 VPN 时不可用，需要 DDG 高质量结果时可提醒用户开 VPN）；首个成功引擎立即返回。适合绝大多数联网查询，快速且不会因跟进结果链接而长时间等待。",
      "parameters": [
        { "name": "query", "description": "清晰、具体的搜索关键词。", "type": "string", "required": true },
        { "name": "max_results", "description": "返回结果数，默认 6，范围 1~10。", "type": "number", "required": false },
        { "name": "platforms", "description": "可选兼容参数：duckduckgo、google、bing、brave；多个用逗号分隔。通常无需填写。", "type": "string", "required": false },
        { "name": "includeLinks", "description": "兼容参数；结果始终会给出可访问 URL。此参数不会触发自动打开结果页。", "type": "boolean", "required": false }
      ]
    },
    {
      "name": "search",
      "description": "兼容别名。默认使用可靠网页搜索；可通过 platforms 指定一个引擎或少量引擎。",
      "parameters": [
        { "name": "query", "description": "搜索关键词。", "type": "string", "required": true },
        { "name": "platforms", "description": "可选：duckduckgo、google、bing；多个用逗号分隔。默认 bing,duckduckgo。", "type": "string", "required": false },
        { "name": "includeLinks", "description": "兼容参数，不会触发自动打开结果页。", "type": "boolean", "required": false }
      ]
    },
    {
      "name": "combined_search",
      "description": "多引擎交叉搜索。最多并行两个引擎，用于需要交叉验证或首个引擎失败时；不自动访问结果链接。",
      "parameters": [
        { "name": "query", "description": "搜索关键词。", "type": "string", "required": true },
        { "name": "platforms", "description": "可选引擎：duckduckgo、google、bing；默认 bing,duckduckgo。旧调用指定 duckduckgo,google 时会自动以 Bing 补位。为保证响应速度，最多优先使用两个引擎。", "type": "string", "required": false },
        { "name": "includeLinks", "description": "兼容参数，不会触发自动打开结果页。", "type": "boolean", "required": false }
      ]
    },
    {
      "name": "search_clean",
      "description": "高质量搜索：并行交叉 Bing 与 DuckDuckGo，任一引擎失败不影响整体。会去重、限制同一站点重复出现，并按问题类型优先官方文档、论文、政府、大学、GitHub 或可信资料。",
      "parameters": [
        { "name": "query", "description": "搜索关键词。建议包含主题、时间范围、地区或具体对象。", "type": "string", "required": true },
        { "name": "platforms", "description": "可选引擎：duckduckgo、google、bing、brave。默认三引擎交叉；可指定单一引擎。", "type": "string", "required": false },
        { "name": "max_results", "description": "返回结果数，默认 6，范围 1~10。", "type": "number", "required": false }
      ]
    },
    {
      "name": "verify_sources",
      "description": "按需双来源核验：先进行高质量搜索，再最多打开两条可信结果并抽取与问题相关的原文段落。仅在需要事实依据、参数核对、政策、技术文档或重要结论时使用；不会批量访问搜索结果。",
      "parameters": [
        { "name": "query", "description": "要核验的具体问题或搜索关键词。", "type": "string", "required": true },
        { "name": "platforms", "description": "可选引擎：bing、duckduckgo。默认双引擎交叉后再选取可信来源。", "type": "string", "required": false },
        { "name": "max_sources", "description": "最多访问的可信网页数，默认 2，范围 1~2。", "type": "number", "required": false }
      ]
    },
    {
      "name": "search_reviews",
      "description": "真实用户口碑搜索。用于查电子产品、数码设备、耳机、手机、显卡等是否值得买。会自动追加缺点/翻车/踩坑/真实体验等词扩展检索，优先 Reddit、NGA、V2EX、Chiphell、Steam 社区、TapTap 等真实玩家讨论，强力拦截淘宝导购页、内容农场和标题党软文。适合用户想听真实使用者反馈而不是厂商宣传或推广测评时使用。",
      "parameters": [
        { "name": "query", "description": "产品名称或型号，例如“红米 K80”“AirPods Pro 3”“RTX 5070”。不需要自己加“怎么样/值得买”。", "type": "string", "required": true },
        { "name": "aspect", "description": "可选：想重点了解的方面，例如“续航”“发热”“做工”“翻车”“长期使用”。留空则综合查优缺点。", "type": "string", "required": false },
        { "name": "max_results", "description": "返回结果数，默认 8，范围 1~12。", "type": "number", "required": false }
      ]
    },
    {
      "name": "search_bing",
      "description": "仅使用 Bing 搜索。适合需要指定 Bing 的场景。",
      "parameters": [
        { "name": "query", "description": "搜索关键词。", "type": "string", "required": true },
        { "name": "includeLinks", "description": "兼容参数，不会触发自动打开结果页。", "type": "boolean", "required": false }
      ]
    },
    {
      "name": "search_google",
      "description": "仅使用 Google 搜索。⚠️ 已弃用：解析链路故障（2026-09-05 实测，开 VPN 也无法解决），调用会返回明确失败信息；国际信息请改用 Bing 或 Tavily。",
      "parameters": [
        { "name": "query", "description": "搜索关键词。", "type": "string", "required": true },
        { "name": "includeLinks", "description": "兼容参数，不会触发自动打开结果页。", "type": "boolean", "required": false }
      ]
    },
    {
      "name": "search_brave",
      "description": "Brave 兼容入口。当前版本为避免不稳定的网页结构，自动使用稳定的 Bing 回退，并在结果中标明实际来源。",
      "parameters": [
        { "name": "query", "description": "搜索关键词。", "type": "string", "required": true },
        { "name": "includeLinks", "description": "兼容参数，不会触发自动打开结果页。", "type": "boolean", "required": false }
      ]
    },
    {
      "name": "search_startpage",
      "description": "兼容别名：使用隐私优先的 DuckDuckGo 搜索，不再调用响应较慢的 Startpage。",
      "parameters": [
        { "name": "query", "description": "搜索关键词。", "type": "string", "required": true },
        { "name": "includeLinks", "description": "兼容参数。", "type": "boolean", "required": false }
      ]
    },
    {
      "name": "search_bing_images",
      "description": "使用 Bing 图片搜索，返回图片编号；下载时使用 download_file 的 visit_key + image_number。",
      "parameters": [{ "name": "query", "description": "图片搜索关键词。", "type": "string", "required": true }]
    },
    {
      "name": "search_wikimedia_images",
      "description": "在 Wikimedia Commons 搜索可复用图片。",
      "parameters": [{ "name": "query", "description": "图片搜索关键词。", "type": "string", "required": true }]
    },
    {
      "name": "search_duckduckgo_images",
      "description": "使用 DuckDuckGo 图片搜索。",
      "parameters": [{ "name": "query", "description": "图片搜索关键词。", "type": "string", "required": true }]
    },
    {
      "name": "search_ecosia_images",
      "description": "使用 Ecosia 图片搜索。",
      "parameters": [{ "name": "query", "description": "图片搜索关键词。", "type": "string", "required": true }]
    },
    {
      "name": "search_pexels_images",
      "description": "在 Pexels 搜索图片。",
      "parameters": [{ "name": "query", "description": "图片搜索关键词。", "type": "string", "required": true }]
    },
    {
      "name": "search_pixabay_images",
      "description": "在 Pixabay 搜索图片。",
      "parameters": [{ "name": "query", "description": "图片搜索关键词。", "type": "string", "required": true }]
    }
  ]
}
*/

const various_search = (function () {
  const REQUEST_TIMEOUT_MS = 6500;
  // A failed fallback chain must still return promptly instead of leaving the chat UI spinning.
  const TOTAL_FALLBACK_TIMEOUT_MS = 13000;
  const IMAGE_TIMEOUT_MS = 10000;
  const VERIFY_SOURCE_TIMEOUT_MS = 7000;
  // Google is fetched through the webview visit link, which needs more headroom
  // than a plain HTTP call but is still bounded so the chat cannot hang.
  const GOOGLE_SEARCH_TIMEOUT_MS = 8500;
  // Balanced mode: cross three engines in parallel so one flaky engine cannot
  // silently degrade result quality.
  const QUALITY_ENGINES = ["bing", "duckduckgo"];

  // Community sources where real owners actually discuss long-term use.
  // Grouped by vertical: international gaming, CN gaming, hardware/audio,
  // and user-generated rating aggregators. Scores are intentional.
  const COMMUNITY_DOMAIN_SCORES = {
    // ---- international gaming & player reviews ----
    "reddit.com": 40,
    "steamcommunity.com": 42, "steamstatic.com": 40, "steamdb.info": 38,
    "store.steampowered.com": 42,
    "metacritic.com": 36,
    "opencritic.com": 34,
    "gamefaqs.gamespot.com": 34, "gamefaqs.com": 34,
    "resetera.com": 36,
    "neogaf.com": 30, "rpgcodex.net": 30, "famiboards.com": 28,
    "gbatemp.net": 26, "vndb.org": 26,
    "howlongtobeat.com": 30,
    "backloggd.com": 32,
    "gog.com": 34,
    "boardgamegeek.com": 32,
    "pcgamingwiki.com": 28,
    "twitch.tv": 20,
    "youtube.com": 18,
    // ---- CN gaming & player reviews ----
    "taptap.cn": 38, "taptap.com": 36,
    "ngabbs.com": 38, "nga.cn": 38, "bbs.nga.cn": 38,
    "steamcn.com": 34, "keylol.com": 34,
    "gamegene.cn": 30,
    "gamer.cn": 26,
    "3dmgame.com": 26, "ali213.net": 24, "yxdown.com": 22,
    "bilibili.com": 20,
    // ---- JP/KR/RU community & price-review aggregators ----
    "5ch.net": 26, "kakaku.com": 28,
    "ruliweb.com": 30, "inven.co.kr": 30, "clien.net": 26,
    "4pda.to": 26,
    // ---- hardware/audio/PC user reviews ----
    "pcpartpicker.com": 38,
    "userbenchmark.com": 30,
    "notebookcheck.net": 32, "rtings.com": 34, "gsmarena.com": 30,
    "dxomark.com": 26, "anandtech.com": 34, "techpowerup.com": 34,
    "tomshardware.com": 28, "arstechnica.com": 28, "soundguys.com": 28,
    "headphonesty.com": 24, "head-fi.org": 32, "avsforum.com": 28,
    "audiosciencereview.com": 34, "diyaudio.com": 26, "avforums.com": 28,
    "guru3d.com": 28, "geekhack.org": 24,
    "xda-developers.com": 30, "forum.xda-developers.com": 32,
    "linustechtips.com": 26, "overclock.net": 26,
    "news.ycombinator.com": 24,
    "miui.com": 30, "vip.miui.com": 30, "xiaomi.eu": 32,
    "coolapk.com": 30, "hupu.com": 26, "bbs.hupu.com": 26,
    // ---- CN community/forum ----
    "v2ex.com": 36, "chiphell.com": 38, "hostloc.com": 24,
    "tieba.baidu.com": 26, "smzdm.com": 24, "post.smzdm.com": 24,
    "douban.com": 22,
    "acfun.cn": 18,
    "pcbeta.com": 28,
    // ---- user rating aggregators / general ----
    "trustpilot.com": 26, "sitejabber.com": 22,
    "consumerreports.org": 24,
    "amazon.com": 24, "amazon.cn": 22,
    "amazon.co.jp": 22, "amazon.de": 22, "amazon.co.uk": 22,
    "igdb.com": 24, "rawg.io": 24,
    "newegg.com": 24,
    "pcmag.com": 20, "techradar.com": 22,
    "stackexchange.com": 30, "superuser.com": 26
  };

  // Shopping-guide farms and SEO templates that dominate Chinese product queries.
  // These are excluded entirely from review search.
  const REVIEW_BLOCKED_DOMAINS = [
    "bk.taobao.com", "shuma.taobao.com", "taobao.com", "tmall.com",
    "jd.com", "suning.com", "gome.com.cn", "pinduoduo.com",
    "zol.com.cn", "wap.zol.com.cn", "pconline.com.cn", "it168.com",
    "duote.com", "xitongzhijia.net", "mydrivers.com",
    "expreview.com", "cnmo.com", "eefocus.com", "qianzhan.com",
    // aggregator/farm that are mostly reposts or ad pages
    "aibase.com", "36kr.com", "ithome.com", "ifeng.com", "sohu.com"
  ];

  // Marketing phrasing typical of paid or templated product articles.
  const HYPE_WORDS = [
    "值得买吗", "宝藏级", "搞钱必看", "闭眼入", "无脑入", "神机",
    "王炸", "真香", "封神", "碾压", "全网最", "最强", "爆款",
    "不踩坑指南", "小白必看", "学生党必看", "秒杀", "吊打",
    "良心", "плюс", "推荐榜", "排行榜", "十大", "口碑榜"
  ];

  // Words that indicate genuine ownership experience rather than promotion.
  const AUTHENTIC_WORDS = [
    "缺点", "翻车", "踩坑", "劝退", "退货", "毛病", "问题", "故障",
    "实际使用", "真实体验", "用了", "半年", "三个月", "长期",
    "后悔", "吐槽", "对比", "实测", "issue", "complaint", "problem",
    "review", "experience", "owners", "long-term", "teardown"
  ];
  const USER_AGENT = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";
  const DEFAULT_ENGINES = ["bing", "duckduckgo"];
  const SUPPORTED_ENGINES = ["duckduckgo", "google", "bing", "brave", "anysearch"];
  // Hard-block sources that are usually navigation pages, scraped content, or low-value Q&A.
  const HARD_BLOCKED_DOMAINS = [
    "baijiahao.baidu.com", "zhidao.baidu.com", "wenku.baidu.com", "tieba.baidu.com",
    "jingyan.baidu.com", "360doc.com", "hao123.com", "aibase.com"
  ];
  // 2026-10-02 新增：词典/字典站。Bing 中文拆词（「王国之泪」→「王国」）时这些站会霸屏，
  // 它们几乎从不是攻略/事实类查询想要的东西 —— 重罚，但不硬拦（查词义时仍可能有用）。
  const DICTIONARY_DOMAINS = [
    "iciba.com", "cambridge.org", "hgcha.com", "hanyuguoxue.com", "chagushici.com",
    "shidianguji.com", "gushici.net", "revised.moe.edu.tw", "zdic.net", "unihan.net",
    "chazidian.com", "baic.com", "youdao.com", "baike.sogou.com"
  ];
  // 影视剧情聚合站：查询非影视类时属噪声（实测韩剧《王国》剧情站占满 Bing 结果页）
  const MEDIA_PLOT_DOMAINS = ["tvmao.com", "tvsou.com", "dbtv.com", "kanju.com", "jjtv.net"];
  // 漫画/小说聚合站：2026-10-02 回归实测发现的新噪声类（查"翻译"返回三个漫画站）
  const READER_SPAM_DOMAINS = ["pipo1.com", "dumanwu.com", "liumanhua.com", "qidian.com", "jjwxc.net"];

  // These are retained only when there is not enough better material, and ranked lower.
  const LOW_QUALITY_DOMAINS = [
    "csdn.net", "jianshu.com", "sohu.com", "toutiao.com", "quora.com",
    "juejin.cn", "app.sharess.cn", "sourceforge.net", "sofarbot.com",
    "baike.baidu.com", "apifox.com", "chatgpt-chinese.com", "devpost.com",
    "kaiyuanbang.cn", "runebook.dev", "kancloud.cn", "cnblogs.com"
  ];
  const TRUSTED_DOMAIN_SCORES = {
    "gov.cn": 34, "gov": 34, "edu.cn": 30, "edu": 30, "ac.uk": 30,
    "nih.gov": 34, "who.int": 34, "github.com": 25, "gitlab.com": 22,
    "arxiv.org": 26, "doi.org": 30, "nature.com": 26, "science.org": 26,
    "ieee.org": 25, "acm.org": 25, "openai.com": 28, "developers.openai.com": 36,
    "platform.openai.com": 36, "anthropic.com": 28, "developer.mozilla.org": 30,
    "docs.python.org": 30, "nodejs.org": 28,
    "developer.android.com": 30, "learn.microsoft.com": 30, "support.apple.com": 27,
    "reuters.com": 24, "apnews.com": 24, "bbc.com": 20, "wikipedia.org": 15
  };
  const LOW_VALUE_WORDS = [
    "广告", "推广", "加盟", "加微信", "扫码", "下载站", "破解版", "免费领取",
    "限时优惠", "软文", "伪原创", "代写", "引流"
  ];
  const SEARCH_HEADERS = {
    "User-Agent": USER_AGENT,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8"
  };

  function asText(value) {
    return value === null || value === undefined ? "" : String(value);
  }

  function normalizeQuery(query) {
    return asText(query).replace(/\s+/g, " ").trim();
  }

  function clamp(value, fallback, min, max) {
    const number = Number(value);
    return isFinite(number) ? Math.min(max, Math.max(min, Math.floor(number))) : fallback;
  }

  function withTimeout(promise, timeoutMs, label) {
    return new Promise(function (resolve, reject) {
      const timer = setTimeout(function () {
        reject(new Error((label || "请求") + "超时（" + timeoutMs + "ms）"));
      }, timeoutMs);
      Promise.resolve(promise).then(function (value) {
        clearTimeout(timer);
        resolve(value);
      }, function (error) {
        clearTimeout(timer);
        reject(error);
      });
    });
  }

  function decodeHtml(text) {
    return asText(text)
      .replace(/&amp;/gi, "&")
      .replace(/&lt;/gi, "<")
      .replace(/&gt;/gi, ">")
      .replace(/&quot;/gi, '"')
      .replace(/&#39;/gi, "'")
      .replace(/&#x27;/gi, "'")
      .replace(/&nbsp;/gi, " ")
      .replace(/&#(\d+);/g, function (_, code) {
        const number = Number(code);
        return number >= 32 && number <= 65535 ? String.fromCharCode(number) : " ";
      });
  }

  function stripHtml(text) {
    return decodeHtml(asText(text)
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, " ")
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, " ")
      .replace(/<[^>]+>/g, " "))
      .replace(/\s+/g, " ")
      .trim();
  }

  function normalizeUrl(url) {
    let value = decodeHtml(asText(url)).trim();
    if (!value) return "";
    if (value.indexOf("//") === 0) value = "https:" + value;
    value = value.replace(/\\u0026/g, "&").replace(/\\\//g, "/");
    if (!/^https?:\/\//i.test(value)) return "";
    return value.replace(/[),.;]+$/, "");
  }

  function hostOf(url) {
    const match = normalizeUrl(url).match(/^https?:\/\/([^\/?#:]+)/i);
    return match ? match[1].toLowerCase().replace(/^www\./, "") : "";
  }

  function domainMatches(host, domain) {
    return host === domain || host.slice(-(domain.length + 1)) === "." + domain;
  }

  function inDomains(url, domains) {
    const host = hostOf(url);
    return domains.some(function (domain) { return domainMatches(host, domain); });
  }

  function comparableUrl(url) {
    const normalized = normalizeUrl(url);
    if (!normalized) return "";
    return normalized
      .replace(/^https?:\/\/(www\.)?/i, "")
      .replace(/[?#].*$/, "")
      .replace(/\/+$/, "")
      .toLowerCase();
  }

  function unwrapRedirect(url) {
    const normalized = normalizeUrl(url);
    if (!normalized) return "";

    const uddg = normalized.match(/[?&]uddg=([^&]+)/i);
    if (uddg) {
      try { return normalizeUrl(decodeURIComponent(uddg[1])); } catch (_) {}
    }

    const google = normalized.match(/^https?:\/\/www\.google\.[^/]+\/url\?(?:[^#]*&)?q=([^&]+)/i);
    if (google) {
      try { return normalizeUrl(decodeURIComponent(google[1])); } catch (_) {}
    }

    return normalized;
  }

  function createClient() {
    try {
      return OkHttp.newBuilder()
        .connectTimeout(3500)
        .readTimeout(5000)
        .writeTimeout(3500)
        .followRedirects(true)
        .retryOnConnectionFailure(false)
        .build();
    } catch (_) {
      return OkHttp.newClient();
    }
  }

  const client = createClient();

  function makeSearchUrl(engine, query) {
    const encoded = encodeURIComponent(query);
    if (engine === "google") return "https://www.google.com/search?q=" + encoded + "&hl=zh-CN&gl=us&num=10&pws=0";
    if (engine === "bing") return "https://www.bing.com/search?q=" + encoded + "&setmkt=zh-CN";
    if (engine === "brave") return "https://search.brave.com/search?q=" + encoded + "&source=web";
    return "";
  }

  // Bing 的 HTML 端点对无浏览器特征的客户端会摘除有机结果；2026-09-07 起
  // HTML 端点进一步改为 JS 渐进式渲染，纯 HTTP 抓包只能得到空结果容器。
  // RSS 端点（format=rss）为服务端渲染，不受影响。⚠️ 旧结论“RSS 中文质量差”
  // 已被推翻：实为 mkt=en-US 市场参数所致，zh-CN 市场中文召回良好。
  function isEnglishQuery(query) {
    return !/[\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af]/.test(normalizeQuery(query));
  }

  function makeBingRssUrl(query) {
    // 中文查询用 zh-CN 市场（2026-09-07 实测：旧结论“RSS 对中文质量差”
    // 实为 mkt=en-US 市场参数所致，zh-CN 市场中文召回良好，10条/次）
    const mkt = isEnglishQuery(query) ? "en-US" : "zh-CN";
    return "https://www.bing.com/search?q=" + encodeURIComponent(query) + "&format=rss&mkt=" + mkt;
  }

  function parseBingRss(xml) {
    const items = [];
    const itemRegex = /<item>([\s\S]*?)<\/item>/gi;
    let block;
    while ((block = itemRegex.exec(xml)) !== null && items.length < 20) {
      const value = block[1];
      const title = (value.match(/<title>([\s\S]*?)<\/title>/i) || [])[1] || "";
      const link = (value.match(/<link>([\s\S]*?)<\/link>/i) || [])[1] || "";
      const description = (value.match(/<description>([\s\S]*?)<\/description>/i) || [])[1] || "";
      const url = normalizeUrl(link);
      const host = hostOf(url);
      if (!url || !host) continue;
      if (host.indexOf("bing.com") >= 0) continue;
      addItem(items, title, url, description, "bing_rss");
    }
    return items;
  }

  async function fetchBingRss(query) {
    const response = await withTimeout(
      client.newRequest()
        .url(makeBingRssUrl(query))
        .method("GET")
        .headers(SEARCH_HEADERS)
        .build()
        .execute(),
      REQUEST_TIMEOUT_MS,
      "bing_rss"
    );
    const status = Number(response && response.statusCode) || 0;
    const xml = asText(response && response.content);
    if (status && (status < 200 || status >= 400)) throw new Error("HTTP " + status);
    const items = parseBingRss(xml);
    if (!items.length) throw new Error("RSS 未解析到结果");
    return items;
  }

  // AnySearch 免费档（2026-09-07 实测：国内直连可达，中文召回含 NGA/社区讨论。
  // 已注册免费 key（注册用邮箱见路由记忆），key 存于 Operit 环境变量
  // ANYSEARCH_API_KEY，未配置时自动回退匿名档（匿名档实测限流宽松、连发不递减）。
  // key 档：rate_limit 20/窗口 + quota_limit 0（无总量限制）。仍按备用纪律使用：
  // 不进默认引擎链，由路由规则在召回不足时显式调用。失败静默，不影响其他引擎。）
  async function fetchAnySearch(query, maxResults) {
    const anyKey = String(getEnv("ANYSEARCH_API_KEY") || "").trim();
    const req = client.newRequest()
      .url("https://api.anysearch.com/v1/search")
      .method("POST")
      .header("Content-Type", "application/json");
    if (anyKey) req.header("Authorization", "Bearer " + anyKey);
    const response = await withTimeout(
      req
        .body(JSON.stringify({
          query: query,
          max_results: clamp(maxResults, 5, 1, 10),
          language: "zh-CN",
        }), "json")
        .build()
        .execute(),
      REQUEST_TIMEOUT_MS,
      "anysearch"
    );
    const status = Number(response && response.statusCode) || 0;
    if (status && (status < 200 || status >= 400)) throw new Error("HTTP " + status);
    try {
      payload = JSON.parse(asText(response && response.content));
    } catch (_) {
      payload = null;
    }
    const results = (payload && payload.data && payload.data.results)
      || (payload && payload.results) || [];
    const items = [];
    for (let i = 0; i < results.length; i++) {
      const r = results[i];
      addItem(items, r.title, r.url, r.content || r.description || r.snippet, "anysearch");
    }
    if (!items.length) throw new Error("AnySearch 未解析到结果");
    return items;
  }

  async function fetchHtml(engine, query) {
    let request;
    if (engine === "duckduckgo") {
      request = client.newRequest()
        .url("https://html.duckduckgo.com/html/")
        .method("POST")
        .body({ q: query, b: "", kl: "cn-zh" }, "form")
        .headers(SEARCH_HEADERS);
    } else {
      const url = makeSearchUrl(engine, query);
      if (!url) throw new Error("不支持的搜索引擎: " + engine);
      request = client.newRequest()
        .url(url)
        .method("GET")
        .headers(SEARCH_HEADERS);
    }

    const response = await withTimeout(request.build().execute(), REQUEST_TIMEOUT_MS, engine);
    const status = Number(response && response.statusCode) || 0;
    const html = asText(response && response.content);
    if (status && (status < 200 || status >= 400)) throw new Error("HTTP " + status);
    if (html.length < 200) throw new Error("返回内容为空或过短");
    return html;
  }

  function addItem(items, title, url, snippet, engine) {
    const finalUrl = unwrapRedirect(url);
    const finalTitle = stripHtml(title);
    const finalSnippet = stripHtml(snippet);
    const host = hostOf(finalUrl);
    if (!finalUrl || !finalTitle || !host) return;
    if (host.indexOf("google.") === 0 || host.indexOf("bing.com") >= 0 || host.indexOf("duckduckgo.com") >= 0 || host.indexOf("brave.com") >= 0) return;
    if (finalTitle.length < 3 || finalTitle.length > 320) return;
    items.push({ title: finalTitle, url: finalUrl, snippet: finalSnippet.slice(0, 420), engine: engine });
  }

  function parseDuckDuckGo(html) {
    const items = [];
    const regex = /<h2[^>]*class=["'][^"']*result__title[^"']*["'][^>]*>[\s\S]*?<a[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>[\s\S]*?<\/h2>[\s\S]*?(?:<a[^>]*class=["'][^"']*result__snippet[^"']*["'][^>]*>([\s\S]*?)<\/a>)?/gi;
    let match;
    while ((match = regex.exec(html)) !== null && items.length < 20) {
      addItem(items, match[2], match[1], match[3] || "", "duckduckgo");
    }
    if (items.length === 0) {
      const fallback = /<a[^>]*class=["'][^"']*result__a[^"']*["'][^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
      while ((match = fallback.exec(html)) !== null && items.length < 12) {
        addItem(items, match[2], match[1], "", "duckduckgo");
      }
    }
    return items;
  }

  function parseGoogle(html) {
    const items = [];
    const regex = /<a[^>]+href=["'](\/url\?[^"']+|https?:\/\/[^"']+)["'][^>]*>[\s\S]{0,1000}?<h3[^>]*>([\s\S]*?)<\/h3>[\s\S]*?<\/a>/gi;
    let match;
    while ((match = regex.exec(html)) !== null && items.length < 20) {
      let link = decodeHtml(match[1]);
      if (link.indexOf("/url?") === 0) {
        const q = link.match(/[?&]q=([^&]+)/);
        if (q) {
          try { link = decodeURIComponent(q[1]); } catch (_) {}
        }
      }
      const tail = html.slice(regex.lastIndex, regex.lastIndex + 1000);
      const snippet = tail.match(/<div[^>]*>([^<]{40,500})<\/div>/i);
      addItem(items, match[2], link, snippet ? snippet[1] : "", "google");
    }
    return items;
  }

  function parseBing(html) {
    const items = [];
    // Some Bing pages have an oversized first b_algo wrapper, so parse each result
    // by its result-header instead of relying on a non-nested </li> regex.
    const headerRegex = /<div[^>]*class=["'][^"']*b_algoheader[^"']*["'][^>]*>\s*<a[^>]*href=["']([^"']+)["'][^>]*>\s*<h2[^>]*>([\s\S]*?)<\/h2>\s*<\/a>\s*<\/div>/gi;
    let match;
    while ((match = headerRegex.exec(html)) !== null && items.length < 20) {
      const tail = html.slice(headerRegex.lastIndex, headerRegex.lastIndex + 1400);
      const snippet = tail.match(/<p[^>]*>([\s\S]*?)<\/p>/i);
      addItem(items, match[2], match[1], snippet ? snippet[1] : "", "bing");
    }
    return items;
  }

  function parseBrave(html) {
    const items = [];
    const regex = /<a[^>]+href=["'](https?:\/\/[^"']+)["'][^>]*>[\s\S]{0,700}?<[^>]*>([\s\S]*?)<\/[^>]+>/gi;
    let match;
    while ((match = regex.exec(html)) !== null && items.length < 20) {
      addItem(items, match[2], match[1], "", "brave");
    }
    return items;
  }

  function parseResults(engine, html) {
    if (engine === "duckduckgo") return parseDuckDuckGo(html);
    if (engine === "google") return parseGoogle(html);
    if (engine === "bing") return parseBing(html);
    if (engine === "brave") return parseBrave(html);
    return [];
  }

  function isSearchNavigationUrl(url) {
    const host = hostOf(url);
    const normalized = normalizeUrl(url);
    if (!normalized) return true;
    if (host === "google.com" || host.slice(-11) === ".google.com") return true;
    if (host === "translate.google.com") return true;
    if (host === "accounts.google.com") return true;
    if (host === "support.google.com") return true;
    if (normalized.indexOf("/search?") >= 0 && host.indexOf("google") >= 0) return true;
    return false;
  }

  function extractGoogleTitle(link) {
    const raw = asText(link && (link.text || link.title || link.name));
    const parts = raw.split(/\n+/).map(function (part) { return part.trim(); }).filter(Boolean);
    if (!parts.length) return "";
    return parts[0].slice(0, 320);
  }

  function extractGoogleSnippet(link) {
    const raw = asText(link && (link.text || link.title || link.name));
    const parts = raw.split(/\n+/).map(function (part) { return part.trim(); }).filter(Boolean);
    if (parts.length <= 2) return "";
    return parts.slice(2).join(" ").slice(0, 420);
  }

  function parseGoogleVisitResult(response) {
    const items = [];
    const links = response && Array.isArray(response.links) ? response.links : [];
    links.forEach(function (link) {
      const url = normalizeUrl(link && (link.realUrl || link.real_url || link.url || link.href || link.targetUrl || link.target_url));
      if (!url || isSearchNavigationUrl(url)) return;
      const title = extractGoogleTitle(link);
      if (!title || title.length < 3) return;
      addItem(items, title, url, extractGoogleSnippet(link), "google");
    });
    return items;
  }

  async function searchGoogleStructured(query) {
    const url = makeSearchUrl("google", query);
    const response = await withTimeout(Tools.Net.visit({ url: url }), GOOGLE_SEARCH_TIMEOUT_MS, "Google 搜索");
    const items = parseGoogleVisitResult(response);
    if (!items.length) throw new Error("Google 未返回可解析的结果");
    return items;
  }

  function queryTokens(query) {
    const result = [];
    normalizeQuery(query).toLowerCase().split(/[^a-z0-9\u4e00-\u9fff]+/).forEach(function (piece) {
      if (piece.length < 2) return;
      result.push(piece);
      const chinese = piece.replace(/[^\u4e00-\u9fff]/g, "");
      for (let index = 0; index + 1 < chinese.length; index++) result.push(chinese.slice(index, index + 2));
    });
    return result.filter(function (token, index) { return result.indexOf(token) === index; });
  }

  function sourceScore(url) {
    const host = hostOf(url);
    let score = 0;
    Object.keys(TRUSTED_DOMAIN_SCORES).forEach(function (domain) {
      if (domainMatches(host, domain)) score = Math.max(score, TRUSTED_DOMAIN_SCORES[domain]);
    });
    return score;
  }

  function scoreItem(item, query, frequency) {
    const title = item.title.toLowerCase();
    const combined = (item.title + " " + item.snippet + " " + item.url).toLowerCase();
    let score = 20 + sourceScore(item.url);

    queryTokens(query).forEach(function (token) {
      if (title.indexOf(token) >= 0) score += 12;
      else if (combined.indexOf(token) >= 0) score += 5;
    });

    if (frequency[comparableUrl(item.url)] > 1) score += 18;
    if (inDomains(item.url, LOW_QUALITY_DOMAINS)) score -= 35;
    if (item.snippet.length >= 60) score += 3;
    if (/(official|documentation|docs|research|paper|report|官方|文档|研究|论文|报告)/i.test(combined)) score += 6;

    LOW_VALUE_WORDS.forEach(function (word) {
      if (combined.indexOf(word) >= 0) score -= 20;
    });

    const q = normalizeQuery(query).toLowerCase();
    if (/(论文|学术|research|paper|doi|journal)/i.test(q) && /(arxiv|doi|nature|science|ieee|acm|edu)/i.test(hostOf(item.url))) score += 15;
    if (/(官网|官方|文档|api|docs|documentation)/i.test(q) && sourceScore(item.url) >= 22) score += 12;

    // ---- 2026-10-02：拆词噪声惩罚 ----
    // 背景（实测）：Bing 中文会把「王国之泪」拆成「王国」，于是一条游戏查询返回
    // 百科/豆瓣/腾讯/电视猫上的韩剧《王国》共 9 条。这里按"查询有没有该意图"
    // 做条件化惩罚——不做无条件硬拦，避免用户真查影视/词义时被误伤。
    const DICT_INTENT = /(意思|中文意思|翻译|读音|拼音|读法|解释|释义|词典|字典|怎么读|近义词|反义词|成语|术语)/;
    const MEDIA_INTENT = /(电影|电视剧|剧集|剧情|演员|导演|综艺|动漫|番剧|豆瓣|在线观看|收视|票房|韩剧|美剧|日剧)/;
    const qn = normalizeQuery(query).toLowerCase();
    if (inDomains(item.url, DICTIONARY_DOMAINS)) {
      score += DICT_INTENT.test(qn) ? 25 : -50;
    }
if (inDomains(item.url, MEDIA_PLOT_DOMAINS)) {
      score += MEDIA_INTENT.test(qn) ? 12 : -45;
    }
    const READER_INTENT = /(小说|漫画|连载|章节|无弹窗|在线阅读|全本小说|番剧)/;
    if (inDomains(item.url, READER_SPAM_DOMAINS)) {
      score += READER_INTENT.test(qn) ? 0 : -50;
    }
    // 标题层的影视/阅读聚合噪声（不依赖域名，误伤面更小）
    if (!MEDIA_INTENT.test(qn) && !READER_INTENT.test(qn) &&
        /(第[一二三四五六七八九十\d]+季|大结局|剧情简介|剧情中介|在线观看|免费在线|全集在线|免费阅读|下拉式|丧尸|韩剧|美剧|日剧|精彩速看|系列全收录)/.test(item.title)) {
      score -= 45;
    }
    // ---- 整片段命中检验（治拆词污染的主刀）----
    // bigram 会让「王国之泪」的拆词「王国」也算命中，所以改用"查询里的完整片段
    // （长度>=3）是否原样出现在结果中"来判定真相关。全部片段都不在 → 拆词污染，重罚。
    const segments = normalizeQuery(query).toLowerCase().split(/[^a-z0-9\u4e00-\u9fff]+/)
      .filter(function (s) { return s.length >= 3; });
    if (segments.length) {
      let segHit = 0;
      segments.forEach(function (seg) { if (combined.indexOf(seg) >= 0) segHit++; });
      // 只惩罚"查询里任何一个完整片段都没出现"的情况——这是拆词污染的确证特征。
      // 刻意不加"部分命中就扣分"的中间档：那会误伤只匹配到一个词的正常结果（含英文查询）。
      if (segHit === 0) score -= 55;
    }
    return score;
  }

  function mergeAndRank(rawItems, query, maxResults, strictQuality) {
    const frequency = {};
    rawItems.forEach(function (item) {
      const key = comparableUrl(item.url);
      if (key) frequency[key] = (frequency[key] || 0) + 1;
    });

    const seen = {};
    const selected = [];
    rawItems.forEach(function (item) {
      const key = comparableUrl(item.url);
      if (!key || seen[key]) return;
      seen[key] = true;
      if (strictQuality && inDomains(item.url, HARD_BLOCKED_DOMAINS)) return;
      const score = scoreItem(item, query, frequency);
      if (strictQuality && score < 8) return;
      if (strictQuality && inDomains(item.url, LOW_QUALITY_DOMAINS) && score < 28) return;
      selected.push({ title: item.title, url: item.url, snippet: item.snippet, engine: item.engine, score: score });
    });

    selected.sort(function (left, right) {
      if (right.score !== left.score) return right.score - left.score;
      return left.title.localeCompare(right.title);
    });
    return selected.slice(0, maxResults);
  }

  function limitSourceDiversity(items, maxPerHost) {
    const counts = {};
    return items.filter(function (item) {
      const host = hostOf(item.url);
      if (!host) return false;
      counts[host] = (counts[host] || 0) + 1;
      return counts[host] <= maxPerHost;
    });
  }

  function formatResults(query, items, engines, failures) {
    const lines = [
      "网页搜索：" + query,
      "来源：" + (engines.length ? engines.join("、") : "无") + " ｜ 已去重、按相关性与来源可信度排序·V2"
    ];
    if (failures.length) lines.push("未使用/失败引擎：" + failures.join("；"));
    lines.push("");

    if (!items.length) {
      lines.push("没有获得可用结果。请尝试换成更具体的关键词，或稍后重试。");
      return lines.join("\n");
    }

    items.forEach(function (item, index) {
      lines.push("[" + (index + 1) + "] " + item.title);
      lines.push("URL: " + item.url);
      if (item.snippet) lines.push("摘要: " + item.snippet);
      lines.push("来源: " + item.engine);
      lines.push("");
    });
    lines.push("提示：搜索工具不会自动打开以上网页；需要核实具体内容时，再使用 visit_web 访问相应 URL。");
    return lines.join("\n");
  }

  function parseEngines(value, defaults, limit) {
    const candidates = normalizeQuery(value || defaults.join(",")).split(",").map(function (engine) {
      return engine.trim().toLowerCase();
    }).filter(Boolean);
    const engines = [];
    candidates.forEach(function (engine) {
      if (SUPPORTED_ENGINES.indexOf(engine) >= 0 && engines.indexOf(engine) < 0) engines.push(engine);
    });
    return (engines.length ? engines : defaults).slice(0, limit);
  }

  async function searchEngine(engine, query) {
    if (engine === "google") return searchGoogleStructured(query);
    // Bing 一律先走 RSS 端点：2026-09-07 实测 HTML 端点已改为 JS 渐进式渲染，
    // 无浏览器客户端只能拿到空结果容器（英文/中文均验证）。RSS 失败时回退 HTML 兜底。
    if (engine === "bing") {
      try {
        const rssItems = await fetchBingRss(query);
        if (rssItems.length) return rssItems;
      } catch (_) { /* 回退 HTML */ }
    }
    if (engine === "anysearch") return fetchAnySearch(query, 10);
    const html = await fetchHtml(engine, query);
    const items = parseResults(engine, html);
    if (!items.length) throw new Error("未解析到结果");
    return items;
  }

  async function searchWithFallback(query, engines, maxResults) {
    const normalizedQuery = normalizeQuery(query);
    if (!normalizedQuery) return { platform: "search", content: "搜索失败：搜索关键词不能为空。" };

    const failures = [];
    for (let index = 0; index < engines.length; index++) {
      const engine = engines[index];
      try {
        const ranked = mergeAndRank(await searchEngine(engine, normalizedQuery), normalizedQuery, maxResults, true);
        if (ranked.length) return { platform: engine, content: formatResults(normalizedQuery, ranked, [engine], failures) };
        failures.push(engine + "：结果质量不足");
      } catch (error) {
        failures.push(engine + "：" + asText(error && error.message ? error.message : error));
      }
    }
    return { platform: "search", content: formatResults(normalizedQuery, [], [], failures) };
  }

  async function searchAcrossEngines(query, engines, maxResults) {
    const normalizedQuery = normalizeQuery(query);
    if (!normalizedQuery) return [{ platform: "search", content: "搜索失败：搜索关键词不能为空。" }];

    // Google occasionally returns a challenge/empty page in this runtime. Keep the
    // requested pair lightweight, but use Bing as a deterministic second source then.
    if (engines.length === 2 && engines[0] === "duckduckgo" && engines[1] === "google") {
      engines = ["duckduckgo", "bing"];
    }

    const settled = await Promise.all(engines.map(async function (engine) {
      try {
        return { engine: engine, items: await searchEngine(engine, normalizedQuery), error: "" };
      } catch (error) {
        return { engine: engine, items: [], error: asText(error && error.message ? error.message : error) };
      }
    }));

    const rawItems = [];
    const used = [];
    const failures = [];
    settled.forEach(function (result) {
      if (result.items.length) {
        used.push(result.engine);
        Array.prototype.push.apply(rawItems, result.items);
      } else {
        failures.push(result.engine + "：" + (result.error || "未返回结果"));
      }
    });

    const ranked = limitSourceDiversity(mergeAndRank(rawItems, normalizedQuery, maxResults * 2, true), 2).slice(0, maxResults);
    return [{ platform: "combined", content: formatResults(normalizedQuery, ranked, used, failures) }];
  }

  async function searchOne(engine, query, maxResults) {
    const normalizedQuery = normalizeQuery(query);
    if (!normalizedQuery) return { platform: engine, content: "搜索失败：搜索关键词不能为空。" };
    try {
      const ranked = mergeAndRank(await searchEngine(engine, normalizedQuery), normalizedQuery, maxResults, true);
      return { platform: engine, content: formatResults(normalizedQuery, ranked, [engine], []) };
    } catch (error) {
      return { platform: engine, content: engine + " 搜索失败: " + asText(error && error.message ? error.message : error) };
    }
  }

  async function search_bing(query, includeLinks) { return searchOne("bing", query, 8); }
  // Google is queried via Tools.Net.visit because raw HTTP commonly receives a
  // JavaScript challenge in this runtime. Brave remains a safe Bing compatibility alias.
  async function search_google(query, includeLinks) { return searchOne("google", query, 8); }
  async function search_brave(query, includeLinks) { return searchOne("bing", query, 8); }
  async function search_startpage(query, includeLinks) { return searchWithFallback(query, ["duckduckgo"], 8); }
  async function search(query, platforms, includeLinks) {
    return withTimeout(
      searchWithFallback(query, parseEngines(platforms, DEFAULT_ENGINES, 3), 6),
      TOTAL_FALLBACK_TIMEOUT_MS,
      "搜索"
    ).catch(function (error) {
      return { platform: "search", content: "搜索暂时超时，请稍后重试或换一个关键词。" };
    });
  }
  async function search_web(query, maxResults, platforms, includeLinks) {
    // Older chats may still send the engine list in max_results. Accept both forms.
    const legacyPlatforms = typeof maxResults === "string" && /[a-z]/i.test(maxResults) ? maxResults : "";
    const requestedPlatforms = asText(platforms || legacyPlatforms).trim();
    const engines = requestedPlatforms ? parseEngines(requestedPlatforms, DEFAULT_ENGINES, 3) : DEFAULT_ENGINES;
    const limit = legacyPlatforms ? 6 : clamp(maxResults, 6, 1, 10);
    return withTimeout(
      searchWithFallback(query, engines, limit),
      TOTAL_FALLBACK_TIMEOUT_MS,
      "网页搜索"
    ).catch(function (error) {
      return { platform: "search", content: "网页搜索暂时超时，请稍后重试或换一个关键词。" };
    });
  }
  async function combined_search(query, platforms, includeLinks) {
    return withTimeout(
      searchAcrossEngines(query, parseEngines(platforms, ["duckduckgo", "bing"], 2), 8),
      TOTAL_FALLBACK_TIMEOUT_MS,
      "交叉搜索"
    ).catch(function (error) {
      return [{ platform: "combined", content: "交叉搜索暂时超时，请改用普通网页搜索或稍后重试。" }];
    });
  }
function communityScore(url) {
    const host = hostOf(url);
    let score = 0;
    Object.keys(COMMUNITY_DOMAIN_SCORES).forEach(function (domain) {
      if (domainMatches(host, domain)) score = Math.max(score, COMMUNITY_DOMAIN_SCORES[domain]);
    });
    return score;
  }

  function scoreReviewItem(item, query, frequency) {
    const combined = (item.title + " " + item.snippet + " " + item.url).toLowerCase();
    const rawTitle = item.title;
    let score = 20 + communityScore(item.url);

    queryTokens(query).forEach(function (token) {
      if (item.title.toLowerCase().indexOf(token) >= 0) score += 10;
      else if (combined.indexOf(token) >= 0) score += 4;
    });

    // Reward posts that read like genuine ownership reports.
    let authenticHits = 0;
    AUTHENTIC_WORDS.forEach(function (word) {
      if (combined.indexOf(word.toLowerCase()) >= 0) authenticHits++;
    });
    score += Math.min(24, authenticHits * 8);

    // Penalise hype/templated marketing titles.
    let hypeHits = 0;
    HYPE_WORDS.forEach(function (word) {
      if (rawTitle.indexOf(word) >= 0) hypeHits += 2;
      else if (combined.indexOf(word.toLowerCase()) >= 0) hypeHits += 1;
    });
    score -= hypeHits * 14;

    LOW_VALUE_WORDS.forEach(function (word) {
      if (combined.indexOf(word) >= 0) score -= 20;
    });

    // Penalise vendor/official pages in review mode: titles or URLs containing
    // download/official/FAQ/news/blog keywords on non-community domains are
    // almost always manufacturer marketing, not genuine user feedback.
    var VENDOR_SIGNALS = ["官网", "官方", "下载", "download", "安装", "教程", "教学",
      "使用方法", "使用指南", "设置", "教程", "配置", "faq", "帮助",
      "news", "blog", "公告", "资讯", "产品介绍", "功能介绍", "优势", "特点",
      "促销", "优惠", "福利", "活动", "新品", "首发"];
    var isVendorPage = communityScore(item.url) === 0;
    if (isVendorPage) {
      var vendorHits = 0;
      VENDOR_SIGNALS.forEach(function (signal) {
        if (combined.indexOf(signal.toLowerCase()) >= 0) vendorHits++;
      });
      if (vendorHits >= 2) score -= 25;
      else if (vendorHits === 1) score -= 12;
    }

    // Exclamation-heavy Chinese SEO titles are almost always templated content.
    if (/[!！]{1,}$/.test(rawTitle.trim())) score -= 12;
    if (inDomains(item.url, LOW_QUALITY_DOMAINS)) score -= 10;
    if (frequency[comparableUrl(item.url)] > 1) score += 10;
    if (item.snippet.length >= 60) score += 3;
    return score;
  }

  function rankReviewItems(rawItems, query, maxResults) {
    const frequency = {};
    rawItems.forEach(function (item) {
      const key = comparableUrl(item.url);
      if (key) frequency[key] = (frequency[key] || 0) + 1;
    });

    const seen = {};
    const selected = [];
    rawItems.forEach(function (item) {
      const key = comparableUrl(item.url);
      if (!key || seen[key]) return;
      seen[key] = true;
      if (inDomains(item.url, HARD_BLOCKED_DOMAINS)) return;
      if (inDomains(item.url, REVIEW_BLOCKED_DOMAINS)) return;
      if (!isOnTopic(item, query)) return;
      const score = scoreReviewItem(item, query, frequency);
      if (score < 10) return;
      selected.push({
        title: item.title,
        url: item.url,
        snippet: item.snippet,
        engine: item.engine,
        score: score,
        community: communityScore(item.url) > 0
      });
    });

    selected.sort(function (left, right) {
      if (right.score !== left.score) return right.score - left.score;
      return left.title.localeCompare(right.title);
    });
    return limitSourceDiversity(selected, 2).slice(0, maxResults);
  }
  function buildReviewQueries(query, aspect) {
    const base = normalizeQuery(query);
    const focus = normalizeQuery(aspect);
    const suffix = focus ? " " + focus : "";
    // Tighten CJK queries (黑神话 悟空 -> 黑神话悟空) so engines do not split
    // the product name into single characters.
    const tightened = base.replace(/[\u4e00-\u9fff]+/g, function (run) {
      return run;
    }).replace(/[ \t]+/g, " ").replace(/([\u4e00-\u9fff]+) ([\u4e00-\u9fff]+)/g, "$1$2");
    return [
      tightened + suffix + " 缺点 真实体验",
      base + suffix + " 论坛 吐槽 后悔",
      base + suffix + " reddit user problems complaints"
    ];
  }

  // Guard against a degraded engine returning results that no longer match the
  // product at all (observed: the token "红" from 红米 matching dictionary pages).
  function productKeywords(query) {
    const text = normalizeQuery(query).toLowerCase();
    const keywords = [];

    // Latin/number runs such as "airpods", "k80", "rtx", "5070".
    (text.match(/[a-z0-9][a-z0-9.+-]*/g) || []).forEach(function (piece) {
      if (piece.length >= 2) keywords.push(piece);
    });

    // CJK runs contribute whole runs, adjacent bigrams, and merged adjacent runs
    // (黑神话 + 悟空 -> 黑神话悟空), never single chars, so a one-character
    // overlap can no longer qualify as a match.
    const cjkRuns = text.match(/[\u4e00-\u9fff]+/g) || [];
    cjkRuns.forEach(function (run) {
      if (run.length >= 2) {
        keywords.push(run);
        for (let index = 0; index + 1 < run.length; index++) {
          keywords.push(run.slice(index, index + 2));
        }
      }
    });
    if (cjkRuns.length >= 2) {
      const merged = cjkRuns.join("");
      if (merged.length >= 2) keywords.push(merged);
    }

    return keywords.filter(function (token, index) {
      return keywords.indexOf(token) === index;
    });
  }

  function isOnTopic(item, query) {
    const keywords = productKeywords(query);
    if (!keywords.length) return true;
    const haystack = (item.title + " " + item.snippet + " " + item.url).toLowerCase();
    return keywords.some(function (keyword) {
      return haystack.indexOf(keyword) >= 0;
    });
  }


  function formatReviewResults(query, aspect, items, used, failures) {
    const lines = [
      "真实口碑搜索：" + normalizeQuery(query) + (aspect ? "（关注点：" + normalizeQuery(aspect) + "）" : ""),
      "来源：" + (used.length ? used.join("、") : "无") + " ｜ 已拦截导购页与标题党软文，优先真实用户讨论"
    ];
    if (failures.length) lines.push("降级说明：" + failures.join("；"));
    lines.push("");

    if (!items.length) {
      lines.push("没有找到足够可信的用户讨论。可以换成更具体的型号，或补充想了解的方面（如续航、发热、做工）。");
      return lines.join("\n");
    }

    items.forEach(function (item, index) {
      lines.push("[" + (index + 1) + "] " + item.title + (item.community ? "　【用户社区】" : ""));
      lines.push("URL: " + item.url);
      if (item.snippet) lines.push("摘要: " + item.snippet);
      lines.push("");
    });
    lines.push("提示：以上偏向真实使用者反馈，个别负面案例不代表普遍质量；需要确认具体问题时，可用 verify_sources 打开原帖核对。");
    return lines.join("\n");
  }

  async function search_reviews(query, aspect, maxResults) {
    const normalizedQuery = normalizeQuery(query);
    if (!normalizedQuery) return { platform: "reviews", content: "口碑搜索失败：请提供产品名称或型号。" };
    const limit = clamp(maxResults, 8, 1, 12);
    const variants = buildReviewQueries(normalizedQuery, aspect);

    // Firing every engine at once starved the connection pool and made all but one
    // engine time out. Stage 1 covers CN community coverage with Bing + DDG; if the
    // ranked pool is still thin, stage 2 adds one Google sweep for Reddit/Steam etc.
    const stages = [
      [
        { engine: "bing", query: variants[0] },
        { engine: "duckduckgo", query: variants[1] }
      ],
      [
        { engine: "google", query: variants[2] }
      ]
    ];

    const rawItems = [];
    const used = [];
    const failures = [];

    for (let stageIndex = 0; stageIndex < stages.length; stageIndex++) {
      const settled = await Promise.all(stages[stageIndex].map(async function (plan) {
        try {
          return { engine: plan.engine, items: await searchEngine(plan.engine, plan.query), error: "" };
        } catch (error) {
          return { engine: plan.engine, items: [], error: asText(error && error.message ? error.message : error) };
        }
      }));

      settled.forEach(function (result) {
        if (result.items.length) {
          if (used.indexOf(result.engine) < 0) used.push(result.engine);
          Array.prototype.push.apply(rawItems, result.items);
        } else if (result.error) {
          failures.push(result.engine + "：" + result.error);
        }
      });

      // Enough on-topic community material already; skip the extra round trip.
      if (rankReviewItems(rawItems, normalizedQuery, limit).length >= limit) break;
    }

    const ranked = rankReviewItems(rawItems, normalizedQuery, limit);
    return { platform: "reviews", content: formatReviewResults(normalizedQuery, aspect, ranked, used, failures) };
  }

async function search_clean(query, platforms, maxResults) {
    return withTimeout(
      searchAcrossEngines(query, parseEngines(platforms, QUALITY_ENGINES, 3), clamp(maxResults, 6, 1, 10)),
      TOTAL_FALLBACK_TIMEOUT_MS,
      "高质量搜索"
    ).catch(function (error) {
      return [{ platform: "combined", content: "高质量搜索暂时超时，请改用普通网页搜索或稍后重试。" }];
    });
  }

  function isPreferredVerificationSource(item, query) {
    const host = hostOf(item.url);
    if (!host || inDomains(item.url, HARD_BLOCKED_DOMAINS)) return false;
    if (sourceScore(item.url) >= 22) return true;
    const q = normalizeQuery(query).toLowerCase();
    if (/(官网|官方|文档|api|docs|documentation|论文|学术|research|paper|政策|公告|news)/i.test(q)) {
      return sourceScore(item.url) >= 15;
    }
    return !inDomains(item.url, LOW_QUALITY_DOMAINS);
  }

  function chooseVerificationCandidates(items, query, maxSources) {
    const candidates = [];
    const seenHosts = {};
    items.forEach(function (item) {
      const host = hostOf(item.url);
      if (!host || seenHosts[host] || !isPreferredVerificationSource(item, query)) return;
      seenHosts[host] = true;
      candidates.push(item);
    });
    return candidates.slice(0, maxSources);
  }

  function extractRelevantExcerpt(content, query, maxLength) {
    const text = asText(content).replace(/\s+/g, " ").trim();
    if (!text) return "未提取到可读正文。";
    const tokens = queryTokens(query);
    let bestIndex = -1;
    for (let index = 0; index < tokens.length; index++) {
      const position = text.toLowerCase().indexOf(tokens[index].toLowerCase());
      if (position >= 0) { bestIndex = position; break; }
    }
    if (bestIndex < 0) return text.slice(0, maxLength);
    const start = Math.max(0, bestIndex - Math.floor(maxLength * 0.25));
    const end = Math.min(text.length, start + maxLength);
    return (start > 0 ? "…" : "") + text.slice(start, end) + (end < text.length ? "…" : "");
  }

  async function verify_sources(query, platforms, maxSources) {
    const normalizedQuery = normalizeQuery(query);
    if (!normalizedQuery) return { platform: "verify", content: "核验失败：搜索关键词不能为空。" };
    const sourceLimit = clamp(maxSources, 2, 1, 2);
    const engines = parseEngines(platforms, QUALITY_ENGINES, 3);
    let rawItems = [];
    let used = [];
    const failures = [];

    const settled = await withTimeout(Promise.all(engines.map(async function (engine) {
      try { return { engine: engine, items: await searchEngine(engine, normalizedQuery), error: "" }; }
      catch (error) { return { engine: engine, items: [], error: asText(error && error.message ? error.message : error) }; }
    })), TOTAL_FALLBACK_TIMEOUT_MS, "核验搜索");

    settled.forEach(function (result) {
      if (result.items.length) {
        used.push(result.engine);
        Array.prototype.push.apply(rawItems, result.items);
      } else {
        failures.push(result.engine + "：" + (result.error || "未返回结果"));
      }
    });

    const ranked = limitSourceDiversity(mergeAndRank(rawItems, normalizedQuery, 12, true), 1);
    const candidates = chooseVerificationCandidates(ranked, normalizedQuery, sourceLimit);
    if (!candidates.length) {
      return { platform: "verify", content: formatResults(normalizedQuery, [], used, failures.concat(["没有满足核验条件的可信来源"])) };
    }

    // Return candidate URLs for browser-based verification in the conversation layer.
    // The sandbox Tools.Net.visit cannot handle login walls or JS-heavy pages,
    // so actual page access is delegated to the browser package via package_proxy.
    const lines = [
      "核验候选来源：" + normalizedQuery,
      "搜索来源：" + (used.length ? used.join("、") : "无"),
      ""
    ];
    if (failures.length) lines.push("搜索降级：" + failures.join("；"), "");
    lines.push("请用 browser 包依次访问以下URL获取原文：");
    lines.push("");
    candidates.forEach(function (item, index) {
      lines.push("[" + (index + 1) + "] " + item.title);
      lines.push("URL: " + item.url);
      lines.push("分数: " + item.score);
      lines.push("");
    });
    lines.push("说明：以上为核验候选来源，需用浏览器访问获取真实内容。");
    return { platform: "verify", content: lines.join("\n") };
  }

  // Old engine names
  // Old engine names are deliberately retained as safe disabled aliases so an old model
  // cannot silently fall back to a forbidden search provider.
  async function search_baidu() { return { platform: "baidu", content: "百度搜索已禁用。请使用 DuckDuckGo、Google 或 Bing。" }; }
  async function search_sogou() { return { platform: "sogou", content: "搜狗搜索已禁用。请使用 DuckDuckGo、Google 或 Bing。" }; }
  async function search_quark() { return { platform: "quark", content: "夸克搜索已禁用。请使用 DuckDuckGo、Google 或 Bing。" }; }

  async function performImageSearch(platform, url) {
    try {
      const response = await withTimeout(
        Tools.Net.visit({ url: url, include_image_links: true, user_agent_preset: "android" }),
        IMAGE_TIMEOUT_MS,
        platform + " 图片搜索"
      );
      if (!response) throw new Error("无法获取图片搜索结果");
      const parts = [];
      if (response.visitKey !== undefined) parts.push("visit_key: " + response.visitKey);
      const images = Array.isArray(response.imageLinks) ? response.imageLinks : [];
      if (images.length) {
        parts.push("Images:");
        images.slice(0, 20).forEach(function (image, index) {
          const name = asText(image).split("/").pop().split("?")[0] || "image";
          parts.push("[" + (index + 1) + "] " + name);
        });
      }
      if (response.content) parts.push(asText(response.content).slice(0, 4000));
      return { platform: platform, content: parts.join("\n") || "未获得图片结果" };
    } catch (error) {
      return { platform: platform, content: platform + " 图片搜索失败: " + asText(error && error.message ? error.message : error) };
    }
  }

  async function search_bing_images(query) {
    return performImageSearch("bing_images", "https://www.bing.com/images/search?q=" + encodeURIComponent(normalizeQuery(query)));
  }
  async function search_wikimedia_images(query) {
    return performImageSearch("wikimedia_images", "https://commons.wikimedia.org/wiki/Special:MediaSearch?type=image&search=" + encodeURIComponent(normalizeQuery(query)));
  }
  async function search_duckduckgo_images(query) {
    return performImageSearch("duckduckgo_images", "https://duckduckgo.com/?q=" + encodeURIComponent(normalizeQuery(query)) + "&iax=images&ia=images");
  }
  async function search_ecosia_images(query) {
    return performImageSearch("ecosia_images", "https://www.ecosia.org/images?q=" + encodeURIComponent(normalizeQuery(query)));
  }
  async function search_pexels_images(query) {
    return performImageSearch("pexels_images", "https://www.pexels.com/search/" + encodeURIComponent(normalizeQuery(query)) + "/");
  }
  async function search_pixabay_images(query) {
    return performImageSearch("pixabay_images", "https://pixabay.com/images/search/" + encodeURIComponent(normalizeQuery(query)) + "/");
  }

  function wrap(fn, parameterNames) {
    return async function (params) {
      params = params || {};
      return fn.apply(null, parameterNames.map(function (name) { return params[name]; }));
    };
  }

  async function main() {
    return search_clean("Operit AI GitHub official repository", "google,bing", 3);
  }

  return {
    search_bing: search_bing,
    search_google: search_google,
    search_brave: search_brave,
    search_startpage: search_startpage,
    search_baidu: search_baidu,
    search_sogou: search_sogou,
    search_quark: search_quark,
    search: search,
    search_web: search_web,
    combined_search: combined_search,
    search_clean: search_clean,
    search_reviews: search_reviews,
    verify_sources: verify_sources,
    search_bing_images: search_bing_images,
    search_wikimedia_images: search_wikimedia_images,
    search_duckduckgo_images: search_duckduckgo_images,
    search_ecosia_images: search_ecosia_images,
    search_pexels_images: search_pexels_images,
    search_pixabay_images: search_pixabay_images,
    wrap: wrap,
    main: main
  };
})();

exports.search_bing = various_search.wrap(various_search.search_bing, ["query", "includeLinks"]);
exports.search_google = various_search.wrap(various_search.search_google, ["query", "includeLinks"]);
exports.search_brave = various_search.wrap(various_search.search_brave, ["query", "includeLinks"]);
exports.search_startpage = various_search.wrap(various_search.search_startpage, ["query", "includeLinks"]);
exports.search_baidu = various_search.wrap(various_search.search_baidu, ["query", "page", "includeLinks"]);
exports.search_sogou = various_search.wrap(various_search.search_sogou, ["query", "page", "includeLinks"]);
exports.search_quark = various_search.wrap(various_search.search_quark, ["query", "page", "includeLinks"]);
exports.search = various_search.wrap(various_search.search, ["query", "platforms", "includeLinks"]);
exports.search_web = various_search.wrap(various_search.search_web, ["query", "max_results", "platforms", "includeLinks"]);
exports.combined_search = various_search.wrap(various_search.combined_search, ["query", "platforms", "includeLinks"]);
exports.search_clean = various_search.wrap(various_search.search_clean, ["query", "platforms", "max_results"]);
exports.search_reviews = various_search.wrap(various_search.search_reviews, ["query", "aspect", "max_results"]);
exports.verify_sources = various_search.wrap(various_search.verify_sources, ["query", "platforms", "max_sources"]);
exports.search_bing_images = various_search.wrap(various_search.search_bing_images, ["query"]);
exports.search_wikimedia_images = various_search.wrap(various_search.search_wikimedia_images, ["query"]);
exports.search_duckduckgo_images = various_search.wrap(various_search.search_duckduckgo_images, ["query"]);
exports.search_ecosia_images = various_search.wrap(various_search.search_ecosia_images, ["query"]);
exports.search_pexels_images = various_search.wrap(various_search.search_pexels_images, ["query"]);
exports.search_pixabay_images = various_search.wrap(various_search.search_pixabay_images, ["query"]);
exports.main = various_search.main;