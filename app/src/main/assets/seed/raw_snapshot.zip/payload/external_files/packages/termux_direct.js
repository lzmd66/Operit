/*
METADATA
{
    "name": "termux_direct",
    "description": "Termux 直驱技能包：经本机执行服务器（127.0.0.1:8888/cmd, X-Token 认证）远程执行命令。主力移动 Linux 环境（2026-09-15 同题对决转正）。Termux 未开时返回明确指引（打开 Termux 即自启动 8888 服务器）。",
    "tools": [
        {
            "name": "exec",
            "description": "在 Termux 内执行 bash 命令并返回完整输出。注意：Termux 无 /sdcard 读权限，脚本请用 heredoc 写入 ~/ 后运行。",
            "parameters": [
                { "name": "command", "description": "要执行的 bash 命令文本（完整命令，如 python3 ~/x.py）", "type": "string", "required": true },
                { "name": "timeout_ms", "description": "超时毫秒，默认 60000，最大 115000（服务器端执行超时 120s）", "type": "number", "required": false }
            ]
        },
        {
            "name": "status",
            "description": "健康检查：探测 Termux 8888 执行服务器是否在线，返回存活状态与 Python 版本。",
            "parameters": []
        }
    ]
}
*/

const termux_directPackage = (function () {
    const URL = "http://127.0.0.1:8888/cmd";
    const TOKEN = "opx-20260914";

    async function postCmd(cmd, timeoutMs) {
        const resp = await Tools.Net.http({
            url: URL,
            method: "POST",
            headers: { "X-Token": TOKEN },
            body: String(cmd),
            follow_redirects: true,
            connect_timeout: 5000,
            read_timeout: timeoutMs,
            validateStatus: false
        });
        const code = resp && resp.statusCode != null ? resp.statusCode : (resp && resp.status) || 0;
        const text = resp && typeof resp.content === "string" ? resp.content : "";
        return { ok: code >= 200 && code < 300, code: code, output: text };
    }

    async function exec(params) {
        params = params || {};
        const cmd = params.command;
        if (!cmd || !String(cmd).trim()) {
            return { success: false, error: "command 不能为空" };
        }
        let t = Number(params.timeout_ms);
        if (!t || t < 3000) { t = 60000; }
        if (t > 115000) { t = 115000; }
        try {
            const res = await postCmd(cmd, t);
            return {
                success: res.ok,
                output: res.output,
                http_code: res.code,
                hint: res.ok ? null : "HTTP " + res.code + "：Termux 执行服务器异常（若拒连=Termux 已死，请用户打开 Termux App，自启会拉起 8888 服务器）"
            };
        } catch (e) {
            return {
                success: false,
                output: null,
                hint: "拒连/超时：" + String(e) + " —— Termux 大概率已死（后台冻结或被刷掉），请用户打开 Termux App（bashrc 自启会拉起 8888 服务器），然后重试"
            };
        }
    }

    async function status(params) {
        try {
            const res = await postCmd("echo __TD_ALIVE__; python3 --version", 10000);
            const alive = res.ok && res.output.indexOf("__TD_ALIVE__") >= 0;
            return {
                success: alive,
                alive: alive,
                detail: alive ? res.output.replace("__TD_ALIVE__\n", "").trim() : "HTTP " + res.code,
                hint: alive ? null : "服务器无响应：Termux 已死或执行服务器未启动，请用户打开 Termux App"
            };
        } catch (e) {
            return {
                success: false,
                alive: false,
                detail: null,
                hint: "拒连：" + String(e) + " —— Termux 未运行，请用户打开 Termux App"
            };
        }
    }

    return { exec: exec, status: status };
})();

exports.exec = termux_directPackage.exec;
exports.status = termux_directPackage.status;