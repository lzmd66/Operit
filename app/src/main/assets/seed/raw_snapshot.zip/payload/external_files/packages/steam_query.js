/*
METADATA
{
    "name": "steam_query",
    "description": "Steam 商店查询（纯 JS 沙盒）：按名搜索、App 详情/价格、当前在线人数。走 Valve 公开 Store API，默认国区(CN)，无需 API Key。内置三栈降级：Tools.Net.http → OkHttp → DoH 解析真 IP + IP 直连（绕 DNS 污染），每栈自守卫超时，坏网络日不挂死。",
    "tools": [
        {
            "name": "search_game",
            "description": "按游戏名搜索 Steam 商店，返回 AppID、名称、价格、类型等。",
            "parameters": [
                {
                    "name": "query",
                    "description": "游戏名关键词，例如 Elden Ring / 艾尔登法环",
                    "type": "string",
                    "required": true
                },
                {
                    "name": "cc",
                    "description": "国家/地区码，默认 CN。如 US/JP/HK/TW",
                    "type": "string",
                    "required": false
                },
                {
                    "name": "lang",
                    "description": "语言，默认 schinese。可选 english / tchinese 等",
                    "type": "string",
                    "required": false
                },
                {
                    "name": "limit",
                    "description": "最多返回条数，默认 10，最大 25",
                    "type": "number",
                    "required": false
                }
            ]
        },
        {
            "name": "get_app_details",
            "description": "按 AppID 获取商店详情：简介、类型、发售日、开发商、价格/折扣、metacritic、是否免费等。",
            "parameters": [
                {
                    "name": "appid",
                    "description": "Steam AppID，例如 1245620",
                    "type": "string",
                    "required": true
                },
                {
                    "name": "cc",
                    "description": "国家/地区码，默认 CN",
                    "type": "string",
                    "required": false
                },
                {
                    "name": "lang",
                    "description": "语言，默认 schinese",
                    "type": "string",
                    "required": false
                }
            ]
        },
        {
            "name": "get_price",
            "description": "按 AppID 或游戏名查当前价格与折扣（名搜索时取最相关一条）。",
            "parameters": [
                {
                    "name": "appid",
                    "description": "Steam AppID（与 query 二选一，优先 appid）",
                    "type": "string",
                    "required": false
                },
                {
                    "name": "query",
                    "description": "游戏名（未给 appid 时使用）",
                    "type": "string",
                    "required": false
                },
                {
                    "name": "cc",
                    "description": "国家/地区码，默认 CN",
                    "type": "string",
                    "required": false
                },
                {
                    "name": "lang",
                    "description": "语言，默认 schinese",
                    "type": "string",
                    "required": false
                }
            ]
        },
        {
            "name": "get_player_count",
            "description": "查询某 App 当前在线玩家数（公开接口，无需 Key）。",
            "parameters": [
                {
                    "name": "appid",
                    "description": "Steam AppID",
                    "type": "string",
                    "required": true
                }
            ]
        },
        {
            "name": "lookup",
            "description": "一站式：按游戏名搜索并取首条详情+价格+在线人数。适合「查一下某某游戏」。",
            "parameters": [
                {
                    "name": "query",
                    "description": "游戏名",
                    "type": "string",
                    "required": true
                },
                {
                    "name": "cc",
                    "description": "国家/地区码，默认 CN",
                    "type": "string",
                    "required": false
                },
                {
                    "name": "lang",
                    "description": "语言，默认 schinese",
                    "type": "string",
                    "required": false
                }
            ]
        }
    ]
}
*/

// ===================== 配置 =====================
const PKG = "steam_query";
const DEFAULT_CC = "CN";
const DEFAULT_LANG = "schinese";
const UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36 OperitSteamQuery/1.0";

// ===================== 基础 =====================
function ok(data, message) {
  const payload = { success: true, message: message || "ok", data: data };
  if (typeof complete === "function") complete(payload);
  return payload;
}

function fail(message, extra) {
  const payload = Object.assign({ success: false, message: String(message || "error") }, extra || {});
  if (typeof complete === "function") complete(payload);
  return payload;
}

function clamp(n, a, b) {
  n = Number(n);
  if (!isFinite(n)) return a;
  return Math.max(a, Math.min(b, n));
}

function nowIso() {
  return new Date().toISOString();
}

function str(v) {
  return v == null ? "" : String(v);
}

function normalizeCc(cc) {
  const c = str(cc || DEFAULT_CC).trim().toUpperCase();
  return c || DEFAULT_CC;
}

function normalizeLang(lang) {
  const l = str(lang || DEFAULT_LANG).trim().toLowerCase();
  return l || DEFAULT_LANG;
}

function encodeQ(s) {
  return encodeURIComponent(str(s));
}

function centsToDisplay(priceObj) {
  if (!priceObj || typeof priceObj !== "object") return null;
  const currency = priceObj.currency || "";
  const final = priceObj.final;
  const initial = priceObj.initial;
  const discount = priceObj.discount_percent;
  function fmt(cents) {
    if (cents == null || !isFinite(Number(cents))) return null;
    const n = Number(cents) / 100;
    if (currency === "CNY" || currency === "RMB") return "¥" + n.toFixed(2);
    if (currency === "USD") return "$" + n.toFixed(2);
    if (currency === "JPY") return "¥" + Math.round(n);
    if (currency === "EUR") return "€" + n.toFixed(2);
    return n.toFixed(2) + " " + currency;
  }
  return {
    currency: currency,
    initial_cents: initial,
    final_cents: final,
    initial: fmt(initial),
    final: fmt(final),
    discount_percent: discount == null ? 0 : Number(discount),
    free: !!(priceObj && (final === 0 || priceObj.final === 0))
  };
}

function mapSearchItem(it) {
  if (!it) return null;
  const price = it.price || null;
  let price_info = null;
  if (price) {
    // storesearch 的 price 字段：currency, initial, final, discount_percent（单位分）
    price_info = centsToDisplay({
      currency: price.currency,
      initial: price.initial,
      final: price.final,
      discount_percent: price.discount_percent
    });
  }
  return {
    appid: it.id != null ? Number(it.id) : (it.appid != null ? Number(it.appid) : null),
    name: it.name || "",
    type: it.type || "",
    tiny_image: it.tiny_image || it.img || "",
    price: price_info,
    metascore: it.metascore != null ? it.metascore : null,
    platforms: it.platforms || null,
    controller_support: it.controller_support || null
  };
}

function pickAppData(appdetailsJson, appid) {
  if (!appdetailsJson || typeof appdetailsJson !== "object") return null;
  const key = str(appid);
  const node = appdetailsJson[key] || appdetailsJson[Number(key)];
  if (!node || !node.success || !node.data) return null;
  return node.data;
}

function summarizeApp(data, appid, cc, lang) {
  if (!data) return null;
  const price_overview = data.price_overview || null;
  const price = centsToDisplay(price_overview);
  const is_free = !!data.is_free;
  const genres = Array.isArray(data.genres)
    ? data.genres.map(function (g) { return g.description || g; })
    : [];
  const categories = Array.isArray(data.categories)
    ? data.categories.map(function (c) { return c.description || c; }).slice(0, 12)
    : [];
  const developers = Array.isArray(data.developers) ? data.developers : [];
  const publishers = Array.isArray(data.publishers) ? data.publishers : [];
  const platforms = data.platforms || {};
  const release = data.release_date || {};
  const metacritic = data.metacritic || null;
  const screenshots = Array.isArray(data.screenshots)
    ? data.screenshots.slice(0, 5).map(function (s) {
        return s.path_full || s.path_thumbnail || "";
      }).filter(Boolean)
    : [];

  return {
    appid: Number(appid),
    name: data.name || "",
    type: data.type || "",
    is_free: is_free,
    short_description: data.short_description || "",
    header_image: data.header_image || "",
    website: data.website || "",
    developers: developers,
    publishers: publishers,
    genres: genres,
    categories: categories,
    platforms: {
      windows: !!platforms.windows,
      mac: !!platforms.mac,
      linux: !!platforms.linux
    },
    release_date: {
      coming_soon: !!release.coming_soon,
      date: release.date || ""
    },
    metacritic: metacritic
      ? { score: metacritic.score, url: metacritic.url || "" }
      : null,
    price: is_free
      ? { free: true, final: "免费", discount_percent: 0, currency: (price && price.currency) || "" }
      : price,
    recommendations: data.recommendations && data.recommendations.total
      ? Number(data.recommendations.total)
      : null,
    required_age: data.required_age != null ? data.required_age : null,
    supported_languages: data.supported_languages
      ? String(data.supported_languages).replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().slice(0, 300)
      : "",
    store_url: "https://store.steampowered.com/app/" + appid + "/?cc=" + encodeQ(cc),
    screenshots: screenshots,
    cc: cc,
    lang: lang
  };
}

// ===================== HTTP =====================
const CONNECT_TIMEOUT_MS = 15000;
const HTTP_TRY_TIMEOUT_MS = 12000;
const DOH_TIMEOUT_MS = 4000;
const DOH_GRACE_MS = 500;
const IP_TRY_TIMEOUT_MS = 8000;
const MAX_DOH_IPS = 3;

const DOH_ENDPOINTS = [
  { name: "alidns", url: "https://dns.alidns.com/resolve?name={host}&type=A" },
  { name: "tencent", url: "https://doh.pub/dns-query?name={host}&type=A" },
  { name: "google", url: "https://dns.google/resolve?name={host}&type=A" }
];

function msgOf(e) { return e && e.message ? e.message : String(e); }

/** 给任意 Promise 加自守卫超时：到点即以 Error 拒绝，防止宿主层 timeout 参数不生效导致无限挂起。 */
function raceGuard(promise, ms, label) {
  return new Promise(function (resolve, reject) {
    let done = false;
    const timer = setTimeout(function () {
      if (!done) { done = true; reject(new Error("guard-timeout " + ms + "ms" + (label ? "（" + label + "）" : ""))); }
    }, ms);
    promise.then(function (v) {
      if (!done) { done = true; clearTimeout(timer); resolve(v); }
    }, function (e) {
      if (!done) { done = true; clearTimeout(timer); reject(e); }
    });
  });
}

function splitHttpsUrl(rawUrl) {
  const m = String(rawUrl).match(/^https:[/]{2}([^/?#]+)([/?#].*)?$/);
  if (!m) return null;
  const rest = m[2] ? m[2].replace(/^[/]/, "") : "";
  return { host: m[1], path: rest ? "/" + rest : "/" };
}

/** 查询单个 DoH 源（带自守卫超时，绝不无限挂起）。 */
function queryDohSource(source, host, timeoutMs) {
  const started = Date.now();
  const url = source.url.replace("{host}", encodeURIComponent(host));
  return raceGuard(Tools.Net.http({
    url: url,
    method: "GET",
    headers: { "User-Agent": UA, "Accept": "application/dns-json, application/json, */*" },
    connect_timeout: timeoutMs,
    read_timeout: timeoutMs,
    responseType: "text",
    validateStatus: false
  }), timeoutMs + 300, source.name).then(function (resp) {
    const ms = Date.now() - started;
    const text = resp && resp.content !== undefined ? resp.content : (resp ? resp.body : null);
    if (!text) return { name: source.name, ok: false, ms: ms, err: "空响应" };
    let data;
    try { data = JSON.parse(String(text)); } catch (e2) {
      return { name: source.name, ok: false, ms: ms, err: "非 JSON 响应" };
    }
    const answers = (data && data.Answer) || [];
    const ips = [];
    for (let j = 0; j < answers.length; j++) {
      const a = answers[j];
      if (a && a.type === 1 && a.data) ips.push(String(a.data));
    }
    return { name: source.name, ok: true, ms: ms, ips: ips };
  }, function (e) {
    return { name: source.name, ok: false, ms: Date.now() - started, err: msgOf(e) };
  });
}

/** 三源并行解析真 IP：拿到首个结果后再等 500ms 收集快源即返回，绝不等慢源/死源。 */
async function dohResolve(host) {
  const started = Date.now();
  const details = [];
  for (let i = 0; i < DOH_ENDPOINTS.length; i++) details.push({ name: DOH_ENDPOINTS[i].name, status: "pending" });
  let gotAny = false;
  let overall = null;
  const collected = await new Promise(function (resolve) {
    let pending = DOH_ENDPOINTS.length;
    let graceTimer = null;
    let finished = false;
    function finish(why) {
      if (finished) return;
      finished = true;
      if (graceTimer) clearTimeout(graceTimer);
      if (overall) clearTimeout(overall);
      const snap = [];
      for (let k = 0; k < details.length; k++) {
        const d = details[k];
        if (d.status === "pending") snap.push(Object.assign({}, d, { status: "skipped(" + why + ")" }));
        else snap.push(Object.assign({}, d));
      }
      resolve(snap);
    }
    overall = setTimeout(function () { finish("overall-cap"); }, DOH_TIMEOUT_MS + 800);
    DOH_ENDPOINTS.forEach(function (source, idx) {
      queryDohSource(source, host, DOH_TIMEOUT_MS).then(function (r) {
        if (finished) return;
        details[idx] = Object.assign({}, r, { status: "done" });
        if (r.ok && r.ips && r.ips.length > 0) gotAny = true;
        pending--;
        if (gotAny && !graceTimer) {
          graceTimer = setTimeout(function () { finish("first+grace"); }, DOH_GRACE_MS);
        }
        if (pending === 0) {
          clearTimeout(overall);
          finish("all-settled");
        }
      });
    });
  });
  const ips = [];
  const seen = {};
  for (let i = 0; i < collected.length; i++) {
    const srcIps = (collected[i] && collected[i].ips) || [];
    for (let j = 0; j < srcIps.length; j++) {
      if (!seen[srcIps[j]]) { seen[srcIps[j]] = 1; ips.push(srcIps[j]); }
    }
  }
  return { ips: ips, sources: collected, ms: Date.now() - started };
}

/** 统一提取响应文本（兼容 content/body/text/落盘文件/data 对象等形态）。 */
async function extractResp(resp) {
  if (resp == null) throw new Error("empty response");
  let text = "";
  const saved = resp.content_saved_to || (resp.data && resp.data.content_saved_to) || resp.output_saved_to || "";
  if (saved && Tools.Files && typeof Tools.Files.read === "function") {
    try {
      let r;
      try { r = await Tools.Files.read({ path: saved, environment: "android" }); }
      catch (e1) { r = await Tools.Files.read(saved); }
      if (typeof r === "string") text = r;
      else if (r && typeof r.content === "string") text = r.content;
      else if (r && r.data && typeof r.data.content === "string") text = r.data.content;
    } catch (e) {}
  }
  if (!text) {
    if (typeof resp.content === "string") text = resp.content;
    else if (typeof resp.body === "string") text = resp.body;
    else if (typeof resp.text === "string") text = resp.text;
    else if (typeof resp === "string") text = resp;
    else if (resp.data && typeof resp.data.content === "string") text = resp.data.content;
  }
  const status = (resp.statusCode !== undefined ? resp.statusCode : (resp.status !== undefined ? resp.status : null));
  if (!text && resp.data && typeof resp.data === "object") {
    return { text: "", obj: resp.data, status: status == null ? null : status };
  }
  return { text: text, obj: null, status: status == null ? null : status };
}

/** 第 1 层：Tools.Net.http */
async function toolsHttpGet(url) {
  const resp = await Tools.Net.http({
    url: url,
    method: "GET",
    headers: {
      "User-Agent": UA,
      "Accept": "application/json,text/plain,*/*",
      "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8"
    },
    follow_redirects: true,
    connect_timeout: CONNECT_TIMEOUT_MS,
    read_timeout: HTTP_TRY_TIMEOUT_MS,
    validateStatus: false
  });
  return await extractResp(resp);
}

/** 第 2 层：OkHttp */
async function okHttpGet(url) {
  const client = OkHttp.newBuilder()
    .connectTimeout(CONNECT_TIMEOUT_MS)
    .readTimeout(HTTP_TRY_TIMEOUT_MS)
    .writeTimeout(HTTP_TRY_TIMEOUT_MS)
    .retryOnConnectionFailure(true)
    .build();
  const req = client.newRequest().url(url).method("GET").headers({
    "User-Agent": UA,
    "Accept": "application/json,text/plain,*/*",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8"
  });
  const response = await req.build().execute();
  const status = response ? response.statusCode : null;
  const text = response && response.content !== undefined ? response.content : "";
  return { text: text == null ? "" : String(text), obj: null, status: status == null ? null : status };
}

/** 第 3 层：DoH 解析真 IP -> IP 直连（绕 DNS 污染） */
async function dohHttpGet(url) {
  if (typeof toolCall !== "function") throw new Error("当前沙盒不支持 toolCall，无法使用 DoH 直连");
  const parts = splitHttpsUrl(url);
  if (!parts) throw new Error("DoH 直连仅支持 https URL");
  const rr = await dohResolve(parts.host);
  if (!rr.ips.length) throw new Error("DoH 解析 " + parts.host + " 未获得可用 IP");
  const tryList = rr.ips.slice(0, MAX_DOH_IPS);
  const hdrs = { "Host": parts.host, "User-Agent": UA, "Accept": "application/json,text/plain,*/*" };
  let lastMsg = "";
  for (let i = 0; i < tryList.length; i++) {
    const ip = tryList[i];
    try {
      const resp = await raceGuard(toolCall({
        name: "http_request",
        params: { url: "https://" + ip + parts.path, method: "GET", headers: JSON.stringify(hdrs), ignore_ssl: true }
      }), IP_TRY_TIMEOUT_MS, "IP " + ip);
      const status = resp && (resp.statusCode !== undefined ? resp.statusCode : resp.status);
      const text = resp && (resp.content !== undefined ? resp.content : resp.body);
      if (status === null || status === undefined) { lastMsg = "IP " + ip + " 未返回状态码"; continue; }
      return { text: text == null ? "" : String(text), obj: null, status: status };
    } catch (e) {
      lastMsg = "IP " + ip + " 失败: " + msgOf(e);
    }
  }
  throw new Error("DoH 直连全部失败：" + lastMsg);
}

function parseJsonFromResponse(r) {
  const text = r && r.text != null ? String(r.text) : "";
  if (!text) return null;
  try { return JSON.parse(text); } catch (e) {}
  const i1 = text.indexOf("{");
  const i2 = text.lastIndexOf("}");
  if (i1 >= 0 && i2 > i1) {
    try { return JSON.parse(text.slice(i1, i2 + 1)); } catch (e2) {}
  }
  const j1 = text.indexOf("[");
  const j2 = text.lastIndexOf("]");
  if (j1 >= 0 && j2 > j1) {
    try { return JSON.parse(text.slice(j1, j2 + 1)); } catch (e3) {}
  }
  return null;
}

/**
 * 三栈降级 HTTP GET -> JSON：
 * 1) Tools.Net.http
 * 2) OkHttp
 * 3) DoH 解析真 IP + IP 直连（绕 DNS 污染）
 * 每栈带自守卫超时，绝不无限挂起；任一层拿到合法 JSON 即返回。
 */
async function httpGetJson(url) {
  const stacks = [
    { name: "Tools.Net.http", run: function () { return toolsHttpGet(url); }, guard: HTTP_TRY_TIMEOUT_MS },
    { name: "OkHttp", run: function () { return okHttpGet(url); }, guard: HTTP_TRY_TIMEOUT_MS },
    { name: "DoH直连", run: function () { return dohHttpGet(url); }, guard: 25000 }
  ];
  const tried = [];
  for (let i = 0; i < stacks.length; i++) {
    try {
      const r = await raceGuard(stacks[i].run(), stacks[i].guard, stacks[i].name);
      if (r && r.obj) return r.obj;
      const parsed = parseJsonFromResponse(r);
      if (parsed !== null) return parsed;
      tried.push(stacks[i].name + ":无法解析为 JSON");
    } catch (e) {
      tried.push(stacks[i].name + ": " + msgOf(e));
    }
  }
  throw new Error("Steam 接口三栈均失败｜" + tried.join("｜") + "。可能是网络中断或域名被整体阻断，可稍后重试。");
}

async function storeSearch(query, cc, lang, limit) {
  const url =
    "https://store.steampowered.com/api/storesearch/?" +
    "term=" + encodeQ(query) +
    "&l=" + encodeQ(lang) +
    "&cc=" + encodeQ(cc) +
    "&category1=998"; // games 偏置，仍可能返回 DLC 等
  const json = await httpGetJson(url);
  const items = (json && Array.isArray(json.items)) ? json.items : [];
  const mapped = [];
  for (let i = 0; i < items.length && mapped.length < limit; i++) {
    const row = mapSearchItem(items[i]);
    if (row && row.appid) mapped.push(row);
  }
  return {
    query: query,
    total: json && json.total != null ? Number(json.total) : mapped.length,
    count: mapped.length,
    items: mapped,
    cc: cc,
    lang: lang
  };
}

async function appDetails(appid, cc, lang) {
  const id = str(appid).trim();
  if (!/^\d+$/.test(id)) throw new Error("appid 必须是数字");
  const url =
    "https://store.steampowered.com/api/appdetails?" +
    "appids=" + encodeQ(id) +
    "&cc=" + encodeQ(cc) +
    "&l=" + encodeQ(lang);
  const json = await httpGetJson(url);
  const data = pickAppData(json, id);
  if (!data) throw new Error("未找到 App 或该区不可用: " + id);
  return summarizeApp(data, id, cc, lang);
}

async function playerCount(appid) {
  const id = str(appid).trim();
  if (!/^\d+$/.test(id)) throw new Error("appid 必须是数字");
  const url =
    "https://api.steampowered.com/ISteamUserStats/GetNumberOfCurrentPlayers/v1/?appid=" +
    encodeQ(id);
  const json = await httpGetJson(url);
  const res = json && json.response ? json.response : null;
  if (!res || res.result !== 1) {
    return {
      appid: Number(id),
      player_count: null,
      available: false,
      note: "该 App 可能不支持在线人数接口"
    };
  }
  return {
    appid: Number(id),
    player_count: Number(res.player_count),
    available: true
  };
}

// ===================== 工具 =====================
async function search_game(params) {
  try {
    const query = str(params && params.query).trim();
    if (!query) return fail("query 不能为空");
    const cc = normalizeCc(params && params.cc);
    const lang = normalizeLang(params && params.lang);
    const limit = clamp((params && params.limit) || 10, 1, 25);

    const data = await storeSearch(query, cc, lang, limit);
    data.timestamp = nowIso();
    if (!data.items.length) {
      return fail("未搜索到相关游戏: " + query, { data: data });
    }
    return ok(data, "搜索完成");
  } catch (e) {
    return fail(e && e.message ? e.message : e);
  }
}

async function get_app_details(params) {
  try {
    const appid = str(params && params.appid).trim();
    if (!appid) return fail("appid 不能为空");
    const cc = normalizeCc(params && params.cc);
    const lang = normalizeLang(params && params.lang);

    const detail = await appDetails(appid, cc, lang);
    detail.timestamp = nowIso();
    return ok(detail, "详情获取完成");
  } catch (e) {
    return fail(e && e.message ? e.message : e);
  }
}

async function get_price(params) {
  try {
    const cc = normalizeCc(params && params.cc);
    const lang = normalizeLang(params && params.lang);
    let appid = str(params && params.appid).trim();
    const query = str(params && params.query).trim();

    if (!appid && !query) return fail("请提供 appid 或 query");

    let matched_name = "";
    if (!appid) {
      const s = await storeSearch(query, cc, lang, 5);
      if (!s.items.length) return fail("未找到游戏: " + query);
      appid = str(s.items[0].appid);
      matched_name = s.items[0].name || query;
    }

    const detail = await appDetails(appid, cc, lang);
    const data = {
      appid: Number(appid),
      name: detail.name || matched_name,
      is_free: detail.is_free,
      price: detail.price,
      store_url: detail.store_url,
      cc: cc,
      lang: lang,
      timestamp: nowIso()
    };
    return ok(data, "价格查询完成");
  } catch (e) {
    return fail(e && e.message ? e.message : e);
  }
}

async function get_player_count(params) {
  try {
    const appid = str(params && params.appid).trim();
    if (!appid) return fail("appid 不能为空");
    const data = await playerCount(appid);
    data.timestamp = nowIso();
    return ok(data, data.available ? "在线人数查询完成" : "在线人数不可用");
  } catch (e) {
    return fail(e && e.message ? e.message : e);
  }
}

async function lookup(params) {
  try {
    const query = str(params && params.query).trim();
    if (!query) return fail("query 不能为空");
    const cc = normalizeCc(params && params.cc);
    const lang = normalizeLang(params && params.lang);

    const s = await storeSearch(query, cc, lang, 8);
    if (!s.items.length) {
      return fail("未搜索到相关游戏: " + query, {
        data: { query: query, items: [], cc: cc, lang: lang }
      });
    }

    const top = s.items[0];
    const appid = top.appid;
    let detail = null;
    let players = null;
    let detail_error = null;
    let players_error = null;

    try {
      detail = await appDetails(appid, cc, lang);
    } catch (e1) {
      detail_error = e1 && e1.message ? e1.message : String(e1);
    }
    try {
      players = await playerCount(appid);
    } catch (e2) {
      players_error = e2 && e2.message ? e2.message : String(e2);
    }

    const data = {
      query: query,
      matched: top,
      alternatives: s.items.slice(1, 6),
      detail: detail,
      player_count: players,
      detail_error: detail_error,
      players_error: players_error,
      cc: cc,
      lang: lang,
      timestamp: nowIso()
    };
    return ok(data, "查询完成");
  } catch (e) {
    return fail(e && e.message ? e.message : e);
  }
}

// ===================== 导出 =====================
exports.search_game = search_game;
exports.get_app_details = get_app_details;
exports.get_price = get_price;
exports.get_player_count = get_player_count;
exports.lookup = lookup;
