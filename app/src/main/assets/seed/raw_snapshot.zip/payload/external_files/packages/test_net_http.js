/*
METADATA
{
    "name": "test_net_http",
    "display_name": {
        "zh": "网络栈测试",
        "en": "Net Stack Test"
    },
    "description": {
        "zh": "临时测试包：验证 Tools.Net.http 与 OkHttp 两个网络栈的连通性。测试后删除。",
        "en": "Temp test package for network stacks."
    },
    "category": "Test",
    "tools": [
        {
            "name": "test_http",
            "description": {
                "zh": "用 Tools.Net.http 请求指定 URL 并返回状态与响应片段。",
                "en": "Fetch URL via Tools.Net.http."
            },
            "parameters": [
                {
                    "name": "url",
                    "description": { "zh": "目标 URL。", "en": "Target URL." },
                    "type": "string",
                    "required": true
                }
            ]
        },
        {
            "name": "test_okhttp",
            "description": {
                "zh": "用 OkHttp 请求指定 URL 并返回状态与响应片段（对照组）。",
                "en": "Fetch URL via OkHttp."
            },
            "parameters": [
                {
                    "name": "url",
                    "description": { "zh": "目标 URL。", "en": "Target URL." },
                    "type": "string",
                    "required": true
                }
            ]
        }
    ]
}*/

const test_net_http = (function () {

    async function test_http(params) {
        const url = params && params.url ? String(params.url) : "";
        if (!url) {
            throw new Error("url 不能为空");
        }
        const started = Date.now();
        const resp = await Tools.Net.http({
            url: url,
            method: "GET",
            connect_timeout: 15000,
            read_timeout: 20000,
            responseType: "text",
            validateStatus: false
        });
        const ms = Date.now() - started;
        let shape = null;
        try {
            shape = resp ? Object.keys(resp).slice(0, 20) : null;
        }
        catch (e) {
            shape = "KEYS_ERR";
        }
        const content = resp && (resp.content !== undefined ? resp.content : (resp.body !== undefined ? resp.body : null));
        return {
            ms: ms,
            keys: shape,
            status: resp && resp.status !== undefined ? resp.status : (resp && resp.statusCode !== undefined ? resp.statusCode : null),
            content_len: content === null || content === undefined ? null : String(content).length,
            head: content === null || content === undefined ? null : String(content).slice(0, 200)
        };
    }

    async function test_okhttp(params) {
        const url = params && params.url ? String(params.url) : "";
        if (!url) {
            throw new Error("url 不能为空");
        }
        const client = OkHttp.newBuilder()
            .connectTimeout(15000)
            .readTimeout(20000)
            .retryOnConnectionFailure(true)
            .build();
        const started = Date.now();
        const request = client.newRequest()
            .url(url)
            .method("GET")
            .headers({
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            });
        const response = await request.build().execute();
        const ms = Date.now() - started;
        const text = response.content;
        return {
            ms: ms,
            status: response.statusCode,
            content_len: text ? String(text).length : 0,
            head: text ? String(text).slice(0, 200) : null
        };
    }

    async function wrap(label, func, params) {
        try {
            console.log("[test_net_http] 开始: " + label);
            const data = await func(params || {});
            complete({ success: true, message: label + " 完成", data: data });
        }
        catch (error) {
            const msg = error && error.message ? error.message : String(error);
            complete({ success: false, message: label + " 失败: " + msg });
        }
    }

    return {
        test_http: function (params) { return wrap("Tools.Net.http", test_http, params); },
        test_okhttp: function (params) { return wrap("OkHttp", test_okhttp, params); }
    };
})();

exports.test_http = test_net_http.test_http;
exports.test_okhttp = test_net_http.test_okhttp;
