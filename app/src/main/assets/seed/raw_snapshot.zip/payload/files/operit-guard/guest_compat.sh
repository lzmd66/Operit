#!/system/bin/sh
# Operit Ubuntu guest compatibility bootstrap for Android PROOT. v2 (2026-08-02)
# Runs from the Android host before entering the Ubuntu guest.
# v2: ELF launcher 恢复 + ld.so.preload(link->copy) + dpkg/apt 权限 + Queue-Mode 串行下载
ROOT="$1"
[ -n "$ROOT" ] && [ -d "$ROOT" ] || exit 0

BIN_DIR="/sdcard/Download/Operit/dev_package/proot_guard/bin"

is_elf() {
  [ -f "$1" ] || return 1
  head -c 4 "$1" 2>/dev/null | od -An -tx1 2>/dev/null | tr -d ' \n' | grep -q '^7f454c46'
}

restore_bin() {
  src="$1"; dst="$2"; mode="${3:-755}"
  [ -f "$src" ] || return 1
  if ! is_elf "$dst" || [ "$(stat -c%s "$dst" 2>/dev/null)" != "$(stat -c%s "$src" 2>/dev/null)" ]; then
    cp "$src" "$dst" 2>/dev/null || return 1
    chmod "$mode" "$dst" 2>/dev/null
  fi
  return 0
}

# ---- 1. 关键 ELF 二进制恢复 (apt-key launcher / dpkg-preconfigure launcher / 原始ELF) ----
restore_bin "$BIN_DIR/aptkey_launcher" "$ROOT/usr/bin/apt-key" 755
restore_bin "$BIN_DIR/generic_launcher" "$ROOT/usr/sbin/dpkg-preconfigure" 755
restore_bin "$BIN_DIR/update-alternatives.orig" "$ROOT/usr/bin/update-alternatives" 755
restore_bin "$BIN_DIR/dpkg-split.orig" "$ROOT/usr/bin/dpkg-split" 755
if [ -f "$BIN_DIR/libnolink.so" ] && [ ! -f "$ROOT/usr/lib/libnolink.so" ]; then
  cp "$BIN_DIR/libnolink.so" "$ROOT/usr/lib/libnolink.so" 2>/dev/null
  chmod 644 "$ROOT/usr/lib/libnolink.so" 2>/dev/null
fi

# ---- 2. launcher 依赖的真实脚本备份 ----
if is_elf "$ROOT/usr/bin/apt-key"; then
  if [ ! -f "$ROOT/usr/bin/apt-key.operit.sh" ]; then
    [ -f "$BIN_DIR/apt-key.operit.sh" ] && cp "$BIN_DIR/apt-key.operit.sh" "$ROOT/usr/bin/apt-key.operit.sh" 2>/dev/null
    [ -f "$ROOT/usr/bin/apt-key.operit.original" ] && cp "$ROOT/usr/bin/apt-key.operit.original" "$ROOT/usr/bin/apt-key.operit.sh" 2>/dev/null
  fi
  chmod 755 "$ROOT/usr/bin/apt-key.operit.sh" 2>/dev/null
fi
if is_elf "$ROOT/usr/sbin/dpkg-preconfigure" && [ ! -f "$ROOT/usr/sbin/dpkg-preconfigure.real" ]; then
  [ -f "$BIN_DIR/dpkg-preconfigure.real" ] && cp "$BIN_DIR/dpkg-preconfigure.real" "$ROOT/usr/sbin/dpkg-preconfigure.real" 2>/dev/null
  chmod 755 "$ROOT/usr/sbin/dpkg-preconfigure.real" 2>/dev/null
fi

# ---- 3. bashrc 注入 LD_PRELOAD (link(2) -> copy, Android 禁硬链接) ----
if [ -f "$ROOT/usr/lib/libnolink.so" ]; then
  if ! grep -q 'libnolink' "$ROOT/root/.bashrc" 2>/dev/null; then
    echo 'export LD_PRELOAD=/usr/lib/libnolink.so' >> "$ROOT/root/.bashrc" 2>/dev/null
  fi
  rm -f "$ROOT/etc/ld.so.preload" 2>/dev/null || true
fi

# ---- 4. dpkg/apt 关键目录可写 (修复 0700 压缩权限) ----
for path in \
  "$ROOT/var/lib/dpkg" \
  "$ROOT/var/lib/dpkg/updates" \
  "$ROOT/var/lib/dpkg/triggers" \
  "$ROOT/var/lib/dpkg/info" \
  "$ROOT/var/lib/dpkg/parts" \
  "$ROOT/var/lib/apt/lists" \
  "$ROOT/var/lib/apt/lists/partial" \
  "$ROOT/var/cache/apt/archives" \
  "$ROOT/var/cache/apt/archives/partial"
do
  [ -d "$path" ] && chmod 777 "$path" 2>/dev/null || true
done
for f in "$ROOT/var/lib/dpkg/status" "$ROOT/var/lib/dpkg/status-old"; do
  [ -f "$f" ] && chmod 666 "$f" 2>/dev/null || true
done
[ -d "$ROOT/tmp" ] && chmod 1777 "$ROOT/tmp" 2>/dev/null || true
[ -d "$ROOT/var/tmp" ] && chmod 1777 "$ROOT/var/tmp" 2>/dev/null || true

# ---- 5. 标准路径权限恢复 (原 v1 逻辑) ----
for path in \
  "$ROOT" "$ROOT/bin" "$ROOT/etc" "$ROOT/usr" "$ROOT/usr/bin" "$ROOT/usr/lib" \
  "$ROOT/usr/lib/apt" "$ROOT/usr/lib/apt/methods" "$ROOT/usr/share" \
  "$ROOT/usr/share/keyrings" "$ROOT/var" "$ROOT/var/cache" "$ROOT/var/cache/apt" \
  "$ROOT/var/cache/apt/archives" "$ROOT/var/cache/apt/archives/partial" \
  "$ROOT/var/lib" "$ROOT/var/lib/apt" "$ROOT/var/lib/apt/lists" \
  "$ROOT/var/lib/apt/lists/partial" "$ROOT/var/log" "$ROOT/var/log/apt"
do
  [ -d "$path" ] && chmod 755 "$path" 2>/dev/null || true
done
for path in \
  "$ROOT/bin/bash" "$ROOT/bin/dash" "$ROOT/usr/bin/apt" "$ROOT/usr/bin/apt-cache" \
  "$ROOT/usr/bin/apt-config" "$ROOT/usr/bin/apt-get" "$ROOT/usr/bin/apt-key" \
  "$ROOT/usr/bin/dash" "$ROOT/usr/bin/dpkg" "$ROOT/usr/bin/dpkg-deb" \
  "$ROOT/usr/bin/env" "$ROOT/usr/bin/gpgv"
do
  [ -f "$path" ] && chmod 755 "$path" 2>/dev/null || true
done

APT_DIR="$ROOT/etc/apt"
SOURCES="$APT_DIR/sources.list"
RESOLV="$ROOT/etc/resolv.conf"
PACKAGEKIT="$APT_DIR/apt.conf.d/20packagekit"
DISABLED_DIR="$APT_DIR/operit-disabled"
mkdir -p "$APT_DIR/apt.conf.d" "$DISABLED_DIR" 2>/dev/null || true

# ---- 6. APT 源 (signed-by + security, 清华 ports) ----
cat > "$SOURCES" <<'EOF'
# Operit Ubuntu on Android/ARM64.
deb [signed-by=/usr/share/keyrings/ubuntu-archive-keyring.gpg] https://mirrors.tuna.tsinghua.edu.cn/ubuntu-ports/ noble main restricted universe multiverse
deb [signed-by=/usr/share/keyrings/ubuntu-archive-keyring.gpg] https://mirrors.tuna.tsinghua.edu.cn/ubuntu-ports/ noble-updates main restricted universe multiverse
deb [signed-by=/usr/share/keyrings/ubuntu-archive-keyring.gpg] https://mirrors.tuna.tsinghua.edu.cn/ubuntu-ports/ noble-security main restricted universe multiverse
deb [signed-by=/usr/share/keyrings/ubuntu-archive-keyring.gpg] https://mirrors.tuna.tsinghua.edu.cn/ubuntu-ports/ noble-backports main restricted universe multiverse
EOF
chmod 644 "$SOURCES" 2>/dev/null || true

# ---- 7. DNS (国内优先) ----
cat > "$RESOLV" <<'EOF'
# Operit PROOT DNS order: local resolvers first, public fallback last.
nameserver 223.5.5.5
nameserver 119.29.29.29
nameserver 1.1.1.1
options timeout:2 attempts:2
EOF
chmod 644 "$RESOLV" 2>/dev/null || true

# ---- 8. APT 网络策略 (串行下载, PROOT 并发易 182) ----
cat > "$APT_DIR/apt.conf.d/99operit-proot-network" <<'EOF'
// Stable network behavior for Operit Ubuntu running under Android PROOT.
Acquire::ForceIPv4 "true";
Acquire::Retries "3";
Acquire::http::Timeout "30";
Acquire::https::Timeout "30";
Acquire::http::Pipeline-Depth "0";
Acquire::https::Pipeline-Depth "0";
Acquire::http::No-Cache "true";
Acquire::https::No-Cache "true";
Acquire::Queue-Mode "host";
EOF
chmod 644 "$APT_DIR/apt.conf.d/99operit-proot-network" 2>/dev/null || true

# ---- 9. PackageKit 禁用 (原 v1 逻辑) ----
if [ -f "$PACKAGEKIT" ]; then
  mv -f "$PACKAGEKIT" "$DISABLED_DIR/20packagekit" 2>/dev/null || true
fi

# ---- 10. 清理重复源文件 (deb822 与 sources.list 重复配置) ----
rm -f "$ROOT/etc/apt/sources.list.d/ubuntu.sources" 2>/dev/null || true

exit 0